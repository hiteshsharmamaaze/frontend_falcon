from django.db import connections
from .models import *
from .pdfgenerator import *
import psycopg2

dbConnection= connections['default'].cursor()
 #udf_get_ins_insured_info_json
 
#udf_get_coverages_info_by_quoteid

#udf_get_ins_quote_statuses

def get_queue_statuses_db():
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_ins_quote_statuses();")

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
               
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result

def get_db_get_coverages_info_by_quoteid(quote_id):
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_coverages_info_by_quoteid(%s);", (quote_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                print("Begin.........")
                print(item[0]," coverages data")
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result



def get_quote_info_by_quoteid_db(quote_id):
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_quote_details_with_quote_id(%s);", (quote_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                print("Begin.........")
                print(item[0]," coverages data")
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result





def get_db_general_info_by_quoteid(quote_id):
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_general_info_by_quoteid(%s);", (quote_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                print(item[0])
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result



def get_db_ins_insured_info_by_quote_id(quote_id):
    """
    

    Args:
        agency_id (_type_): _description_
    """
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_ins_insured_info_json(%s);", (quote_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result
 


def get_copmanys_by_lob_id(lob_id):
    
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_comapny_lob_from_xref_by_lob(%s);", (lob_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result

def   get_vehicles_by_quote_id_db(quote_id):
    """
    

    Args:
        agency_id (_type_): _description_
    """
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_vehicles_by_quoteid(%s);", (quote_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])
    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result  


def   get_submission_details_by_quote_id(quote_id):
    """
    

    Args:
        agency_id (_type_): _description_
    """
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_submission_details_by_quote_id_json(%s);", (quote_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result  



def get_all_quotes_of_submission_db(submission_id):
    """
    

    Args:
        agency_id (_type_): _description_
    """
    result = []

    try:
        dbConnection= connections['default'].cursor()
        #udf_get_all_submission_list_for_underwriter_json()
        #query = dbConnection.mogrify("select udf_get_all_submission_list_for_underwriter_json(%s);")
        query = dbConnection.mogrify("select udf_get_all_quotes_details_with_submission_id(%s);", (submission_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result

def get_all_quotes_by_underwriter_id(underwriter_id):
    """
    

    Args:
        agency_id (_type_): _description_
    """
    result = []

    try:
        dbConnection= connections['default'].cursor()
        #udf_get_all_submission_list_for_underwriter_json()
        query = dbConnection.mogrify("select udf_get_all_submission_list_for_underwriter_json();")
        #query = dbConnection.mogrify("select udf_get_all_submission_list_by_underwriter_json(%s);", (underwriter_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result
#udf_get_current_underwriter_json

def get_underwriter_by_agency_id_db(agency_id):
    """
    

    Args:
        agency_id (_type_): _description_
    """
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_current_underwriter_json(%s);", (agency_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result

def get_all_non_agency_users_db():
    """
    

    Args:
        agency_id (_type_): _description_
    """
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_users_json();")

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result

def get_all_quote_status_db():
    """
    

    Args:
        agency_id (_type_): _description_
    """
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_quote_status_json();")

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result

def get_all_underwriters_db():
    """
    

    Args:
        agency_id (_type_): _description_
    """
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_all_underwriters_json();")

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result

def get_all_quotes_by_agency_id(agency_id):
    """
    

    Args:
        agency_id (_type_): _description_
    """
    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_all_submission_list_by_agency_id_json(%s);", (agency_id,))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result

#udf_get_quote_details_with_quote_id

def get_quote_data_from_history(_quote_id):
    """_summary_

    Args:
        id (_type_): _description_

    Returns:
        _type_: _description_
    """
    s_id = -1

    result = []

    try:
        dbConnection= connections['default'].cursor()
        #udf_get_quote_json_data
        #query = dbConnection.mogrify("select udf_get_quote_premium_estimate(%s);", (_quote_id,))
        query = dbConnection.mogrify("select udf_get_quote_json_data(%s);", (_quote_id,))
        dbConnection.execute(query)

        rows = dbConnection.fetchall()
        print(rows) 
        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result


def get_quotes_by_submissionid_db(id):
    """_summary_

    Args:
        id (_type_): _description_

    Returns:
        _type_: _description_
    """
    s_id = -1

    result = []

    try:
        dbConnection= connections['default'].cursor()
        query = dbConnection.mogrify("select udf_get_ins_quotes_json(%s);", (str(id),))

        dbConnection.execute(query)

        rows = dbConnection.fetchall()

        if len(rows) > 0:
            for item in rows:
                result.append(item[0])


    except (Exception, psycopg2.DatabaseError) as error:

        s_id = -1

    return result


def get_state_city_by_zipcode(zipcode):
    """sumary_line
    
    Keyword arguments:
    argument -- description
    Return: return_description
    """
       
    state_city=''
    state_garging=''
    city_state_dict={"state_city":'',"state_garging":''}
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_state_city_territory_with_zipcode(%s);", (zipcode,))
            dbConnection.execute(query)
            
            rows=dbConnection.fetchall()
          
           
            if len(rows)>0:
                state_city=rows[0][0].get('city')
                state_garging=rows[0][0].get('state')
               
           
                city_state_dict={"state_city":state_city,"state_garging":state_garging}
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           u_id=-1
           
    return city_state_dict
#udf_update_quote_underwriter


def update_quote_underwriter_db(quote_id,underwriter_id ):
    id=-1
    try:
       
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_update_quote_underwriter(%s,%s);",(quote_id , underwriter_id ,))
        dbConnection.execute(query)
           
        rows=dbConnection.fetchall()
          
        print(rows," underwriter")   
        if len(rows)>0:
            id=rows[0][0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
    print(id)      
    return id
    

def update_quote_status_db(quote_id,status_id ):
    id=-1
    try:
       
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_update_quote_status(%s,%s);",(quote_id , status_id ,))
        dbConnection.execute(query)
           
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
            id=rows[0][0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
          
    return id
    



#******** update submission draft

def update_submission_draft_db(_data_json,_submission_draft_id ):
    id=-1
    try:
       
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_update_submission_draft(%s,%s);",(_data_json ,  _submission_draft_id ,))
        dbConnection.execute(query)
           
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
            id=rows[0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
          
    return id
    

#************ save submission draft *************#
def save_submission_draft_db(_data_json ,  
                          _insured_name , 
                          _dot_number,   
                          _effective_date, 
                          _user_id):
    id=-1
    try:
       
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_add_submission_draft(%s,%s,%s,%s,%s);",
                                 (_data_json ,  
                          _insured_name , 
                          _dot_number,   
                          _effective_date, 
                          _user_id
                                        ,))
        dbConnection.execute(query)
           
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
            id=rows[0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
          
    return id

#**************************************************
#udf_remove_quote_general_info

def remove_general_info_db(_quote_id ):
    id=-1
    try:
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_remove_quote_general_info(%s);",
                                 ( _quote_id ,))
        dbConnection.execute(query)
           
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
            id=rows[0]
    except:
        id=-1
    return id
    

#*********** adding general info **************************#

def add_general_info(quote_type ,
	policy_type  ,
    company,
    lob,
	bill_type  ,
	quote_id ):
    id=-1
    try:
       
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_add_quote_general_info(%s,%s,%s,%s,%s,%s);",
                                 (quote_type ,
                                  company,
                                  lob,
	                                policy_type  ,
	                                bill_type  ,
	                                quote_id
                                        ,))
        dbConnection.execute(query)
           
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
            id=rows[0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
           print(quote_type ,
                                  company,
                                  lob,
	                                policy_type  ,
	                                bill_type  ,
	                                quote_id
                                        ,)
           
    return id

def update_general_info(quote_type ,
	policy_type  ,
    company,
    lob,
	bill_type  ,
	quote_id ):
    id=-1
    try:
       
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_add_quote_general_info(%s,%s,%s,%s,%s,%s);",
                                 (quote_type ,
                                  company,
                                  lob,
	                                policy_type  ,
	                                bill_type  ,
	                                quote_id
                                        ,))
        dbConnection.execute(query)
        rows=dbConnection.fetchall()   
        if len(rows)>0:
            id=rows[0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
           
           
    return id
#**************************************************************
#*********************** Add radius of operations ********

def remove_radius_of_operations(_quote_id):
    id=-1
    try:
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_remove_radius_of_oprations(%s);",(_quote_id,))
        dbConnection.execute(query)
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
            id=rows[0]
        
    except:
        id=-1
        
    return id
        

def add_radius_of_operation(range_of_transport,radius_of_operation,
                            other_states_1,other_states_2,other_states_3,other_states_4,quote_id):
    id=-1    
    try:
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_add_radius_of_oprations(%s,%s,%s,%s,%s,%s,%s);",
                                 (range_of_transport ,
	                                radius_of_operation  ,
	                                other_states_1  ,
	                                other_states_2,
                                    other_states_3,
                                    other_states_4,
                                    quote_id,
                                        ))
        dbConnection.execute(query)
           
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
            id=rows[0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
           
    return id


#**********************************************************
#*********** Add quote commodity **************************
#udf_remove_quote_commodity

def remove_quote_commodities(quote_id):
    id=-1    
    try:
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_remove_quote_commodity(%s);",
                                 (
	                                quote_id  ,
	                                
                                        ))
        dbConnection.execute(query)
           
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
            id=rows[0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
           
    return id

#udf_add_quote_commodity
def add_quote_commodity(commodity,quote_id):
    id=-1    
    try:
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_add_quote_commodity(%s,%s);",
                                 (commodity ,
	                                quote_id  ,
	                                
                                        ))
        dbConnection.execute(query)
           
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
            id=rows[0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
           
    return id
    

def remove_insured_db(_submission_id):
    id=-1
    try:
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_remove_insured(%s);", 
                                        (_submission_id
                                        ,))
        dbConnection.execute(query)
        id=1
        
    except:
        pass
    return id
#**********************************************************
#********************************* adding a submissions ************************#

def add_submission_new_db(_agency_id, _effective_date,_expiration_date, _broker_default_email, _broker_default_phone, _broker_bind_confirmation_email, _broker_endorsments_contact_email,_broker_cancellation_confirmation_email, _user_id):
    id=-1
    try:
            
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_add_submission_new(%s,%s,%s,%s,%s,%s,%s,%s,%s);", 
                                        (_agency_id, _effective_date,_expiration_date,_broker_default_email, _broker_default_phone, _broker_bind_confirmation_email, _broker_endorsments_contact_email,_broker_cancellation_confirmation_email, _user_id
                                        ,))
            dbConnection.execute(query)
           
            rows=dbConnection.fetchall()
          
           
            if len(rows)>0:
                
                id=rows[0][0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
           
    return id

#*****************************************************#
#********************** Add insured Info ************#

def add_insured(insuredInfo,filingInfo,submission_id):
    insured_id= add_insured_new_db(insuredInfo['insured_name'],insuredInfo['insured_dba'],
                                      insuredInfo['entity_type'],
                                      insuredInfo['insured_mailing_address'],
                                      insuredInfo['insured_mailing_city'],
                                      insuredInfo['insured_mailing_state'],
                                      insuredInfo['insured_mailing_zip'],
                                       insuredInfo['insured_garaging_address'],
                                       insuredInfo['insured_garaging_city'],
                                       insuredInfo['insured_garaging_state'],
                                       insuredInfo['insured_garaging_zip'],
                                        insuredInfo['insured_phone'],
                                       insuredInfo['insured_email'],
                                       '',insuredInfo['insured_policy_name'],
                                       insuredInfo['insured_owner_operator'],
                                        int(insuredInfo['years_of_experience']),
                                        filingInfo['dot_yes_no'],
                                        filingInfo['dot_number'],
                                        filingInfo['icc_filings_yes_no'],
                                        filingInfo['mc_number'],
                                        filingInfo['state_filings_yes_no'],
                                        filingInfo['permit_number'],
                                        filingInfo['safer_factor'],
                                        submission_id
                                                                            
                                       
                                      )
    return insured_id
    

def add_insured_new_db(_insured_name,
			_insured_dba, 
			_insured_entity, 
			_insured_mailing_address, 
			_insured_mailing_city,
_insured_mailing_state, 
			_insured_mailing_zip, 
			_insured_garaging_address, 
			_insured_garaging_city,
_insured_garaging_state, 
			_insured_garaging_zip, 
			_insured_phone, 
			_insured_email, 
			_history,
			
_name_on_policy,
			_insured_owner_operator,
			_years_of_experience,
			_does_insured_have_dot_number,
_dot_number,
			_does_insured_require_icc_filings,
			_does_insured_need_state_filings,
			_mc_number,
_permit_number,
			_insured_rating_on_safer_fmcsa_website,
			_submission_id):
    id=-1
    try:
            
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_add_insured(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", 
                                        (_insured_name,
			                             _insured_dba, 
			                             _insured_entity, 
			                            _insured_mailing_address, 
			                            _insured_mailing_city,
                                        _insured_mailing_state, 
			                            _insured_mailing_zip, 
			                            _insured_garaging_address, 
			                            _insured_garaging_city,
                                        _insured_garaging_state, 
			                            _insured_garaging_zip, 
			                            _insured_phone, 
			                            _insured_email, 
			                            _history,
			
                                        _name_on_policy,
			                            _insured_owner_operator,
			                            int(_years_of_experience),
			                            _does_insured_have_dot_number,
                                        _dot_number,
			                            _does_insured_require_icc_filings,
			                            _does_insured_need_state_filings,
			                            _mc_number,
                                        _permit_number,
			                            _insured_rating_on_safer_fmcsa_website,
			                            _submission_id ,))
            dbConnection.execute(query)
           
            rows=dbConnection.fetchall()
          
           
            if len(rows)>0:
                id=rows[0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error,"insured info",type(_years_of_experience))
           print(type(_insured_name),
			type(_insured_dba), 
			type(_insured_entity), 
			type(_insured_mailing_address), 
			type(_insured_mailing_city),
type(_insured_mailing_state), 
			type(_insured_mailing_zip), 
			type(_insured_garaging_address), 
			type(_insured_garaging_city),
type(_insured_garaging_state), 
			type(_insured_garaging_zip), 
			type(_insured_phone), 
			type(_insured_email), 
			type(_history),
			
type(_name_on_policy),
			type(_insured_owner_operator),
			_years_of_experience,
			_does_insured_have_dot_number,
        type(_dot_number),
			_does_insured_require_icc_filings,
			_does_insured_need_state_filings,
			type(_mc_number),
_permit_number,
			_insured_rating_on_safer_fmcsa_website,
			_submission_id)
           id=-1
           
    return id

####*****************************************************#

###************** coverages*****************************

def add_coverages(coveragesInfo,secondary_class,quote_id):
   
    coverages_id=add_coverages_db(coveragesInfo['rating_type'] ,
    coveragesInfo['liability'] ,
    int(coveragesInfo['liability']) if coveragesInfo['liability']=='Yes' else 0  ,
    coveragesInfo['hired_auto_liability'] ,
	coveragesInfo['hired_auto_type'] ,
	int(coveragesInfo['cost_basis']) if coveragesInfo['hired_auto_liability']=='Yes' else 0,
	coveragesInfo['non_hired_auto_limit'] ,
	coveragesInfo['non_hired_auto_on_contratual_basis'],
	int(coveragesInfo['number_of_non_owned_units']) ,
    coveragesInfo['pd'],
    coveragesInfo['trailer_interchange'] ,
	int(coveragesInfo['trailer_interchange_limit']) ,
	int(coveragesInfo['trailer_interchange_units']) ,
    'No' if coveragesInfo['towing']=='No' else 'Yes'  ,
	int(coveragesInfo['towing']) ,
	'No' if coveragesInfo['cargo']=='No' else 'Yes'  ,
	int(coveragesInfo['cargo']) ,
	int(coveragesInfo['cargo_deductible']) ,
	coveragesInfo['refeer_coverage_required']  ,
	int(coveragesInfo['refeer_coverage']) ,
    secondary_class,
	'No' if coveragesInfo['um_limit']=='No' else 'Yes',
	0 if coveragesInfo['um_limit']=='No' else int(coveragesInfo['um_limit']),
	'No' if coveragesInfo['uim_limit']=='No' else 'Yes',
	0 if coveragesInfo['um_limit']=='No' else int(coveragesInfo['uim_limit']),
	'No' if coveragesInfo['pip_limit']=='No' else 'Yes',
	0  if coveragesInfo['pip_limit']=='No' else int(coveragesInfo['pip_limit']),
	'No' if coveragesInfo['medical_limit']=='No' else 'Yes',
	0 if coveragesInfo['medical_limit']=='No' else int(coveragesInfo['medical_limit']),
	quote_id 
)
    return coverages_id
#udf_delete_quote_coverages
def remove_quote_coverage_with_quote_id(_quote_id):
    id=-1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_delete_quote_coverages(%s);",(_quote_id,))
            rows=dbConnection.fetchall()
          
           
            if len(rows)>0:
                id=rows[0]
            
    except:
        id=-1
    return id

def add_coverages_db(rating_type ,
    liability ,
    liability_limit  ,
    hired_auto ,
	hired_auto_type ,
	hired_auto_cost_basic ,
	non_owned_auto_liability ,
	is_non_owned_auto_liability_contractual_basis,
	no_of_non_owned_units ,
    pd ,
    trailer_interchange ,
	trailer_interchange_limit ,
	trailer_interchange_no_of_units ,
    towing  ,
	towing_limit ,
	cargo  ,
	cargo_limit ,
	cargo_deductible ,
	reefer  ,
	reefer_deductible ,
    secondary_class,
	um,
	um_limit,
	uim,
	uim_limit,
	pip,
	pip_limit,
	medical,
	medical_limit,
	quote_id 
):
    id=-1
    
    print(rating_type ,
    liability ,
    liability_limit  ,
    hired_auto ,
	hired_auto_type ,
	hired_auto_cost_basic ,
	non_owned_auto_liability ,
	is_non_owned_auto_liability_contractual_basis,
	no_of_non_owned_units ,
    pd ,
    trailer_interchange ,
	trailer_interchange_limit ,
	trailer_interchange_no_of_units ,
    towing  ,
	towing_limit ,
	cargo  ,
	cargo_limit ,
	cargo_deductible ,
	reefer  ,
	reefer_deductible ,
    secondary_class,
	um,
	um_limit,
	uim,
	uim_limit,
	pip,
	pip_limit,
	medical,
	medical_limit,
	quote_id ,"   quote.....covergaes")
    
    try:
            
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_add_quote_coverages(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", 
                                        (rating_type ,
    'No' if liability=='No' else 'Yes' ,
    int(liability)  ,
    hired_auto ,
	hired_auto_type ,
	int(hired_auto_cost_basic) ,
	non_owned_auto_liability ,
	is_non_owned_auto_liability_contractual_basis,
	int(no_of_non_owned_units) ,
    pd ,
    trailer_interchange ,
	int(trailer_interchange_limit) ,
	int(trailer_interchange_no_of_units) ,
    towing  ,
	int(towing_limit) ,
	cargo  ,
	int(cargo_limit) ,
	int(cargo_deductible) ,
	reefer  ,
	int(reefer_deductible) ,
    secondary_class,
	um,
	int(um_limit),
	uim,
	int(uim_limit),
	pip,
	int(pip_limit),
	medical,
	int(medical_limit),
	quote_id  ,))
            dbConnection.execute(query)
           
            rows=dbConnection.fetchall()
          
           
            if len(rows)>0:
                id=rows[0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error,"error in coverages")
           id=-1
           
    return id
    


###*****************************************************


###********************************************************#


def get_applcation_type_id(_company_id , 
	_lob_id):
    id=-1
    try:
            
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_application_type_id_by_company_and_lob(%s,%s);", 
                                        (_company_id ,_lob_id ,))
            dbConnection.execute(query)
           
            rows=dbConnection.fetchall()
          
           
            if len(rows)>0:
                id=rows[0][0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
           
    return id   

#udf_remove_quote_existing
def update_quote_db(_quote_id,_user_id ,  
	_company_id , 
	_lob_id ):
    id=-1
    try:
        dbConnection= connections['default'].cursor()
        app_dict=get_applcation_type_id(_company_id,_lob_id)
            #print(_application_type_id,"app type id error")
        _application_type_id=app_dict['application_type_id']
        query= dbConnection.mogrify("select udf_update_quote_existing(%s,%s,%s,%s,%s);", 
                                        (_quote_id,_application_type_id,_user_id ,  
	_company_id , 
	_lob_id ,))
        dbConnection.execute(query)
           
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
                id=rows[0][0]
    except:
        id=-1
    
    return id
                

def add_quote_new_db(_submission_id ,
	_user_id ,  
	_company_id , 
	_lob_id ):
    id=-1
    try:
            app_dict=get_applcation_type_id(_company_id,_lob_id)
            #print(_application_type_id,"app type id error")
            _application_type_id=app_dict['application_type_id']
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_add_quote_new(%s,%s,%s,%s,%s);", 
                                        (_submission_id ,  _application_type_id, _user_id,_company_id ,_lob_id 
	
                                        ,))
            dbConnection.execute(query)
           
            rows=dbConnection.fetchall()
          
           
            if len(rows)>0:
                id=rows[0][0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error,"error in adding quote")
           print(_submission_id ,
	_user_id ,  
	_company_id , 
	_lob_id," error in")
           id=-1
           
    return id


#add submission details
def add_submission(submission):
    """_summary_

    Args:
        submission (_type_): _description_

    Returns:
        _type_: _description_
    """
    id=-1
    try:
            
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_add_submission(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", 
                                        (submission.insured_name,
                                         submission.effective_date,
                                         submission.user_id,
                                         submission.dot_number,
                                         submission.mc_number,
                                         submission.permit_number,
                                         submission.garagingaddress,
                                         submission.garagingcity,
                                         submission.garagingstate,
                                         submission.garagingzip,
                                         submission.mailingaddress,
                                         submission.mailingcity,
                                         submission.mailingstate,
                                         submission.mailingzip
                                        ,))
            dbConnection.execute(query)
           
            rows=dbConnection.fetchall()
          
           
            if len(rows)>0:
                id=rows[0][0]
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           id=-1
           
    return id

def add_quote(quote):
    """_summary_

    Args:
        quote (_type_): _description_

    Returns:
        _type_: _description_
    """
    id=-1
   
    
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_add_quote(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", 
                                        
                                        (quote.submissionid,
                quote.quotedatetime,
                quote.hiredauto,
                 quote.hiredauto_cost,
                 quote.hiredauto_premium,
                 quote.nonownedauto,
                 quote.nonownedauto_premium,
                 quote.broker_fee_total,
                 quote.broker_fee_liability,
                 quote.broker_fee_pd,
                 quote.broker_fee_cargo,
                 quote.surpluslinetax,
                 quote.stampingfee,
                 quote.costofpackage,
                 quote.costofliability,
                 quote.costofpd,
                 quote.costofcargo,
                 quote.ai_total_cost,
                 quote.effectivedate,))
            dbConnection.execute(query)
            #dbConnection.commit()
            rows=dbConnection.fetchall()
          
           
            if len(rows)>0:
                id=rows[0][0]
                print(id)
                
               
           
                
    except (Exception, psycopg2.DatabaseError) as error:
           id=-1
           print(error)
           
    return id
def remove_vehicles(_quote_id):
    #udf_remove_vehicles
    id=-1
    try:
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_remove_vehicles(%s);",(_quote_id,))
        dbConnection.execute(query)
       
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
                id=rows[0]
        
         
    except:
        id=-1
    return id

def add_vehicledetails(vehicle):
    """_summary_

    Args:
        vehicle (_type_): _description_

    Returns:
        _type_: _description_
    """
    id=-1
   
    try:
        
        print(vehicle.vehicle_medical_limit,"Vehicle medical limit")
       
       
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_add_vehicle(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", 
                                 (vehicle.vehiclemake,                     
                vehicle.vehiclemodel,
                vehicle.vehicleyear,
                str(vehicle.vehicletypefactor),
                str(vehicle.vehiclemakefactor),
                vehicle.vehiclemodelfactor,
                str(vehicle.vehicledeductiblefactor),
                vehicle.vehiclestatedamount,
                vehicle.vehicledeductible,
                vehicle.vehicle_um,
                str(vehicle.vehicle_um_premium),
                vehicle.vehicle_um_limit,
                vehicle.vehicle_uim,
                str(vehicle.vehicle_uim_premium),
                vehicle.vehicle_medical,
                vehicle.vehicle_medical_limit,
                vehicle.vehicle_medical_premium,
                vehicle.vehicle_pd_premium,
                vehicle.vehicle_liability,
                vehicle.vehicle_liability_limit,
                vehicle.vehicle_liability_premium,
                vehicle.vehicle_pip,
                str(vehicle.vehicle_pip_limit),
                str(vehicle.vehicle_pip_premium),
                vehicle.vehicle_trailer_interchange,
                vehicle.vehicle_trailer_interchange_limit,
                str(vehicle.vehicle_trailer_interchange_premium),
                vehicle.vehicle_towing,
                str(vehicle.vehicle_towing_limit),
                str(vehicle.vehicle_towing_premium),
                vehicle.vehicle_cargo,
                vehicle.vehicle_cargo_limit,
                vehicle.vehicle_cargo_deductible,
                vehicle.vehicle_cargo_deductible_factor,
                vehicle.vehicle_cargo_premium,
                vehicle.vehicle_cargo_reefer,
                vehicle.vehicle_cargo_reefer_limit,
                str(vehicle.vehicle_cargo_reefer_factor),
                 vehicle.vehicle_cargo_refeer_deductible_factor,
                vehicle.quoteid,
                vehicle.vehicle_add_date,vehicle.weight,vehicle.vin,vehicle.o_l_rent,))
        except Exception as e:
            print("Exception in vehicles")
            exception_type, exception_object, exception_traceback = sys.exc_info()
            filename = exception_traceback.tb_frame.f_code.co_filename
            line_number = exception_traceback.tb_lineno
            #print(line_number)
            print(e.__str__) 
        
        dbConnection.execute(query)
       
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
                id=rows[0][0]
    except (Exception, psycopg2.DatabaseError) as error:
           id=-1
           print(error.__cause__ , " in adding vehicle")
           print(vehicle.vehiclemake,                     
                vehicle.vehiclemodel,
                vehicle.vehicleyear,
                str(vehicle.vehicletypefactor),
                str(vehicle.vehiclemakefactor),
                vehicle.vehiclemodelfactor,
                str(vehicle.vehicledeductiblefactor),
                vehicle.vehiclestatedamount,
                vehicle.vehicledeductible,
                vehicle.vehicle_um,
                str(vehicle.vehicle_um_premium),
                vehicle.vehicle_um_limit,
                vehicle.vehicle_uim,
                str(vehicle.vehicle_uim_premium),
                vehicle.vehicle_medical,
                vehicle.vehicle_medical_limit,
                vehicle.vehicle_medical_premium,
                vehicle.vehicle_pd_premium,
                vehicle.vehicle_liability,
                vehicle.vehicle_liability_limit,
                vehicle.vehicle_liability_premium,
                vehicle.vehicle_pip,
                str(vehicle.vehicle_pip_limit),
                str(vehicle.vehicle_pip_premium),
                vehicle.vehicle_trailer_interchange,
                vehicle.vehicle_trailer_interchange_limit,
                str(vehicle.vehicle_trailer_interchange_premium),
                vehicle.vehicle_towing,
                str(vehicle.vehicle_towing_limit),
                str(vehicle.vehicle_towing_premium),
                vehicle.vehicle_cargo,
                vehicle.vehicle_cargo_limit,
                vehicle.vehicle_cargo_deductible,
                vehicle.vehicle_cargo_deductible_factor,
                vehicle.vehicle_cargo_premium,
                vehicle.vehicle_cargo_reefer,
                vehicle.vehicle_cargo_reefer_limit,
                str(vehicle.vehicle_cargo_reefer_factor),
                 vehicle.vehicle_cargo_refeer_deductible_factor,
                vehicle.quoteid,
                vehicle.vehicle_add_date,vehicle.weight,vehicle.vin,vehicle.o_l_rent)
           
    return id
def remove_liability_factors_xref(_quote_id):
    #udf_remove_liabilityfactors_quote_xref
    id=-1
    try:
        #print(LiabilityXref.convert_to_tuple())
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_remove_liabilityfactors_quote_xref(%s);", (_quote_id,))
        dbConnection.execute(query)
        
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
                id=rows[0]
    except (Exception, psycopg2.DatabaseError) as error:
           id=-1
           
           
    return id

def add_liabilityxref(LiabilityXref):
    """_summary_

    Args:
        LiabilityXref (_type_): _description_

    Returns:
        _type_: _description_
    """
    id=-1
    try:
        #print(LiabilityXref.convert_to_tuple())
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_add_liabilityfactors_quote_xref(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", LiabilityXref.convert_to_tuple())
        dbConnection.execute(query)
        
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
                id=rows[0][0]
    except (Exception, psycopg2.DatabaseError) as error:
           id=-1
           print(error,"xref")
           
    return id

def remove_pd_factors_xref(_quote_id):
    #udf_remove_liabilityfactors_quote_xref
    id=-1
    try:
        #print(LiabilityXref.convert_to_tuple())
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_remove_pdfactors_quote_xref(%s);", (_quote_id,))
        dbConnection.execute(query)
        
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
                id=rows[0]
    except (Exception, psycopg2.DatabaseError) as error:
           id=-1
           
           
    return id

def add_pdxref(pdXref):
    """_summary_

    Args:
        pdXref (_type_): _description_

    Returns:
        _type_: _description_
    """
    id=-1
    print(pdXref.convert_to_tuple())
    try:
        #print(pdXref.convert_to_tuple())
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_add_pdfactors_quote_xref(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", 
         (pdXref.quoteid,
              pdXref.stated_value,
                pdXref.base_rate_factor,
                pdXref.vehicle_make_factor,
                pdXref.vehicle_model_factor,
                pdXref.state_factor,
                pdXref.rate_control_factor,
                pdXref.commodity_factor,
                pdXref.driver_factor,
                pdXref.safer_factor,
                pdXref.years_of_experience_factor,
                pdXref.deductible_factor,
                pdXref.uw_credit_debit_factor,
                pdXref.loss_experience_factor,)                           )
        dbConnection.execute(query)
        #dbConnection.commit()
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
                id=rows[0][0]
    except (Exception, psycopg2.DatabaseError) as error:
           id=-1
           print(error," In pdxref")
           
    return id

def remove_cargo_factors_xref(_quote_id):
    #udf_remove_liabilityfactors_quote_xref
    id=-1
    try:
        #print(LiabilityXref.convert_to_tuple())
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_remove_cargofactors_quote_xref(%s);", (_quote_id,))
        dbConnection.execute(query)
        
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
                id=rows[0]
    except (Exception, psycopg2.DatabaseError) as error:
           id=-1
           
           
    return id

def add_cargoxref(cargoXref):
    """_summary_

    Args:
        cargoXref (_type_): _description_

    Returns:
        _type_: _description_
    """
    id=-1
    try:
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_add_cargofactors_quote_xref(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", cargoXref.convert_to_tuple())
        dbConnection.execute(query)
        
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
                id=rows[0][0]
    except (Exception, psycopg2.DatabaseError) as error:
           id=-1
           print(error,"in cargo xref")
           
    return id

def add_insurance_application(submission,quote,vehicles):
    
    pass

def get_liability_broker_fee(limit):
        """_summary_

        Args:
            limit (_type_): _description_

        Returns:
            _type_: _description_
        """
        charges=0
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_broker_fee_liability_json(%s);", (limit,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
               charges=rows[0][0].get('charges')
                
            
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error,"broker fees")
           u_id=-1
        print(charges," liability")   
        return  charges
#udf_get_pd_broker_fee_json  
def get_pd_broker_fee(premium):
        """_summary_

        Args:
            premium (_type_): _description_

        Returns:
            _type_: _description_
        """
        charges=0
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_broker_fee_pd_json(%s);", (premium,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
               charges=rows[0][0].get('charges')
                
            
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
        return  charges



#udf_get_broker_fee_cargo_json

def get_cargo_broker_fee(premium):
        """_summary_

        Args:
            premium (_type_): _description_

        Returns:
            _type_: _description_
        """
        charges=0
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_broker_fee_cargo_json(%s);", (premium,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               charges=rows[0][0].get('charges')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error,"cargo broker fee")
           u_id=-1
           
        return  charges
def update_quote(quotedid,broker_fee_total,broker_fee_liability,broker_fee_pd,broker_fee_cargo,trailer_interchange,trailer_interchange_units,trailer_interchange_limit,trailer_interchange_premium):
        """_summary_

        Args:
            quotedid (_type_): _description_
            broker_fee_total (_type_): _description_
            broker_fee_liability (_type_): _description_
            broker_fee_pd (_type_): _description_
            broker_fee_cargo (_type_): _description_
            trailer_interchange (_type_): _description_
            trailer_interchange_units (_type_): _description_
            trailer_interchange_limit (_type_): _description_
            trailer_interchange_premium (_type_): _description_

        Returns:
            _type_: _description_
        """
        result='FAIL'
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_update_quote(%s,%s,%s,%s,%s,%s,%s,%s,%s);", (quotedid,
                                                                                                 broker_fee_total,
                                                                                                 broker_fee_liability,
                                                                                                 broker_fee_pd,
                                                                                                 broker_fee_cargo,
                                                                                                 trailer_interchange,trailer_interchange_units,trailer_interchange_limit,trailer_interchange_premium,))
            dbConnection.execute(query)
            
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           result='PASS'
           
        return  result 

def update_quote_all(quotedid,broker_fee_total,broker_fee_liability,broker_fee_pd,broker_fee_cargo,trailer_interchange,trailer_interchange_units,trailer_interchange_limit,trailer_interchange_premium,
                     hiredauto,hiredauto_cost,hiredauto_premium,nonownedauto_premium,surpluslinetax,
                     stampingfee,costofpackage,costofliability,costofpd,costofcargo,
                     ai_total_cost,endorsement,
                     losspayee_total_cost,primary_wording,pw_total_cost,
                     wos_total_cost,cargo_lte_cost,cargo_eggs_cost,cargo_riggers_cost,
                     cargo_ltem,cargo_eggs,cargo_riggers,firemarshall_tax,
                     subrogation_waiver):
        """_summary_

        Args:
            quotedid (_type_): _description_
            broker_fee_total (_type_): _description_
            broker_fee_liability (_type_): _description_
            broker_fee_pd (_type_): _description_
            broker_fee_cargo (_type_): _description_
            trailer_interchange (_type_): _description_
            trailer_interchange_units (_type_): _description_
            trailer_interchange_limit (_type_): _description_
            trailer_interchange_premium (_type_): _description_
            hiredauto (_type_): _description_
            hiredauto_cost (_type_): _description_
            hiredauto_premium (_type_): _description_
            nonownedauto_premium (_type_): _description_
            surpluslinetax (_type_): _description_
            stampingfee (_type_): _description_
            costofpackage (_type_): _description_
            costofliability (_type_): _description_
            costofpd (_type_): _description_
            costofcargo (_type_): _description_
            ai_total_cost (_type_): _description_
            endorsement (_type_): _description_
            losspayee_total_cost (_type_): _description_
            primary_wording (_type_): _description_
            pw_total_cost (_type_): _description_
            wos_total_cost (_type_): _description_
            cargo_lte_cost (_type_): _description_
            cargo_eggs_cost (_type_): _description_
            cargo_riggers_cost (_type_): _description_
            cargo_ltem (_type_): _description_
            cargo_eggs (_type_): _description_
            cargo_riggers (_type_): _description_
            firemarshall_tax (_type_): _description_
            subrogation_waiver (_type_): _description_

        Returns:
            _type_: _description_
        """
        result='FAIL'
        try:
           
            dbConnection= connections['default'].cursor()
           
            query= dbConnection.mogrify("select udf_update_quote_all(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", (quotedid,
                                                                                                 broker_fee_total,
                                                                                                 broker_fee_liability,
                                                                                                 broker_fee_pd,
                                                                                                 broker_fee_cargo,
                                                                                                 trailer_interchange,trailer_interchange_units,trailer_interchange_limit,trailer_interchange_premium,
                                                                                                 hiredauto,hiredauto_cost,hiredauto_premium,nonownedauto_premium,surpluslinetax,
                                                                                                 stampingfee,costofpackage,costofliability,costofpd,costofcargo,
                                                                                                 ai_total_cost,endorsement,
                                                                                                 losspayee_total_cost,primary_wording,pw_total_cost,
                                                                                                 wos_total_cost,cargo_lte_cost,cargo_eggs_cost,cargo_riggers_cost,
                                                                                                 cargo_ltem,cargo_eggs,cargo_riggers,firemarshall_tax,
                                                                                                 subrogation_waiver,
                                                                                                 ))
            dbConnection.execute(query)
            result='PASS'
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           
           
        return  result 

def get_liability_xref_factors(quotedid):
    """_summary_

    Args:
        quotedid (_type_): _description_

    Returns:
        _type_: _description_
    """
    result=[]
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_liabilityfactors_quote_xref(%s);", (quotedid,))
            dbConnection.execute(query)
            result=dbConnection.fetchall()
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
        pass
           
    return  result 
def get_pd_xref_factors(quotedid):
    """_summary_

    Args:
        quotedid (_type_): _description_

    Returns:
        _type_: _description_
    """
    result=[]
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_pdfactors_quote_xref(%s);", (quotedid,))
            dbConnection.execute(query)
            result=dbConnection.fetchall()
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
        pass
           
    return  result 

def get_cargo_xref_factors(quotedid):
    """_summary_

    Args:
        quotedid (_type_): _description_

    Returns:
        _type_: _description_
    """
    result=[]
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_cargofactors_quote_xref(%s);", (quotedid,))
            dbConnection.execute(query)
            result=dbConnection.fetchall()
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
        pass
           
    return  result 
def is_policy_number_available_db(_policy_number):
   
    is_avaliable='No'
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select is_policy_number_available(%s);", (_policy_number,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            print(rows[0]," count")
            if len(rows) > 0:
                if(rows[0][0]=='0'):
                    is_avaliable='Yes'
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
        pass
           
    return  is_avaliable
    
def get_quote_bind_info_db(_quote_id):
    result=[]
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_quote_bind_info(%s);", (_quote_id,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            if len(rows) > 0:
                for item in rows:
                    result.append(item[0])
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
        pass
           
    return  result

def update_quote_bind_info_db(_policy_number ,
_have_filings  ,
_filings_processed ,
_filings_processed_by ,
_all_documents_received  ,
_pending_documents ,
_documents_processed_by ,
_pending_docs_due_by ,
_bind_processed_byt,
_downpayment_received ,
_downpayment_amount ,
_is_financed ,
_finance_company_name  ,
_quote_id ):
    _id=-1
    try:
            print((_policy_number ,
_have_filings  ,
_filings_processed ,
_filings_processed_by ,
_all_documents_received  ,
_pending_documents ,
_documents_processed_by ,
_pending_docs_due_by ,
_bind_processed_byt,
_downpayment_received ,
_downpayment_amount ,
_is_financed ,
_finance_company_name  ,
_quote_id ))
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_update_quote_bind_info(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", (
              _policy_number ,
_have_filings  ,
_filings_processed ,
_filings_processed_by ,
_all_documents_received  ,
_pending_documents ,
_documents_processed_by ,
_pending_docs_due_by ,
_bind_processed_byt,
_downpayment_received ,
_downpayment_amount ,
_is_financed ,
_finance_company_name  ,
_quote_id  
	    ,)
 )
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            print(rows,"XXXXXXXXXX")  
            if len(rows)>0:
               _id=rows[0]
    
                
            
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error,"quote info  adding")
           _id=-1
           
    return  _id
    

def add_quote_bind_info_db(_policy_number ,
_have_filings  ,
_filings_processed ,
_filings_processed_by ,
_all_documents_received  ,
_pending_documents ,
_documents_processed_by ,
_pending_docs_due_by ,
_bind_processed_byt,
_downpayment_received ,
_downpayment_amount ,
_is_financed ,
_finance_company_name  ,
_quote_id ):
    _id=-1
    print(_policy_number ,
_have_filings  ,
_filings_processed ,
_filings_processed_by ,
_all_documents_received  ,
_pending_documents ,
_documents_processed_by ,
_pending_docs_due_by ,
_bind_processed_byt,
_downpayment_received ,
_downpayment_amount ,
_is_financed ,
_finance_company_name  ,
_quote_id )
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_add_quote_bind_info(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", (
              _policy_number ,
_have_filings  ,
_filings_processed ,
_filings_processed_by ,
_all_documents_received  ,
_pending_documents ,
_documents_processed_by ,
_pending_docs_due_by ,
_bind_processed_byt,
_downpayment_received ,
_downpayment_amount ,
_is_financed ,
_finance_company_name  ,
_quote_id  
	    ,)
 )
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
              
            if len(rows)>0:
               _id=rows[0]
    
                
            
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error,"quote info  adding")
           _id=-1
           
    return  _id
    
    

def get_quote_premium_by_quoteid_db(quotedid):
    """_summary_

    Args:
        quotedid (_type_): _description_

    Returns:
        _type_: _description_
    """
    result=[]
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_quote_premium_details_by_quote_id_json(%s);", (quotedid,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            if len(rows) > 0:
                for item in rows:
                    result.append(item[0])
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
        pass
           
    return  result

def get_drivers_by_quote_db(quotedid):
    """_summary_

    Args:
        quotedid (_type_): _description_

    Returns:
        _type_: _description_
    """
    result=[]
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_drivers_by_quoteid(%s);", (quotedid,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            if len(rows) > 0:
                for item in rows:
                    result.append(item[0])
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
        pass
           
    return  result

def get_vehicles_premium(quotedid):
    """_summary_

    Args:
        quotedid (_type_): _description_

    Returns:
        _type_: _description_
    """
    result=[]
    try:
            dbConnection= connections['default'].cursor()
            #query= dbConnection.mogrify("select udf_get_vehicles_premium_json(%s);", (quotedid,))
            query= dbConnection.mogrify("select udf_get_quote_vehicles_premium_json(%s);", (quotedid,))
            
            dbConnection.execute(query)
            result=dbConnection.fetchall()
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
        pass
           
    return  result
def get_agency_id_with_quote_id(_quote_id):
    agency={}
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_agency_id_from_with_quote_id(%s);", (_quote_id,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
               
                  agency=rows[0]
                
            
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error,"submission")
           u_id=-1
    print(agency)       
    return  agency
     
def get_submission_details_by_submission_id(submission_id):
        """_summary_

        Args:
            premium (_type_): _description_

        Returns:
            _type_: _description_
        """
        submission={}
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_ins_submission_by_id_json(%s);", (submission_id,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
               
                  submission=rows[0]
                
            
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error,"submission")
           u_id=-1
           
        return  submission

def get_quotes_by_submission_id(submission_id):
        """_summary_

        Args:
            premium (_type_): _description_

        Returns:
            _type_: _description_
        """
        quotes=[]
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_ins_quotes_json(%s);", (submission_id,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
               for sub in rows:
                   quotes.append(sub[0])
                
            
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error,"submissions")
           u_id=-1
           
        return  quotes

def get_submissions():
        """_summary_

        Args:
            premium (_type_): _description_

        Returns:
            _type_: _description_
        """
        submissions=[]
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_ins_submissions_json;", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
               for sub in rows:
                   submissions.append(sub[0])
                
            
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error,"submissions")
           u_id=-1
           
        return  submissions

def add_driver_violation(violation):
     """_summary_

    Args:
        violation (_type_): _description_
    """
     violation_id=-1
     try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_add_driver_violation(%s,%s,%s,%s);", (
                str(violation.quoteid) ,violation.violationdate,violation.violation,str(violation.quoteid)
	    ,)
 )
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
              
            if len(rows)>0:
               violation_id=rows[0][0]
                
            
           
        
     except (Exception, psycopg2.DatabaseError) as error:
           print(error,"violation adding")
           u_id=-1
           
     return  violation_id
 
#udf_remove_drivers

def remove_drivers(_quote_id):
    id=-1
    try:
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_remove_drivers(%s);",(_quote_id,))
        dbConnection.execute(query)
        rows=dbConnection.fetchall()
            
            
        if len(rows)>0:
            id=rows[0]
               
               
        
    except:
        id=-1
    return id        
    
def add_driver(driver):
     """_summary_

    Args:
        driver (_type_): _description_
    """
     driver_id=-1
     print("******** Adding Driver **********")
     try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_add_driver(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", (
                driver.name ,
	driver.dob ,
	driver.license_no ,
	str(driver.experience) ,
	driver.license_state ,
	driver.license_class_type ,
	driver.license_medical_exp ,
	driver.license_exp_date,
    str(driver.violation_points[0]),
    str(driver.factor),driver.quoteid,)
 )
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
               driver_id=rows[0][0]
                
            
           
        
     except (Exception, psycopg2.DatabaseError) as error:
           print("Error with driver .........")
           print(error,"driver adding")
           u_id=-1
           
     return  driver_id
def get_driver_violations_list():
     """_summary_

    Returns:
        _type_: _description_
    """
     violations=[]
     try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_driver_violations();",())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
               
               for dv in rows:
                violations.append(dv[0])   
                
            
           
        
     except (Exception, psycopg2.DatabaseError) as error:
           print(error,"driver violations")
           u_id=-1
           
     return  violations     

def get_quote_forms_list():
    """_summary_

    Returns:
        _type_: _description_
    """
    formslist=[]
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_quote_forms_json();",())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
               
               for frm in rows:
                formslist.append(frm[0])   
                
            
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
          
    #print(formslist)       
    return  formslist

def add_comp_lob_submission(_comp_id,_lob_id,_submission_id):
    """_summary_

    Args:
        cargoXref (_type_): _description_

    Returns:
        _type_: _description_
    """
    id=-1
    try:
        dbConnection= connections['default'].cursor()
        query= dbConnection.mogrify("select udf_add_comp_lob_submission(%s,%s,%s);", (_comp_id,_lob_id,_submission_id,))
        dbConnection.execute(query)
        
        rows=dbConnection.fetchall()
          
           
        if len(rows)>0:
                id=rows[0][0]
    except (Exception, psycopg2.DatabaseError) as error:
           id=-1
           print(error,"in cargo xref")
           
    return id


def get_all_agencies_users(_agency_id):
    dbConnection= connections['default'].cursor()
    user_list=[]
    print(type(_agency_id))
    try:
        query= dbConnection.execute("select udf_get_agency_users_json(%s);",(_agency_id,))
        rows=dbConnection.fetchall()
        print(rows)
            #formslist=rows
            
        if len(rows)>0:
                for frm in rows:
                  #print(type(frm[0]["quote_id"])," quote id......")  
                  
                        user_list.append(frm[0]) 
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    
    return user_list

def get_all_agencies_db():
    dbConnection= connections['default'].cursor()
    agency_list=[]
    try:
        query= dbConnection.execute("select udf_get_agencies_json();")
        rows=dbConnection.fetchall()
            #formslist=rows
            
        if len(rows)>0:
                for frm in rows:
                  #print(type(frm[0]["quote_id"])," quote id......")  
                  
                        agency_list.append(frm[0]) 
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    
    return agency_list
#udf_get_similar_quotes_by_insured_name_or_dotnumber

def get_all_quotes_similar_insured_name_and_dot_number(_quote_id):
    dbConnection= connections['default'].cursor()
    quotes_list=[]
    try:
        query= dbConnection.execute("select udf_get_similar_quotes_by_insured_name_or_dotnumber(%s);",(_quote_id,))
        rows=dbConnection.fetchall()
            #formslist=rows
            
        if len(rows)>0:
                for frm in rows:
                  #print(type(frm[0]["quote_id"])," quote id......")  
                  if frm[0]["quote_id"]!=int(_quote_id):  
                        quotes_list.append(frm[0]) 
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    #agency_details=get_agency_details_db(_agency_id)          
    return quotes_list
def get_all_quotes_of_agency_by_insured_name_and_dot_number(_agency_id,_insured_name,_dot_number,_quote_id):
    dbConnection= connections['default'].cursor()
    quotes_list=[]
    try:
        query= dbConnection.execute("select udf_get_similar_quotes_of_agency_by_insured_name_or_dotnumber(%s,%s,%s);",(_agency_id,_insured_name,_dot_number,))
        rows=dbConnection.fetchall()
            #formslist=rows
            
        if len(rows)>0:
                for frm in rows:
                  #print(type(frm[0]["quote_id"])," quote id......")  
                  if frm[0]["quote_id"]!=int(_quote_id):  
                        quotes_list.append(frm[0]) 
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    #agency_details=get_agency_details_db(_agency_id)          
    return quotes_list


def get_quote_forms_list():
    dbConnection= connections['default'].cursor()
    formslist=[]
    try:
            query= dbConnection.execute("select udf_get_quote_forms_json();",())
            rows=dbConnection.fetchall()
            #formslist=rows
            
            if len(rows)>0:
                for frm in rows:
                 formslist.append(frm[0])   
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close()
                
    return  formslist


def get_all_forms_list_db():
    dbConnection= connections['default'].cursor()
    formslist=[]
    try:
            query= dbConnection.execute("select udf_get_all_forms_json();",())
            rows=dbConnection.fetchall()
            formslist=rows
            # if len(rows)>0:
            #    for frm in rows:
            #     formslist.append(frm[0])   
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close()
    return  formslist

 
def add_forms_details_db(formdata):
       dbConnection= connections['default'].cursor()
       #cursor = dbConnection.cursor()
       #cursor = ps_connection.cursor()
       form_id=-1
       try:
            qry=dbConnection.mogrify ('select udf_quote_formcreation(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);' ,(formdata.form_name,
            formdata.form_edition,
            formdata.form_description,
            formdata.form_category,
            formdata.form_state,
            formdata.form_condition,
            formdata.form_type,
            formdata.form_active,
            formdata.mandatory,
            int(formdata.form_order),
            formdata.file_location,
            formdata.company_id,
            formdata.lob_id,
            ))         
            dbConnection.execute(qry)      
            #ps_connection.commit()
         #   dbConnection.commit()
            #print("Completed")   
            rows=dbConnection.fetchall()
            #print("Fetched")
            #len(rows)
            if len(rows)>0 :
                form_id=rows[0][0]
                if form_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
       except Exception as error:
           print(error)
           res="Internal Server Error"
       finally:
            dbConnection.close()         
       return  res 

def update_form_details_db(form_data):
    dbConnection = connections['default'].cursor()
    try:
        
        qry = dbConnection.mogrify(
            "select udf_update_form_master(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);",
            (
             form_data.form_name,
             form_data.form_edition,
             form_data.form_description,
             form_data.form_category,
             form_data.form_state,
             form_data.form_condition,
             form_data.form_type,
             form_data.form_active,
             form_data.mandatory,
             form_data.form_order,
             form_data.file_location,
             form_data.id
             )
        )

       # print(qry,' form_update')
        dbConnection.execute(qry)
        #dbConnection.commit()
        rows = dbConnection.fetchall()
        if len(rows) > 0:
            id = rows[0]
            res = "Form Updated Successfully"
        else:
            res = "Form Update Failed"
        data={"id":id,"Message":res}  
        print(data,' form')
        return data
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
            dbConnection.close()
    return "FAIL"


def update_uploaded_file_db(form_data):
    dbConnection = connections['default'].cursor()
    try:
        
        qry = dbConnection.mogrify(
            "select udf_upload_file(%s,%s);",
            (
             form_data.file_location,
             form_data.id
             )
        )

       # print(qry,' form_update')
        dbConnection.execute(qry)
        #dbConnection.commit()
        rows = dbConnection.fetchall()
        if len(rows) > 0:
            id = rows[0]
            res = "File Uploaded Successfully"
        else:
            res = "File Uploading Failed"
        data={"id":id,"Message":res}  
        print(data,' form')
        return data
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
            dbConnection.close()
    return "FAIL"


def set_active_form_status_db(_id):
    dbConnection = connections['default'].cursor()
    try:
        
        qry = dbConnection.mogrify(
            "select udf_set_form_master_status(%s);", (_id,)
        )

       # print(qry,' form_update')
        dbConnection.execute(qry)
        #dbConnection.commit()
        res="Form Deleted successfully"
        data={"Message":res} 
        return data
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
            dbConnection.close()
    return "FAIL"


def get_all_forms_master_ById_db(form_id):
    dbConnection= connections['default'].cursor()
    formslist=[]
    try:
            
            query= dbConnection.execute("select udf_get_form_master_byid_json(%s);",(form_id,))
            rows=dbConnection.fetchall()
            formslist=rows
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close()   
    return  formslist

#udf_remove_quote_premiums
def remove_quote_premiums(_quote_id):
    """_summary_

    Args:
        quotoinfo (_type_): _description_

    Returns:
        _type_: _description_
    """
    id=-1
    dbConnection= connections['default'].cursor()
    quote_premium_id=-1
    try:
            
            query= dbConnection.execute("select udf_remove_quote_premiums(%s);",(_quote_id,))
            rows=dbConnection.fetchall()
            if len(rows)>0:
                id=rows[0]
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return id  

def add_quote_premium(_quote_id, _class_of_business_id, _premium):
    """_summary_

    Args:
        quotoinfo (_type_): _description_

    Returns:
        _type_: _description_
    """
   
    dbConnection= connections['default'].cursor()
    quote_premium_id=-1
    try:
            
            query= dbConnection.execute("select udf_add_quote_premium(%s,%s,%s);",(_quote_id, _class_of_business_id, _premium,))
            rows=dbConnection.fetchall()
            if len(rows)>0:
                quote_premium_id=rows[0][0]
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return quote_premium_id  


def add_quote_data_premium_estimate_db(_quote_id, _quote_estimate_json,_quote_submit_data):
    """_summary_

    Args:
        quotoinfo (_type_): _description_

    Returns:
        _type_: _description_
    """
   
    dbConnection= connections['default'].cursor()
    quote_premium_id=-1
    try:
            
            query= dbConnection.execute("select udf_add_quotes_json_data(%s,%s,%s);",(_quote_id, _quote_estimate_json,_quote_submit_data,))
            rows=dbConnection.fetchall()
            if len(rows)>0:
                quote_premium_id=rows[0][0]
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return quote_premium_id  




def add_quote_premium_estimate_db(_quote_id, _quote_estimate_json,_quote_submit_data):
    """_summary_

    Args:
        quotoinfo (_type_): _description_

    Returns:
        _type_: _description_
    """
   
    dbConnection= connections['default'].cursor()
    quote_premium_id=-1
    try:
            
            query= dbConnection.execute("select udf_add_quote_history(%s,%s,%s);",(_quote_id, _quote_estimate_json,_quote_submit_data,))
            rows=dbConnection.fetchall()
            if len(rows)>0:
                quote_premium_id=rows[0][0]
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return quote_premium_id  




def add_quote_info(quotoinfo):
    """_summary_

    Args:
        quotoinfo (_type_): _description_

    Returns:
        _type_: _description_
    """
    qinfo=quotoinfo.convert_to_tuple()
    dbConnection= connections['default'].cursor()
    quote_id=-1
    try:
            
            query= dbConnection.execute("select udf_add_quote_with_submissionid(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);",qinfo)
            rows=dbConnection.fetchall()
            if len(rows)>0:
                quote_id=rows[0][0]
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return quote_id  

def add_insured_info(insured):
    """_summary_

    Args:
        insured (_type_): _description_
    """
    print(insured.convert_to_tuple())
    insured=insured.convert_to_tuple()
    dbConnection= connections['default'].cursor()
    app_id=-1
    try:
            
            query= dbConnection.execute("select udf_add_insured(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);",insured)
            rows=dbConnection.fetchall()
            if len(rows)>0:
                app_id=rows[0][0]
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return app_id  

def add_quote_application(app):
    """_summary_

    Args:
        app (_type_): _description_
    """
    appdata=app.convert_to_tuple()
    dbConnection= connections['default'].cursor()
    app_id=-1
    try:
            
            try:
                query= dbConnection.execute("select udf_add_quote_application(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);",appdata)
            except:
                pass
            rows=dbConnection.fetchall()
            if len(rows)>0:
                app_id=rows[0][0]
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return app_id  

def add_quote_commoditiy(commodities):
    """_summary_

    Args:
        commodity (_type_): _description_
    """
    dbConnection= connections['default'].cursor()
    commodity_count=0
    try:
            for cmd in commodities:    
                try:
                    query= dbConnection.execute("select udf_add_quote_commodity(%s);",(cmd,))
                    rows=dbConnection.fetchall()
                    if len(rows)>0:
                        commodity_count=commodity_count+1
                except:
                    pass
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return commodity_count 
    #udf_add_quote_commodity
    
def get_agency_details(userid):
    """_summary_

    Args:
        commodity (_type_): _description_
    """
    dbConnection= connections['default'].cursor()
    dict_agency_info={}
    try:
           # for cmd in commodities:    
                try:
                    query= dbConnection.execute("select udf_get_agency_details(%s);",(userid,))
                    rows=dbConnection.fetchall()
                    if len(rows)>0:
                        print(rows[0][0])
                        dict_agency_info=rows[0][0]
                except:
                    print("Error")
                    pass
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return dict_agency_info 

def get_quote_info_by_quoteid_db(quote_id):
    """_summary_

    Args:
        commodity (_type_): _description_
    """
    dbConnection= connections['default'].cursor()
    quote_info={}
    try:
           # for cmd in commodities:    
                try:
                    query= dbConnection.execute("select udf_get_quote_info_by_quoteid(%s);",(quote_id,))
                    rows=dbConnection.fetchall()
                    if len(rows)>0:
                        print(rows[0][0])
                        quote_info=rows[0][0]
                except:
                    print("Error")
                    pass
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    print(quote_info)
    return quote_info 

def get_quote_premium_info_by_quoteid(quote_id):
    """_summary_

    Args:
        commodity (_type_): _description_
    """
    dbConnection= connections['default'].cursor()
    premium_info={}
    try:
           # for cmd in commodities:    
                try:
                    query= dbConnection.execute("select udf_get_quote_premium_info_by_quoteid(%s);",(quote_id,))
                    rows=dbConnection.fetchall()
                    if len(rows)>0:
                        print(rows[0][0])
                        premium_info=rows[0][0]
                except:
                    print("Error")
                    pass
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return premium_info 

def app_type_related_data_of_quote(app_type_id):
    """
    

    Args:
        app_type_id (_type_): _description_
    """
    dbConnection= connections['default'].cursor()
    app_type_data={}
    try:
           # for cmd in commodities:    
                try:
                    query= dbConnection.execute("select udf_get_application_type_data_by_app_type_id(%s);",(app_id,))
                    rows=dbConnection.fetchall()
                    if len(rows)>0:
                        print(rows[0][0])
                        app_type_data=rows[0][0]
                except:
                    print("Error")
                    pass
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return app_type_data 
    
    
    
def get_app_type_info_by_app_type_id(app_id):
    """_summary_

    Args:
        commodity (_type_): _description_
    """
    dbConnection= connections['default'].cursor()
    app_type_info={}
    try:
           # for cmd in commodities:    
                try:
                    query= dbConnection.execute("select udf_get_app_type_info_by_app_type_id(%s);",(app_id,))
                    rows=dbConnection.fetchall()
                    if len(rows)>0:
                        print(rows[0][0])
                        app_type_info=rows[0][0]
                except:
                    print("Error")
                    pass
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return app_type_info 

def get_insured_info_by_quoteid(quote_id):
    """_summary_

    Args:
        commodity (_type_): _description_
    """
    dbConnection= connections['default'].cursor()
    insured_info={}
    try:
           # for cmd in commodities:    
                try:
                    query= dbConnection.execute("select udf_get_insured_info_by_quoteid(%s);",(quote_id,))
                    rows=dbConnection.fetchall()
                    if len(rows)>0:
                        print(rows[0][0])
                        insured_info=rows[0][0]
                except:
                    print("Error")
                    pass
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return insured_info 
#udf_get_agency_details_with_agency_user_id

def get_agency_info_by_userid(user_id):
    """_summary_

    Args:
        commodity (_type_): _description_
    """
    dbConnection= connections['default'].cursor()
    insured_info={}
    try:
              
                try:
                    query= dbConnection.execute("select udf_get_agency_details_with_agency_user_id(%s);",(user_id,))
                    rows=dbConnection.fetchall()
                    if len(rows)>0:
                        print(rows[0][0])
                        insured_info=rows[0][0]
                except:
                    print("Error")
                    pass
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return insured_info 

def get_quote_premium_details(submission_id):
    """_summary_

    Args:
        commodity (_type_): _description_
    """
    dbConnection= connections['default'].cursor()
    package_info=[]
    
    
    try:
              
                try:
                    query= dbConnection.execute("udf_get_quote_premium_info_by_quote_id(%s)",(submission_id,))
                    rows=dbConnection.fetchall()
                    if len(rows)>0:
                        for r in rows:
                            #print(rows[0][0])
                            #package_info=rows[0][0]
                            package_info.append(r[0])
                except:
                    print("Error")
                    pass
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return package_info 

def get_premium_details_with_class_id_by_quote(quote_id):
    """_summary_

    Args:
        commodity (_type_): _description_
    """
    dbConnection= connections['default'].cursor()
    quote_premium_info=[]
    
   
    try:
              
                try:
                    query= dbConnection.execute("select udf_get_quote_premium_info_by_quote_id(%s);",(quote_id,))
                    rows=dbConnection.fetchall()
                    if len(rows)>0:
                        for q in rows:
                        
                            print(rows[0][0])
                            #quote_premium_info=rows[0][0]
                            quote_premium_info.append(q[0])
                except:
                    print("Error")
                    pass
                                    
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close() 
    return quote_premium_info 


#udf_get_cargo_insurance_package_info_by_submissionid
#udf_get_liability_insurance_package_info_by_submissionid
#udf_get_pd_insurance_package_info_by_submissionid

#udf_get_quote_premium_info_by_quote_id