 #Liability premium static method    
from datetime import date
import datetime
from .models import *
from .quotedboperations import *
    
def calculate_liability_premium(base_rate,
                                territory_factor,
                                lcm_factor,
                                ilf_factor,
                                primary_factor,
                                pollution_factor,
                                state_factor,
                                rate_control_factor,
                                vehicle_type_factor,
                                radius_factor,
                                commodity_al_factor,
                                driver_factor,
                                loss_experience_factor,
                                 safer_factor,
                                 years_of_experience_factor,
                                 uw_credit_debit_factor,
                                 liability_factor,
                                 type_of_use_factor,
                                 secondary_class_factor,
                                 trailer_type_factor,
                                 ):
       """_summary_

    Args:
        base_rate (_type_): _description_
        territory_factor (_type_): _description_
        lcm_factor (_type_): _description_
        ilf_factor (_type_): _description_
        primary_factor (_type_): _description_
        pollution_factor (_type_): _description_
        state_factor (_type_): _description_
        rate_control_factor (_type_): _description_
        vehicle_type_factor (_type_): _description_
        radius_factor (_type_): _description_
        commodity_al_factor (_type_): _description_
        driver_factor (_type_): _description_
        loss_experience_factor (_type_): _description_
        safer_factor (_type_): _description_
        years_of_experience_factor (_type_): _description_
        uw_credit_debit_factor (_type_): _description_
        liability_factor (_type_): _description_
        type_of_use_factor (_type_): _description_
        secondary_class_factor (_type_): _description_
        trailer_type_factor (_type_): _description_

    Returns:
        _type_: _description_
    """
       try:
            
           
            if vehicle_type_factor==0:
                vehicle_type_factor=1
            liablity_premium= round((base_rate*territory_factor*lcm_factor*ilf_factor*
                                  pollution_factor*state_factor*rate_control_factor*
                                  vehicle_type_factor*radius_factor*
                                 commodity_al_factor*driver_factor*safer_factor*
                                 years_of_experience_factor*
                                 liability_factor*type_of_use_factor*
                                 secondary_class_factor*
                                 trailer_type_factor*primary_factor*
                                 uw_credit_debit_factor*loss_experience_factor),0) 
            return   liablity_premium
       except Exception as e:
           print(e," liability")
           return 0
  
    #PD premium static method
  
def calculate_pd_premium(stated_value,pd_base_rate_factor,pd_vehicle_make_factor,
                            pd_state_factor,driver_factor,pd_loss_experience_factor,pd_uw_credit_debit_factor
                           ,pd_deductible_factor,commodity_pd_factor,pd_years_of_experience,
                           pd_rate_control_factor,pd_safer_factor):
        """_summary_

    Args:
        stated_value (_type_): _description_
        pd_base_rate_factor (_type_): _description_
        pd_vehicle_make_factor (_type_): _description_
        pd_state_factor (_type_): _description_
        driver_factor (_type_): _description_
        pd_loss_experience_factor (_type_): _description_
        pd_uw_credit_debit_factor (_type_): _description_
        pd_deductible_factor (_type_): _description_
        commodity_pd_factor (_type_): _description_
        pd_years_of_experience (_type_): _description_
        pd_rate_control_factor (_type_): _description_
        pd_safer_factor (_type_): _description_

    Returns:
        _type_: _description_
    """
        
        try:
            print(round(stated_value*pd_base_rate_factor
            *pd_vehicle_make_factor 
            *pd_state_factor
            *driver_factor*pd_loss_experience_factor
            *pd_uw_credit_debit_factor
            *pd_deductible_factor
            *commodity_pd_factor
            *pd_years_of_experience
            *pd_rate_control_factor
            *pd_safer_factor ,0),"PD PPP")
            return round(stated_value*pd_base_rate_factor
            *pd_vehicle_make_factor 
            *pd_state_factor
            *driver_factor*pd_loss_experience_factor
            *pd_uw_credit_debit_factor
            *pd_deductible_factor
            *commodity_pd_factor
            *pd_years_of_experience
            *pd_rate_control_factor
            *pd_safer_factor ,0)
        except Exception as e:
            print(e+" pd")
            return 0
             
        
def calculate_trailer_interchange_premium(stated_value,
                                          pd_base_rate_factor,
                                          pd_vehicle_make_factor,
                            pd_state_factor,
                            driver_factor,
                            pd_loss_experience_factor,
                            pd_uw_credit_debit_factor
                           ,pd_deductible_factor,
                           commodity_pd_factor,
                           pd_years_of_experience,
                           pd_rate_control_factor,
                           pd_safer_factor,trailer_type_factor,containers_selected):
        """_summary_

    Args:
        stated_value (_type_): _description_
        pd_base_rate_factor (_type_): _description_
        pd_vehicle_make_factor (_type_): _description_
        pd_state_factor (_type_): _description_
        driver_factor (_type_): _description_
        pd_loss_experience_factor (_type_): _description_
        pd_uw_credit_debit_factor (_type_): _description_
        pd_deductible_factor (_type_): _description_
        commodity_pd_factor (_type_): _description_
        pd_years_of_experience (_type_): _description_
        pd_rate_control_factor (_type_): _description_
        pd_safer_factor (_type_): _description_
        trailer_type_factor (_type_): _description_
        containers_selected (_type_): _description_

    Returns:
        _type_: _description_
    """
        
        try:
            if containers_selected=='Yes':
                pd_base_rate_factor=0.035
            return round(stated_value*pd_base_rate_factor*pd_vehicle_make_factor
             
            *pd_state_factor
            *driver_factor*pd_loss_experience_factor
            *pd_uw_credit_debit_factor*pd_deductible_factor
            
            *commodity_pd_factor
            *pd_years_of_experience
            *pd_rate_control_factor
            *pd_safer_factor*
            trailer_type_factor,0)
        except Exception as e:
            print(e+" pd")
            return 0        
    
   
def calculate_cargo_premium(cargo_base_rate_factor,cargo_state_factor,driver_factor,
                              cargo_loss_experience_factor,cargo_uw_credit_debit_factor,
                             commodity_cargo_factor,years_of_experience_factor,
                            cargo_rate_control_factor,safer_factor,cargo_radius_factor,
                            cargo_limit_factor,cargo_deductible_factor,
                           cargo_refeer_deductible_factor ):
       """_summary_

    Args:
        cargo_base_rate_factor (_type_): _description_
        cargo_state_factor (_type_): _description_
        driver_factor (_type_): _description_
        cargo_loss_experience_factor (_type_): _description_
        cargo_uw_credit_debit_factor (_type_): _description_
        commodity_cargo_factor (_type_): _description_
        years_of_experience_factor (_type_): _description_
        cargo_rate_control_factor (_type_): _description_
        safer_factor (_type_): _description_
        cargo_radius_factor (_type_): _description_
        cargo_limit_factor (_type_): _description_
        cargo_deductible_factor (_type_): _description_
        cargo_refeer_deductible_factor (_type_): _description_

    Returns:
        _type_: _description_
    """
       try:
            print("cargo premium calculation part XXXX ********")
            return round(           
            cargo_base_rate_factor *cargo_state_factor 
        *driver_factor*cargo_loss_experience_factor
        *cargo_uw_credit_debit_factor
        
        *commodity_cargo_factor
        *years_of_experience_factor
        *cargo_rate_control_factor
        *safer_factor
        *cargo_radius_factor
        *cargo_limit_factor
        *cargo_deductible_factor
        *cargo_refeer_deductible_factor,0)
       except Exception as e:
           print("error in cargo calculation") 
           return 0

#### Liability Broker Fees #############       
def calculate_liability_broker_fees(vehicles):
    """_summary_

    Args:
        vehicles (_type_): _description_

    Returns:
        _type_: _description_
    """
    power_unit_count=0
    for v in vehicles:
        if v["model"]=='Truck' or v["model"]=='Tractor':
            power_unit_count=power_unit_count+1
    return get_liability_broker_fee(str(power_unit_count))

###### PD Broker FEES
def calculate_pd_broker_fees(premium):
    """_summary_

    Args:
        premium (_type_): _description_

    Returns:
        _type_: _description_
    """
    return get_pd_broker_fee(premium)

####### Cargo Broker fees
def calculate_cargo_broker_fees(premium):
    """_summary_

    Args:
        premium (_type_): _description_

    Returns:
        _type_: _description_
    """
    return get_cargo_broker_fee(premium)
def get_driver_score(violations):
    """_summary_

    Args:
        violations (_type_): _description_

    Returns:
        _type_: _description_
    """
    points=0
    for v in violations:
           
            s=v["violation"]
           
            
            points=points+get_driver_violation_points(s)
           
    return points
    
def calculate_driver_factor(class_a,class_a_years_of_exp,lic_state,age,violations):
    """_summary_

    Args:
        class_a (_type_): _description_
        class_a_years_of_exp (_type_): _description_
        lic_state (_type_): _description_
        age (_type_): _description_
        violations (_type_): _description_

    Returns:
        _type_: _description_
    """
    sec1=1
    sec2=1
    sec3=1
    sec4=1
    points=0
    try:
        if class_a =='Class A':
            if int(class_a_years_of_exp)<1:
                sec1=1.75
            elif int(class_a_years_of_exp)>=1 and int(class_a_years_of_exp)<2:
                sec1=1.2
            
        if lic_state=='NY':
            sec2=1.25
        if age<22:
            sec3=1.5
        elif age>=22 and age<25:
            sec3=1.25
        elif age>65 and age<=68:
            sec3=1.25
        elif age>=68:
            sec3=1.5
         
        for v in violations["data"]:
           
            s=v["violation"]
            
            points=points+get_driver_violation_points(v["violation"])
        if points < 1:
            sec4=1
        elif points==2:
            sec4=1.05
        elif points==3:
            sec4=1.25
        elif points==4:
            sec4=1.4
        elif points==5:
            sec4=1.55
        elif points==6:
            sec4=1.75
        elif points >=7 :
            sec4=1.95
        
            
        
        if points==0:
            points=1
    except Exception as error:
        print("Erroe in ",error)
    driver_factor=sec1*sec2*sec3*sec4 
   
    return {"points":points,"factor": driver_factor}  

def calculateAge(dob):
    """_summary_

    Args:
        dob (_type_): _description_

    Returns:
        _type_: _description_
    """
    
    parts=dob.split("/")
    dt=datetime.date(int(parts[2]), int(parts[0]), int(parts[1]))
    today = date.today()
    age = today.year - dt.year
    if today.month < dt.month or (today.month == dt.month and today.day < dt.day):
        age -= 1
    return age

   
     
# Driver code

        
        
        
    
    
    
