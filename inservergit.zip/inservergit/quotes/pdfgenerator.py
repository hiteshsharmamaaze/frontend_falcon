import json
import sys
#from tkinter import FLAT
import uuid

from django.conf import settings
from fpdf import FPDF
from reportlab.lib import colors  
from reportlab.lib.pagesizes import letter, inch  
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle  
import PyPDF2
from PyPDF2.generic import BooleanObject, NameObject, IndirectObject

import os
from uuid import *
class BytesEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, bytes):
            return obj.decode('utf-8')
        return json.JSONEncoder.default(self, obj)

def combine_pdf(insuredInfo,forms_info,garaging_state,um,uim,pip,pw_endorsements,ws_endorsements,ai_endorsements,lp_endorsements,drivers,vehicles,file_path,out_put_file,template_path):
    #print("in pdf")
    #print(insuredInfo,forms_info,garaging_state,um,uim,pip,pw_endorsements,ws_endorsements,ai_endorsements,lp_endorsements,drivers,vehicles,file_path,out_put_file,template_path," data")
    
    
    lst_forms_to_be_added_in_pdf=[]
    pdfWriter = PyPDF2.PdfFileWriter()
    pdfOutPutFile=file_path+out_put_file
    merge_status=False
    #print(template_path)
    page_no=0
    #print(uim,pip,' uim pip')
    try:
        for form_dict in forms_info:
            #print('***-----***',form_dict['form_condition'],form_dict['form_name'],form_dict['form_state'])
            er=""
            #print(form_dict," form dictionary")
            #print("pdf gen")
            merge_status=False
            #print(type(form_dict['form_condition'])," form data type")
            #print(garaging_state.upper() in form_dict['form_state'],garaging_state)
            #print(form_dict['form_name'])
            #pdf1File=""
           
            pdf1File=template_path+form_dict['form_name'].replace('/','_')+".pdf"
           
            print(pdf1File)
            #merge_status=True
            
            if form_dict['form_condition'].strip()!='':
                #print(form_dict['form_condition']," form condition not empty")
                if form_dict['form_condition'].strip()=='1':
                    if pw_endorsements>0 or ws_endorsements>0 or ai_endorsements >0 or lp_endorsements>0 :
                        merge_status=True
                    else:
                        merge_status=False
                
                
                elif form_dict['form_condition'].strip()=='2' and  garaging_state.upper().strip()==form_dict['form_state']:
                    #print(um,"Um selected",garaging_state)
                    #if  garaging_state.upper().strip()=='CA': 
                        
                        if um !='No':
                            merge_status=True 
                        else:  
                            merge_status=False 
                    #else:
                        #merge_status=False
                elif form_dict['form_condition'].strip()=='3' and garaging_state.upper() in form_dict['form_state'] : 
                    print(garaging_state)
                    #pdf1File=pdf1File.replace('/','_')
                    
                    if uim!='No' or pip!='No':
                        merge_status=True 
                    else :
                        #if merge_status!=True:
                          merge_status=False
            #pdf1File=pdf1File.replace('/','_')
                
            else:
                    #print(form_dict['form_condition'],' form cond')
                    if form_dict['form_state']==garaging_state.upper() or form_dict['form_state']=='ALL':
                        merge_status=True     
            #print(merge_status) 
           
            print(pdf1File," Merge status ",merge_status)
            if merge_status==True:
                #print(pdf1File)
                
                if( 'SSIC QUOTE VEH SCH' not in pdf1File):
                        if('SSIC TRUCKING QUOTE' not in pdf1File):
                            pdfInput=PyPDF2.PdfFileReader(pdf1File)
                            if('SSIC QUOTE DRV SCH' in pdf1File ):
                                pdf1File=create_drivers_pdf(drivers,file_path)
                        else:#('SSIC TRUCKING QUOTE'  in pdf1File):
                                #print("################")
                                #print("SSIC TRUCKING QUOTE ------- ### matching")
                                pdf1File=create_geninfo_pdf(insuredInfo,file_path)
                else:
                    #print('Vehicles schedule')
                    #print(file_path)
                    pdf1File=create_vehicles_pdf(vehicles,file_path)
                    #print(pdf1File)
                try:
                    pdfInput=PyPDF2.PdfFileReader(pdf1File)
                except:
                    print("error with ",pdf1File)
                    continue
                #print(pdfInput.numPages)
                
                for pageNum in range(pdfInput.numPages):
                        page_no=page_no+1
                    #print(page_no)
                        pageObj = pdfInput.getPage(pageNum)
                                    
                        pdfWriter.addPage(pageObj)
                        #print(form_dict['form_name'])
                        if form_dict['form_name']=="SSIC TRUCKING QUOTE":
                            #print("SSIC.........")
                            #print(dir(pageObj))
                            pass
                            #fields=pageObj.getfields()
                            #print(fields," acro .....")
                            # pdfWriter["/Root"]["/AcroForm"].update(
                            # {NameObject("/NeedAppearances"): True})
                            # pdfWriter.updatePageFormFieldValues(
                            # pdfWriter.getPage(page_no-1), {"insured_name": insuredInfo['insured_name']}
                       #)
                      
                        
                        
                        
                       
                    
            
                print(file_path+'/'+out_put_file, " pdf file path")
                pdfOutFile=open(file_path+'/'+out_put_file,"wb")
                pdfWriter.write(pdfOutFile)
        
                pdfOutFile.close();
        #pdfWriter
    except Exception as e:
        exception_type, exception_object, exception_traceback = sys.exc_info()
        filename = exception_traceback.tb_frame.f_code.co_filename
        line_number = exception_traceback.tb_lineno
        print(line_number," exception in pdf generation",exception_object)
        print(e.__str__) 
                 
            
                              
                
            
            
        
        
def create_vehicles_pdf(vehicles,file_path):
        file_name=str(uuid.uuid1())+".pdf"
        print(vehicles)
        print(file_path+file_name)
        pdf = FPDF('P', 'mm', 'A4')
        pdf.add_page()
        pdf.set_margins(5, 5, 5)
        pdf.set_font('Arial', 'B', 14)
        #pdf.cell(pdf.width/2-6)
       
        #pdf.set_xy(168,12)
        
        pdf.cell(180, 10, 'Vehicles Schedule', 0, 0, 'C')
        pdf.set_font('Arial', '', 10)
        y=25
        x=10
        pdf.set_xy(x,y)
        pdf.cell(30,8,"YEAR", 0, 0, 'L')
        pdf.set_xy(x+20,y)
        pdf.cell(30,8,"MAKE", 0, 0, 'L')
        pdf.set_xy(x+50,y)
        pdf.cell(30,8,"MODEL", 0, 0, 'L')
        pdf.set_xy(x+80,y)
        pdf.cell(30,8,"WEIGHT", 0, 0, 'L')
        pdf.set_xy(x+110,y)
        pdf.cell(30,8,"VIN", 0, 0, 'L')
        pdf.set_xy(x+130,y)
        pdf.cell(30,8,"STD.VAL", 0, 0, 'L')
        pdf.set_xy(x+150,y)
        pdf.cell(30,8,"DED", 0, 0, 'L')
        pdf.set_xy(x+170,y)
        pdf.cell(30,8,"O/L/RENT", 0, 0, 'L')
        #y=y+5
        for v in vehicles:
            print(v)
            y=y+5
            pdf.set_xy(x,y)
            pdf.cell(30,14,v["year"], 0, 0, 'L')
            pdf.set_xy(x+20,y)
            pdf.cell(30,14,v["make"], 0, 0, 'L')
            pdf.set_xy(x+50,y)
            pdf.cell(30,14,v["model"], 0, 0, 'L')
            pdf.set_xy(x+80,y)
            pdf.cell(30,14,v["weight"], 0, 0, 'L')
            pdf.set_xy(x+110,y)
            pdf.cell(30,14,v["vin"], 0, 0, 'L')
            pdf.set_xy(x+130,y)
            pdf.cell(30,14,v["stated_value"], 0, 0, 'L')
            pdf.set_xy(x+150,y)
            pdf.cell(30,14,v["deductible"], 0, 0, 'L')
            pdf.set_xy(x+170,y)
            pdf.cell(30,14,v["o_l_rent"], 0, 0, 'L')
            #print(v[0])
        pdf.output(file_path+file_name, 'F')
        pdf.close()   
        
        return file_path+file_name 
            

def create_drivers_pdf(drivers,file_path):
        file_name=str(uuid.uuid1())+".pdf"
        #print(vehicles)
        print(file_path+file_name)
        pdf = FPDF('P', 'mm', 'A4')
        pdf.add_page()
        pdf.set_margins(5, 5, 5)
        pdf.set_font('Arial', 'B', 14)
        #pdf.cell(pdf.width/2-6)
       
        #pdf.set_xy(168,12)
        
        pdf.cell(180, 10, 'Driver Schedule', 0, 0, 'C')
        pdf.set_font('Arial', '', 10)
        y=16
        x=10
        pdf.set_xy(x,y)
        pdf.cell(30,8,"NAME", 0, 0, 'L')
        pdf.set_xy(x+30,y)
        pdf.cell(30,8,"DOB", 0, 0, 'L')
        pdf.set_xy(x+60,y)
        pdf.cell(30,8,"LICENSE #", 0, 0, 'L')
        pdf.set_xy(x+90,y)
        pdf.cell(30,8,"YRS. EXP", 0, 0, 'L')
        pdf.set_xy(x+120,y)
        pdf.cell(30,8,"LIC STATE", 0, 0, 'L')
        pdf.set_xy(x+150,y)
        pdf.cell(30,8,"LIC CLASS", 0, 0, 'L')
        pdf.set_xy(x+180,y)
        pdf.cell(30,8,"MED EXP", 0, 0, 'L')
        y=10
        for v in drivers:
            #print(v)
            y=y+10
            pdf.set_xy(x,y)
            pdf.cell(30,14,v["name"], 0, 0, 'L')
            pdf.set_xy(x+30,y)
            pdf.cell(30,14,v["dob"], 0, 0, 'L')
            pdf.set_xy(x+60,y)
            pdf.cell(30,14,v["licenseno"], 0, 0, 'L')
            pdf.set_xy(x+90,y)
            pdf.cell(30,14,v["experience"], 0, 0, 'L')
            pdf.set_xy(x+120,y)
            pdf.cell(30,14,v["licensestate"], 0, 0, 'L')
            pdf.set_xy(x+150,y)
            pdf.cell(30,14,v["licenseclasstype"], 0, 0, 'L')
            pdf.set_xy(x+180,y)
            pdf.cell(30,14,v["licensemedicalexp"], 0, 0, 'L')
            #print(v[0])
        pdf.output(file_path+file_name, 'F')
        pdf.close()   
        
        return file_path+file_name              

def create_geninfo_pdf(insured_information,file_path):
    file_name=file_path+str(uuid.uuid1())+".pdf"
    #print(gross_premium)
    try:
        pdf = FPDF('P', 'mm', 'A4')
        pdf.add_page()
        pdf.set_margins(5, 5, 5)
        pdf.set_font('Arial', 'B', 14)
        #pdf.cell(pdf.width/2-6)
        #print(insured_information["insured_name"])
        #pdf.set_xy(168,12)
        
        pdf.cell(180, 10, 'Insured Information', 0, 0, 'C')
        #pdf.cell(pdf.width/2)
        pdf.set_font('Arial', '', 10)
        pdf.set_xy(10,16)
        pdf.cell(30,14,"Insured Name:", 0, 0, 'L')
        pdf.set_xy(60,16)
        pdf.cell(40,14,insured_information["insured_name"], 0, 0, 'L')
        # pdf.set_xy(100,16)
        # pdf.cell(40,14,"Effective Date:", 0, 0, 'L')
        # pdf.set_xy(140,16)
        # pdf.cell(40,14,insured_information["effective_date"], 0, 0, 'L')
        # pdf.set_xy(10,30)
        # pdf.cell(30,14,"Garaging Address:", 0, 0, 'L')
        # pdf.set_xy(60,30)
        # pdf.cell(40,14,insured_information["insured_garaging_address"], 0, 0, 'L')
        # pdf.set_xy(100,30)
        # pdf.cell(40,14,"Expiration Date:", 0, 0, 'L')
        # pdf.set_xy(140,30)
        # pdf.cell(40,14,insured_information["expiration_date"], 0, 0, 'L')
        
        # pdf.set_xy(10,44)
        # pdf.cell(30,14,"Garaging City:", 0, 0, 'L')
        # pdf.set_xy(60,44)
        # pdf.cell(40,14,insured_information["insured_garaging_city"], 0, 0, 'L')
        # pdf.set_xy(100,44)
        # pdf.cell(40,14,"Years of Experience:", 0, 0, 'L')
        # pdf.set_xy(140,44)
        # pdf.cell(40,14,insured_information["years_of_experience"], 0, 0, 'L')
        
        # pdf.set_xy(10,58)
        # pdf.cell(30,14,"Garaging State:", 0, 0, 'L')
        # pdf.set_xy(60,58)
        # pdf.cell(40,14,insured_information["insured_garaging_state"], 0, 0, 'L')
        # pdf.set_xy(10,72)
        # pdf.cell(40,14,"Garaging Zip:", 0, 0, 'L')
        # pdf.set_xy(60,72)
        # pdf.cell(40,14,insured_information["insured_garazing_zip"], 0, 0, 'L')
        # pdf.line(1,90,540,90)
        #pdf.set_xy(10,92)
        #pdf.set_font('Arial', 'B', 14)
        #pdf.cell(30,14,"Premium Breakdown", 0, 0, 'L')
        #pdf.set_font('Arial', '', 10)
        #pdf.set_xy(10,110)
        #************** Table Header **************
        #pdf.cell(15,14,"LIABILITY", 0, 0, 'L')
        #pdf.set_xy(30,110)
        #pdf.cell(15,14,"UM", 0, 0, 'L')
        #pdf.set_xy(50,110)
        #pdf.cell(15,14,"UIM", 0, 0, 'L')
        #pdf.set_xy(70,110)
        #pdf.cell(15,14,"PIP", 0, 0, 'L')
        #pdf.set_xy(90,110)
        #pdf.cell(15,14,"MED", 0, 0, 'L')
        #pdf.set_xy(110,110)
        #pdf.cell(15,14,"PD", 0, 0, 'L')
        #pdf.set_xy(130,110)
        #pdf.cell(15,14,"TOW", 0, 0, 'L')
        #pdf.set_xy(150,110)
        #pdf.cell(15,14,"CARGO", 0, 0, 'L')
        #************** End of table header ************
        #pdf.set_xy(10,126)
        #pdf.cell(15,14,'$'+str(gross_premium["liability"]), 0, 0, 'R')
        #pdf.set_xy(30,126)
        #pdf.cell(15,14,'$'+str(gross_premium["um"]), 0, 0, 'R')
        #pdf.set_xy(50,126)
        #pdf.cell(15,14,'$'+str(gross_premium["uim"]), 0, 0, 'R')
        #pdf.set_xy(70,126)
        #pdf.cell(15,14,'$'+str(gross_premium["pip"]), 0, 0, 'R')
        #pdf.set_xy(90,126)
        #pdf.cell(15,14,'$'+str(gross_premium["med"]), 0, 0, 'R')
        #pdf.set_xy(110,126)
        #pdf.cell(15,14,'$'+str(gross_premium["pd"]), 0, 0, 'R')
        #pdf.set_xy(130,126)
        #pdf.cell(15,14,'$'+str(gross_premium["tow"]), 0, 0, 'R')
        #pdf.set_xy(150,126)
        #pdf.cell(15,14,'$'+str(gross_premium["cargo"]), 0, 0, 'R')
        
        
        
        pdf.output(file_name, 'F')
        pdf.close()
    except Exception as e:
        exception_type, exception_object, exception_traceback = sys.exc_info()
        filename = exception_traceback.tb_frame.f_code.co_filename
        line_number = exception_traceback.tb_lineno
        print(line_number)
        print(e.__str__)
    return file_name


def create_premium_document(liability_factors,pd_factors,cargo_factors,premiums,premiumtotals):
   
    file_name=uuid.uuid1()+".pdf"
    print(file_name)
    #full_filename = os.path.join(settings.MEDIA_ROOT, file_name+".pdf")
    #print(full_filename)
   
    #lf=liability_factors[0]
    #print(liability_factors)
    my_doc = SimpleDocTemplate(file_name, pagesize = letter)
    liability_factors=[
        ['Base Rate',liability_factors[0].get("base_rate")],
         ['Commodity',liability_factors[0].get("commodity_al_factor")],
         ['Driver',liability_factors[0].get("driver_factor")],
         ['ILF',liability_factors[0].get("ilf_factor")],
         ['LCM',liability_factors[0].get("lcm_factor")],
          ['Liability',liability_factors[0].get("liability_factor")],
          ['UW Debit Credit',liability_factors[0].get("loss_experience_factor")],
          ['Trailer Type',liability_factors[0].get("uw_credit_debit_factor")],
          ['Pollution',liability_factors[0].get("pollution_factor")],
           ['Primary',liability_factors[0].get("primary_factor")],
           ['Radius',liability_factors[0].get("radius_factor")],
           ['Rate Control',liability_factors[0].get("radius_factor")],
        ['Safer',liability_factors[0].get("safer_factor")],
        ['Secondary',liability_factors[0].get("secondary_class_factor")],
         ['State',liability_factors[0].get("state_factor")],
         ['Territory',liability_factors[0].get("territory_factor")],
          ['Trailer Type',liability_factors[0].get("trailer_type_factor")]
        
        
    ]
    my_table = Table(liability_factors, 1 * [1.6 * inch], 5 * [0.5 * inch])  
# setting up style and alignments of borders and grids  
    my_obj = []  
    my_table.setStyle(  
    TableStyle(  
       [  
           ("ALIGN", (1, 1), (0, 0), "LEFT"),  
           ("VALIGN", (-1, -1), (-1, -1), "TOP"),  
           ("ALIGN", (-1, -1), (-1, -1), "RIGHT"),  
           ("VALIGN", (-1, -1), (-1, -1), "TOP"),  
           ("INNERGRID", (0, 0), (-1, -1), 1, colors.black),  
           ("BOX", (0, 0), (-1, -1), 2, colors.black),  
       ]  
   )  
)  
    my_obj.append(my_table) 
    return file_name+".pdf"
      