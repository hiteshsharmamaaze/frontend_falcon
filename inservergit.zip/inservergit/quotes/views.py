from os import name
import sys
from fpdf import FPDF 

from django.conf import settings
from time import strptime
from django.shortcuts import render
from django.shortcuts import render
from django.template import Context, loader
from rest_framework import generics
from .models import *
import datetime
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.core import serializers
from rest_framework.parsers import JSONParser
from django.http import HttpResponse
import json
from datetime import datetime
from django.http import JsonResponse
from fpdf import FPDF 
from .pdfgenerator import *
import json.decoder

from django.conf import settings
from django.core.files import File
from django.http import FileResponse
import uuid
import base64

from datetime import datetime
#from .liabilitypremium import get_base_rate_and_territory_factor,get_ilf_factor,get_lcm_factor,get_pollution_factor
#from .liabilitypremium import get_state_factor,get_rate_control_factor,get_vehicle_type_factor

# Create your views here.
from .quotedboperations import *
from .premiumcalculation import *
from adminapp.dboperations import *


""" GetCityandState
    Parameter : request
    request receives zipcode json data, zipcode is key and appropriate value

Returns:
        Json response with garaging state and city
"""
@api_view(['POST'])
def get_city_and_state(request):
    data = json.loads(request.body.decode("utf-8"))
    zipcode=data["zipcode"]
    
    
    data= get_state_city_by_zipcode(zipcode)
   
    
    res={"state": data.get('state_garging'),"city":data.get('state_city')}  
   
     
    return   Response(res, status=status.HTTP_200_OK)


@api_view(['POST'])
def get_companies_by_lob(request):
    data = json.loads(request.body.decode("utf-8"))
    
    lob_id=data["lob_id"]
   
    res = get_copmanys_by_lob_id(lob_id)
    #print(res)
    
   
    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)

#get_db_get_coverages_info_by_quoteid

@api_view(['POST'])
def get_quote_info_by_quoteid(request):
    data = json.loads(request.body.decode("utf-8"))
    
    quote_id=data["quote_id"]
    #print(type(quote_id), "quote id")
   
    res = get_quote_info_by_quoteid_db(quote_id)
    print("##########################")
    #print(res)
    print("##########################")
   
    data = {"result": res[0]}

    return Response(data, status=status.HTTP_200_OK)






@api_view(['POST'])
def get_coverages_info_quote(request):
    data = json.loads(request.body.decode("utf-8"))
    
    quote_id=data["quote_id"]
   
    res = get_db_get_coverages_info_by_quoteid(quote_id)
    print("##########################")
    #print(res)
    print("##########################")
   
    data = {"result": res[0]}

    return Response(data, status=status.HTTP_200_OK)


@api_view(['POST'])
def get_gen_info_of_submission(request):
    data = json.loads(request.body.decode("utf-8"))
    
    quote_id=data["quote_id"]
   
    res = get_db_general_info_by_quoteid(quote_id)

    #print(res[0]," genifo 124")
   
    data = {"result": res[0]}

    return Response(data, status=status.HTTP_200_OK)

@api_view(['POST'])
def get_ins_insured_info_by_quote_id(request):
    data = json.loads(request.body.decode("utf-8"))
    
    quote_id=data["quote_id"]
   
    res = get_db_ins_insured_info_by_quote_id(quote_id)

    
   
    data = {"result": res[0]}

    return Response(data, status=status.HTTP_200_OK)

@api_view(['POST'])
def get_vehicles_by_quote_id(request):
    data = json.loads(request.body.decode("utf-8"))
    
    quote_id=data["quote_id"]
    res = get_vehicles_by_quote_id_db(quote_id)

    #print(res)

    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)

@api_view(['POST'])
def get_quote_info_by_quoteid(request):
    data = json.loads(request.body.decode("utf-8"))
    
    quote_id=data["quote_id"]
    print(type(quote_id)," quote id")
    #res = get_quote_bind_info(quote_id)
    #get_quote_info_by_quoteid
    res = get_quote_info_by_quoteid_db(quote_id)
    #print(res)

    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)


@api_view(['POST'])
def add_quote_bind_info(request):
    data = json.loads(request.body.decode("utf-8"))
    bindInfo=bindInfo["bindInfo"]
    _quote_id=data["quote_id"]
    _policy_number=bindInfo["policy_number"]
    _have_filings=bindInfo["have_filings"]
    _filings_processed=bindInfo["filings_processed"]
    _filings_processed_by=bindInfo["filings_processed_by"]
    _all_documents_received=bindInfo["all_documents_received"]
    _pending_documents=bindInfo["pending_documents"]
    _documents_processed_by=bindInfo["documents_processed_by"]
    _pending_docs_due_by=bindInfo["pending_docs_due_by"]
    _bind_processed_by=bindInfo["bind_processed_by"]
    _downpayment_received=bindInfo["downpayment_received"]
    _downpayment_amount=bindInfo["downpayment_amount"]
    _is_financed=bindInfo["is_financed"]
    _finance_company_name=bindInfo["finance_company_name"]

    res = get_quote_premium_by_quoteid_db(_policy_number ,
_have_filings  ,
_filings_processed ,
_filings_processed_by ,
_all_documents_received  ,
_pending_documents ,
_documents_processed_by ,
_pending_docs_due_by ,
_bind_processed_by,
_downpayment_received ,
_downpayment_amount ,
_is_financed ,
_finance_company_name  ,
_quote_id)
    result="FAILURE"
    if res>-1:
        result="SUCCESS"
            

    #print(res)
    #print(res," quote premium")
    data = {"result": result}

    return Response(data, status=status.HTTP_200_OK)

@api_view(['POST'])
def get_quote_premiums_by_quote_id(request):
    data = json.loads(request.body.decode("utf-8"))
    
    quote_id=data["quote_id"]
    res = get_quote_premium_by_quoteid_db(quote_id)

    
    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)



#get_drivers_by_quote
@api_view(['POST'])
def get_drivers_by_quote_id(request):
    data = json.loads(request.body.decode("utf-8"))
    
    quote_id=data["quote_id"]
    res = get_drivers_by_quote_db(quote_id)

    #print(res)
    #print(res," Drivers")
    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)
#get_all_quotes_of_submission
@api_view(['POST'])
def get_all_quotesof_submission(request):
    data = json.loads(request.body.decode("utf-8"))
    
    submission_id=data["submission_id"]
    res = get_all_quotes_of_submission_db(submission_id)

    #print(res)

    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)
#sridhar@varadasoftwaresolutions.com,admin@varadasoftwaresolutions.com
@api_view(['POST'])
def get_submissions_by_quote_id(request):
    data = json.loads(request.body.decode("utf-8"))
    
    quote_id=data["quote_id"]
    res = get_submission_details_by_quote_id(quote_id)

    #print(res)

    data = {"result": res[0]}

    return Response(data, status=status.HTTP_200_OK)

@api_view(['POST'])
def get_quotes_by_underwriter_id(request):
    data = json.loads(request.body.decode("utf-8"))
    
    user_id=data["user_id"]
    res = get_all_quotes_by_underwriter_id(user_id)

    #print(res)

    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def get_all_quote_status(request):
    
    
    #agency_id=data["agency_id"]
    res = get_all_quote_status_db()

    #print(res)

    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def get_all_non_agency_users(request):
    
    
    #agency_id=data["agency_id"]
    res = get_all_non_agency_users_db()

    #print(res)

    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)

@api_view(['GET'])
def get_all_underwriters(request):
    
    
    #agency_id=data["agency_id"]
    res = get_all_underwriters_db()

    #print(res)

    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)
#get_underwriter_by_agency_id_db
@api_view(['POST'])
def get_underwriter_by_agency_id(request):
    data = json.loads(request.body.decode("utf-8"))
    
    agency_id=data["agency_id"]
    res = get_underwriter_by_agency_id_db(agency_id)

    #print(res)

    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)
#get_queue_statuses_db
@api_view(['GET'])
def get_queue_statuses(request):
    #data = json.loads(request.body.decode("utf-8"))
    
   
    res = get_queue_statuses_db()

    
    #print(res," quote stauses ")
    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)


@api_view(['POST'])
def get_quotes_by_agency_id(request):
    data = json.loads(request.body.decode("utf-8"))
    
    agency_id=data["agency_id"]
    res = get_all_quotes_by_agency_id(agency_id)

    #print(res)

    data = {"result": res}

    return Response(data, status=status.HTTP_200_OK)
    
def get_quotes_by_submissionid(request):
    """_summary_

    Args:
        request HttpRequest: HttpRequest object
        id (integer): submission id

    Returns:
        list<dict>: returns list of submissions
    """

    data = json.loads(request.body.decode("utf-8"))
    
    submission_id=data["submission_id"]
    res = get_quotes_by_submissionid_db(submission_id)

   

    data = {"message": res}

    return Response(data, status=status.HTTP_200_OK)

###### To get quote forms
@api_view(['GET'])
def get_quote_forms(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    _forms= get_quote_forms_list();
    res={"forms":_forms}
    return   Response(res, status=status.HTTP_200_OK)

@api_view(['POST'])
def get_um_status(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    _state=data["insured_garaging_state"]
    #print(_state)
   
    res={"status":get_um_range_per_state(_state)}
    return   Response(res, status=status.HTTP_200_OK)

@api_view(['POST'])
def get_agency_deatils_by_quoteid(request):
    data=json.loads(request.body.decode("utf-8"))
    quote_id=data['quote_id']
    agency_id=get_agency_id_with_quote_id(quote_id)[0]["agency_id"]
    agency=get_agency_details_db(agency_id)
    res={"agency":agency}
    
    return   Response(res, status=status.HTTP_200_OK)


@api_view(['POST'])
def get_similar_quotes_for_underwriter(request):
    print("In .......")
    data=json.loads(request.body.decode("utf-8"))
    print(data," json data")
    quote_id=data['quote_id']
    print("#####################################")
    print(quote_id," from fe")
    print("####################################")
    
    
    print("********")
    
    
    quotes=get_all_quotes_similar_insured_name_and_dot_number( quote_id)
    print("**********")
    print(quotes)
    print("******* similar end******")
    res={"quotes":quotes}
    
    return   Response(res, status=status.HTTP_200_OK)

@api_view(['POST']) 
def get_agency_users(request):
    data = json.loads(request.body.decode("utf-8"))
    _agency_id=int(data['agency_id'])
    print(_agency_id)
    users=get_all_agencies_users(_agency_id)
    print(users)
    res={"result":users}
    
    return   Response(res, status=status.HTTP_200_OK)  


@api_view(['GET']) 
def get_agencies(request):
    print("In the view")
    agencies=get_all_agencies_db()
    res={"result":agencies}
    
    return   Response(res, status=status.HTTP_200_OK)   
@api_view(['POST'])
def get_similar_quotes_of_selected_quote(request):
    data=json.loads(request.body.decode("utf-8"))
    quote_id=data['quote_id']
    agency_id=data['agency_id']
    #print(agency_id," agency id retrieval")
    quotes=[]
    if(agency_id==-1):
        quotes=get_all_quotes_similar_insured_name_and_dot_number(quote_id)
    else:
        if agency_id==-1:
            agency_id=get_agency_id_with_quote_id(quote_id)[0]["agency_id"]
        print("********")
    #print(agency_id)
    
        genInfo = get_db_general_info_by_quoteid(quote_id)
        insuredInfo = get_db_ins_insured_info_by_quote_id(quote_id)
    #print(insuredInfo)
        insured_name=insuredInfo[0]['insured_name']
        dot_number=insuredInfo[0]['dot_number']
    
        quotes=get_all_quotes_of_agency_by_insured_name_and_dot_number( agency_id,insured_name,dot_number,quote_id)
    res={"quotes":quotes}
    
    return   Response(res, status=status.HTTP_200_OK)
    



@api_view(['POST'])
def update_quote_status(request):
    data = json.loads(request.body.decode("utf-8"))
    _quote_id=data['quote_id']
    _status_id=data['status_id']
    
    _id=update_quote_status_db(_quote_id,_status_id)
    res={"result":_id}
    
    return   Response(res, status=status.HTTP_200_OK) 




@api_view(['POST'])
def update_quote_underwriter(request):
    data = json.loads(request.body.decode("utf-8"))
    _quote_id=data['quote_id']
    _underwriter_id=data['underwriter_id']
    
    _id=update_quote_underwriter_db(_quote_id,_underwriter_id)
    print("underwriter updated id",_id)
    print(type(_id))
    res={"result":_id}
    
    return   Response(res, status=status.HTTP_200_OK) 

    
# get_quote_data_from_history  

@api_view(['POST'])
def get_quote_details_from_history(request):
    data = json.loads(request.body.decode("utf-8"))
    _quote_id=data['quote_id']
    print(_quote_id)
   
    quote_details=[]
    quotes=get_quote_data_from_history(_quote_id)
    quote_bind_info=get_quote_bind_info_db(_quote_id)
    #print(quote_bind_info[0])
    
    #print(quotes)
    q1=quotes[0]
    
    res={"result":q1}
    
    return   Response(res, status=status.HTTP_200_OK)  

@api_view(['POST'])
def get_similar_quotes_of_agency(request):
    data = json.loads(request.body.decode("utf-8"))
    _agency_id=data['agency_id']
    _insured_name=data['insured_name']
    _dot_number=data['dot_number']
    quotes=[]
    quotes=get_all_quotes_of_agency_by_insured_name_and_dot_number( _agency_id,_insured_name,_dot_number)
    res={"quotes":quotes}
    
    return   Response(res, status=status.HTTP_200_OK)

@api_view(['POST'])
def get_driver_violations(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    violations=[]
    violations=get_driver_violations_list()
    res={"violations":violations}
    
    return   Response(res, status=status.HTTP_200_OK)

@api_view(['POST'])
def get_driverscore(request):
     """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
     data = json.loads(request.body.decode("utf-8"))
     try:
        violations_data=data["violations"]
        #print( violations_data)
        #points=get_driver_score(violations_data)
        res={"points":points}
     except :
        print("error")
        res={"points":0} 
     return   Response(res, status=status.HTTP_200_OK)
 
@api_view(['POST']) 
def is_policy_number_available(request):
    data = json.loads(request.body.decode("utf-8"))
    policy_number=data['policy_number']
    print(policy_number)
    res=is_policy_number_available_db(policy_number)
    print(res)
    result={"result":res}
    return   Response(result, status=status.HTTP_200_OK)


@api_view(['POST']) 
def update_quote_bind_info(request):
     data = json.loads(request.body.decode("utf-8"))
     res={"quote_info_id":-1}
     try:
        quote_id=data['quote_id']
        policy_number=data['policy_number']
        have_filings=data['have_filings']
        filings_processed=data['filings_processed']
        filings_processed_by=data['filings_processed_by']
        all_documents_received=data['all_documents_received']
        pending_documents=data['pending_documents']
        documents_processed_by=data['documents_processed_by']
        pending_docs_due_by=data['pending_docs_due_by']
        bind_processed_by=data['bind_processed_by']
        downpayment_received=data['downpayment_received']
        downpayment_amount=data['downpayment_amount']
        is_financed=data['is_financed']
        finance_company_name=data['finance_company_name']
     
     
        quote_info_id=update_quote_bind_info_db(policy_number ,
            have_filings  ,
            filings_processed ,
            filings_processed_by ,
            all_documents_received  ,
            pending_documents ,
            documents_processed_by ,
            None if pending_docs_due_by==None else pending_docs_due_by.strip() ,
            bind_processed_by,
            downpayment_received ,
            float(downpayment_amount) ,
            is_financed ,
            finance_company_name  ,
            quote_id)
        res={"quote_info_id":quote_info_id}
     except (Exception, psycopg2.DatabaseError) as error:
           print(error,"quote info  editing")
        
           pass
     return   Response(res, status=status.HTTP_200_OK)


@api_view(['POST'])     
def fetch_quote_bind_info_details(request) :
    data = json.loads(request.body.decode("utf-8"))
    quote_id=data['quote_id']
    res=get_quote_bind_info_db(quote_id)
    result={"result":res}
    return   Response(result, status=status.HTTP_200_OK)

@api_view(['POST']) 
def add_quote_bind_info(request):
     data = json.loads(request.body.decode("utf-8"))
     res={"quote_info_id":-1}
     try:
        quote_id=data['quote_id']
        policy_number=data['policy_number']
        have_filings=data['have_filings']
        filings_processed=data['filings_processed']
        filings_processed_by=data['filings_processed_by']
        all_documents_received=data['all_documents_received']
        pending_documents=data['pending_documents']
        documents_processed_by=data['documents_processed_by']
        pending_docs_due_by=data['pending_docs_due_by']
        bind_processed_by=data['bind_processed_by']
        downpayment_received=data['downpayment_received']
        downpayment_amount=data['downpayment_amount']
        is_financed=data['is_financed']
        finance_company_name=data['finance_company_name']
     
     
        quote_info_id=add_quote_bind_info_db(policy_number ,
            have_filings  ,
            filings_processed ,
            filings_processed_by ,
            all_documents_received  ,
            pending_documents ,
            documents_processed_by ,
            pending_docs_due_by.strip() ,
            bind_processed_by,
            downpayment_received ,
            float(downpayment_amount) ,
            is_financed ,
            finance_company_name  ,
            quote_id)
        res={"quote_info_id":quote_info_id}
     except:
         pass
     return   Response(res, status=status.HTTP_200_OK) 
# def update_general_info(request):
#     data = json.loads(request.body.decode("utf-8"))
#     genInfo=data['genInfo']
#     quote_id=data['quote_id']
#     try:
        
        
        
#     except:
#         pass
#update_submission_draft
@api_view(['POST'])
def update_submission_draft(request):
     data = json.loads(request.body.decode("utf-8"))
     submission_data=data['submission_data']
     _submission_draft_id=data['submission_draft_id']
     
     draft_id=update_submission_draft_db(submission_data,_submission_draft_id)
     res={"draft_id":draft_id}
     
     return   Response(res, status=status.HTTP_200_OK) 
    
@api_view(['POST'])
def save_submission_draft(request):
     data = json.loads(request.body.decode("utf-8"))
     user_id=data['user_id']
     submission_data=data['submission_data']
     insured_name=data['insured_name']
     dot_number=data['dot_number']
     effective_date=data['effective_date']
     
     draft_id=save_submission_draft_db(submission_data,insured_name , 
                          dot_number,   
                          effective_date, 
                          user_id) 
     res={"draft_id":draft_id}
     
     return   Response(res, status=status.HTTP_200_OK) 
@api_view(['POST'])
def clear_premium_details(request):
    data = json.loads(request.body.decode("utf-8"))
    try:
        quote_id=data['quote_id']
        submission_id=data['quote_id']
        remove_quote_premiums(quote_id)
        policy_level_premium={
            "Hired_auto_premium":0,
            "Non_owned_Auto_Premium":0,
            "Trailer_inter_change_premium":0,
            "broker_fee_liability":0,
             "broker_fee_pd":0,
             "broker_cargo_fee":0,
             "broker_total_fee": 0,
             "additional_insured":0,
             "loss_payee":0,
             "primary_wording":0,
             "waiver_of_subrogation":0,
             "cargo_endorsements": 0,
             "sum_of_liability": 0,
             "sum_of_pd":0,
             "sum_of_cargo":0,
             "liability_surplus_lines_tax":0,
             "pd_surplus_lines_tax":0,
             "cargo_surplus_lines_tax": 0,
             "liability_stamping_fee":0,
             "pd_stamping_fee":0,
             "cargo_stamping_fee":0,
             "liability_lob_cost":0,
             "pd_lob_cost":0,
             "cargo_lob_cost":0,
             "package_cost":0
            
        }  
    
        lq=[]
        cf=[]
        pf=[]
        vhs=[]
        gross_premium=[]
        totals=0
        quote_pdf_bs64=''
        quote_premium=0
        base_rate=0
        gross_premium={}

        
        res={"liability":lq,"cargo":cf,"pd": pf,"vehicles":vhs,"totals":gross_premium,"base_rate":base_rate,"ploicylevelpremium":policy_level_premium,"quotepdf":quote_pdf_bs64,"submission_id":submission_id,"quote_premium":quote_premium}
        add_quote_data_premium_estimate_db(quote_id,json.dumps(res,cls=BytesEncoder),json.dumps(data,cls=BytesEncoder))
        result={"result":'SUCCESS'}
    except:
        print("Error.........")
        result={"result":'FAILURE'}
    return   Response(result, status=status.HTTP_200_OK) 
    
       
@api_view(['POST'])
def get_premium_details(request):
    data = json.loads(request.body.decode("utf-8"))
    #print(data)
    try:
         
        _cargo_endorsements_totals=0
       
        user_id=data['user_id']
        agency_id=data['agency_id']
        submission_id=data['submission_id']
        quote_id=data['quote_id']
        
        commodities_info=data['commoditiesInfo']
        commoditiesSelected=data['commoditiesSelected']
        coveragesInfo=data['coveragesInfo']
        cargoEndorsInfo=data['specialEndorsementsInfo']
        if cargoEndorsInfo['contingent_transit_endorsement_cost']!='':
            _cargo_endorsements_totals=_cargo_endorsements_totals+float(cargoEndorsInfo['contingent_transit_endorsement_cost'])
            print(_cargo_endorsements_totals)
        if cargoEndorsInfo['nonowned_interchange_endorsement_cost']!='':
            _cargo_endorsements_totals=_cargo_endorsements_totals+float(cargoEndorsInfo['nonowned_interchange_endorsement_cost'])
        if cargoEndorsInfo['ltl_endorsement_cost']!='':
            _cargo_endorsements_totals=_cargo_endorsements_totals+float(cargoEndorsInfo['ltl_endorsement_cost'])
        if cargoEndorsInfo['eggs_endorsement_cost']!='':
            _cargo_endorsements_totals=_cargo_endorsements_totals+float(cargoEndorsInfo['eggs_endorsement_cost'])
        if cargoEndorsInfo['theft_endorsement_cost']!='':
            _cargo_endorsements_totals=_cargo_endorsements_totals+float(cargoEndorsInfo['theft_endorsement_cost'])
        if cargoEndorsInfo['riggers_endorsement_cost']!='':
            _cargo_endorsements_totals=_cargo_endorsements_totals+float(cargoEndorsInfo['riggers_endorsement_cost'])
        drivers=data["drivers"]
        vehicles=data['vehicles']
        
        
        
        filingInfo=data['filingInfo']
        genInfo=data['genInfo']
        insuredInfo=data['insuredInfo']
        radiusOfOperationsInfo=data['radiusOfOperationsInfo']
        vehiclesInfo=data['vehicleInfo']
        uwReviewInfo=data['uwReviewInfo']
        ai_insured=data['addlInfo']
        secondary_class=data['secondary_class']
        vehicles=data['vehicles']
        
        addlInfo=data['addlInfo']
        broker_info=data['broker_info']
    
        commodities_al_factor=data['commodities_al_factor']
        commodity_cargo_factor=data['commodity_cargo_factor']
        commodity_pd_factor=data['commodity_pd_factor']
        yxpliability=insuredInfo["years_of_experience"] #liability factor years of experience 
        containers_selected=data['containers_selected']
    #********** End of Data received from front end ************#
    
        class_ids={'Surpluslines Tax':90,
               'Stamping Fee':91,
               'Auto Liability Premium':20,
               'Physical Damage Premium':40,
               'Cargo Premium':50,
               'Broker Fee':94,
               'Policy Fee':95
               
        
    }
    
    
        #************ Underwriter modified factors received from UI *************#
    
        uwcreditdebitfactor_liability=uwReviewInfo["uw_credit_debit_factor"] # uw credit debit liability
        uwcreditdebitfactor_pd=uwReviewInfo["pd_uw_credit_debit_factor"] # uw credit debit pd
        uwcreditdebitfactor_cargo=uwReviewInfo["cargo_uw_credit_debit_factor"] # uw credit debit cargo
        loss_experience_factor_liability=uwReviewInfo["loss_experience_factor"]
        loss_experience_factor_pd=uwReviewInfo["pd_loss_experience_factor"]
        loss_experience_factor_cargo=uwReviewInfo["cargo_loss_experience_factor"]
        driver_factor=uwReviewInfo["driver_factor"]
    #************************End of underwriter modified data ********#
    
    #********** Producer Default contact emails and phone ***********#
        broker_default_email=broker_info['broker_default_email']
      
        broker_default_phone=broker_info['broker_default_phone']
        broker_bind_email=broker_info['broker_bind_email']
        broker_endorsements_email=broker_info['broker_endorsements_email']
        broker_cancellation_confirmation_email=broker_info['broker_cancellation_confirmation_email']
    #****************** end of producer email details ************#    
        state_code=insuredInfo['insured_garaging_state'] 
        #_cargo_endorsements_totals=0
        ltl_endorsement_cost='0'
        eggs_cost='0'
        riggers_cost='0'
        theft_cost='0'
        contingent_transit_endorsement_cost='0'
        nonowned_interchange_endorsement_cost='0'
        
      
        
        
        insured_name=insuredInfo["insured_name"]
        insured_dba=''
        #insured_entity=data['entity_type']
        efd=genInfo["effective_date"]
        insured_email=''
        history=''
        #name_on_policy=data['insured_policy_name']
        entity_type=''
        insured_owner_operator=''
        insured_phone=''
        does_insured_have_dot_number='No'
        does_insured_need_state_filings='No'
        insured_rating_on_safer_fmcsa_website=''
        
        
        
        
       
        company=genInfo["company"]
        lob=genInfo["lob"]
        submission_id=-1
        user_id=data["user_id"]
        dot_number=filingInfo["dot_number"]
        permit_number=filingInfo["permit_number"]
        mc_number=filingInfo["mc_number"]
        insured_name=insuredInfo["insured_name"]
        effective_date=genInfo["effective_date"]
        expiration_date=genInfo["expiration_date"]
        years_of_experience=insuredInfo["years_of_experience"]
        insured_garaging_city=insuredInfo["insured_garaging_city"]
        insured_garazing_address=insuredInfo["insured_garaging_address"]
        insured_garaging_state=insuredInfo["insured_garaging_state"]
        insured_garazing_zip=insuredInfo["insured_garaging_zip"]
        insured_mailing_address=insuredInfo["insured_mailing_address"]
        insured_mailing_city=insuredInfo["insured_mailing_city"]
        insured_mailing_state=insuredInfo["insured_mailing_state"]
        insured_mailing_zip=insuredInfo["insured_mailing_zip"]
        containers_selected=data["containers_selected"]
        
        dparts=effective_date.split('/')
        _effective_date=dparts[2]+'/'+dparts[0]+'/'+dparts[1]
        dparts=expiration_date.split('/')
        _expiration_date=dparts[2]+'/'+dparts[0]+'/'+dparts[1]
        insured_info={
            "insured_name":insured_name,
            "insured_garaging_address":insured_garazing_address,
            "insured_garaging_city":insured_garaging_city,
            "insured_garaging_state":insured_garaging_state,
            "insured_garazing_zip":insured_garazing_zip,
            "effective_date":effective_date,
            "expiration_date":expiration_date,
            "years_of_experience":years_of_experience
            
            
            
        }
        
       
                         
                         
                         
                         
                        
     
        towing_yes=coveragesInfo["towing"]
        pd=coveragesInfo["pd"]
    
        print(coveragesInfo["trailer_interchange"])
        trailer_interchange=coveragesInfo["trailer_interchange"]
       
        trailer_interchange_limit=coveragesInfo["trailer_interchange_limit"]
        trailer_interchange_units=coveragesInfo["trailer_interchange_units"]
        
            
     
     
        liability=coveragesInfo["liability"] # liablity limit
        cargo_limit=coveragesInfo["cargo"] # cargo limit
     
        um_limit=coveragesInfo["um_limit"] # um limit
        um_unit_rate=data["um_unit_rate"]
        uim_limit=coveragesInfo["uim_limit"] # uim limit
        pip_limit=coveragesInfo["pip_limit"] # pip limit
        medical_limit=coveragesInfo["medical_limit"] # medical limit
        
        hired_auto_liability=coveragesInfo["hired_auto_liability"] # hired auto limit
        hired_auto_type=coveragesInfo["hired_auto_type"]
        cost_basis=coveragesInfo["cost_basis"]
        non_hired_auto_limit=coveragesInfo["non_hired_auto_limit"]
        non_hired_auto_on_contratual_basis=coveragesInfo["non_hired_auto_on_contratual_basis"]
        number_of_non_owned_units=coveragesInfo["number_of_non_owned_units"]
        non_hired_auto_premium='0'
        state_code= insuredInfo['insured_garaging_state']
        vehicle_towing_premium='0'
        pw_endorsements=0
        ws_endorsements=0
        #ai_endorsements=0
        lp_endorsements=0
        
        if non_hired_auto_on_contratual_basis=='Yes' and  number_of_non_owned_units!='':
            non_hired_auto_premium=str(get_non_owned_auto_premium(number_of_non_owned_units))
        um_premium=0
        uim_premium=0
        territory_code=get_territory_code_by_zipcode(insured_garazing_zip)  
        
        pip_liability_per_unit=0  
        if  pip_limit!='':
           
            is_available=get_premium_type_availability_in_state(state_code,'PIP')
            
            if  is_available==True:
                    
                    pip_liability_per_unit=get_pip_premium(state_code,pip_limit,radiusOfOperationsInfo["radius"].strip())
                    
            else:
                    pip_liability_per_unit=0
        if  uim_limit!='':
            if  get_premium_type_availability_in_state(state_code,'UIM')==False:
                    uim_limit=''
                    uim_premium=0
           
           
        
       
       
        trailer_interchange_units=coveragesInfo["trailer_interchange_units"]
        if towing_yes!='':
           towing=coveragesInfo["towing"]
           
        else:
            towing='0'
        towing_limit=towing
        
        cargo_deductible=coveragesInfo["cargo_deductible"]
        refeer_coverage_required=coveragesInfo["refeer_coverage_required"]
        if refeer_coverage_required=='Yes':
          refeer_coverage=coveragesInfo["refeer_coverage"] 
        else:
            refeer_coverage='0'
     
        zipcode=insuredInfo["insured_garaging_zip"] # zipcode
        state_code=insuredInfo["insured_garaging_state"] # garaging state
        radius=radiusOfOperationsInfo["radius"] # radius
        saferfactor=(filingInfo["safer_factor"]) # safer
        yxpliability=insuredInfo["years_of_experience"] #liability factor years of experience 
    
        uwcreditdebitfactor_liability=uwReviewInfo["uw_credit_debit_factor"] # uw credit debit liability
        uwcreditdebitfactor_pd=uwReviewInfo["pd_uw_credit_debit_factor"] # uw credit debit pd
        uwcreditdebitfactor_cargo=uwReviewInfo["cargo_uw_credit_debit_factor"] # uw credit debit cargo
        loss_experience_factor_liability=uwReviewInfo["loss_experience_factor"]
        loss_experience_factor_pd=uwReviewInfo["pd_loss_experience_factor"]
        loss_experience_factor_cargo=uwReviewInfo["cargo_loss_experience_factor"]
        driver_factor=uwReviewInfo["driver_factor"]
        #driver_factor=1
        usetype=vehiclesInfo["usetype"] # type of use
        secondary_class=commodities_info["secondary_class"] #secondary class
        trailer_type=vehiclesInfo["trailer_type"] #trailer type
        commodity_al_factor=data["commodities_al_factor"]
        commodity_pd_factor=data["commodity_pd_factor"]
        commodity_cargo_factor=data["commodity_cargo_factor"]
        #**************vehicles data**************** 
       # vehicles=data["vehicles"]
        vvhs=vehicles
        #***************************************
        #******* Drivers data **********#
        
       
        driver_factor_max=0
        drv_factor=1
        drivers_factors=[]
        try:
            
            for drv in drivers:
                
                age=calculateAge((drv["dob"]))
                #print(age," Driver age")
                drv_factors=calculate_driver_factor((drv['licenseclasstype']),(drv['experience']),(drv['licensestate']),age,(drv['violations']))
                #print("Driver factor ......",drv_factors['factor'])
                if driver_factor_max==0:
                    driver_factor_max=drv_factors['factor']
                elif driver_factor_max<drv_factors['factor']:
                    driver_factor_max=drv_factors['factor']
                
                dtparts=(drv['dob']).split('/')
                newdt=dtparts[2]+'-'+dtparts[0]+'-'+dtparts[1]
                
                dv=Driver((drv['name']),
                          newdt,
                          (drv['licenseno']),
                          (drv['experience']),
                          (drv['licensestate']),
                          (drv['licenseclasstype']),
                          (drv['licensemedicalexp']),
                          (drv['licenseexpdate']),
                          (drv_factors['points']),
                          drv_factors['factor'],-1)
                #print(dv)
                drivers_factors.append(dv)
            if driver_factor_max==0:
                driver_factor_max=1
           
            
            #for drvf in drivers_factors:
                
                #driver_id=add_driver(dv)
                
        except Exception as e:
            print("Exception in drivers....")
            print(e," age ")
        print("driver factor after calculation",driver_factor_max )
        
        if(driver_factor_max==0):
            driver_factor='1'
        else:
            driver_factor=str(driver_factor_max)
        #**************************************
        #********************Broker fees ***************#
        #driver_factor=1
        
        
        broker_fees_liability=0
        broker_fees_pd=0
        broker_fees_cargo=0
     #********* Get common factors ***********######
        um_premium=0
        uim_premium=0
        territory_code=get_territory_code_by_zipcode(zipcode)
        #print(territory_code,"******* tcode")
       
        lst_base_rate_territory_factor=get_base_rate_and_territory_factor( territory_code,state_code)
        base_rate=lst_base_rate_territory_factor.get("base_rate")
        if base_rate==0:
            lq=[]
            cf=[]
            pf=[]
            vhs=[]
            gross_premium=[]
            res={"liability":lq,"cargo":cf,"pd": pf,"vehicles":vhs,"totals":gross_premium,"base_rate":0}
        #create_premium_document(lq,pf,cf,vhs,gross_premium)
            return   Response(res, status=status.HTTP_200_OK) 
        #print(base_rate,"**********")
        territory_factor=lst_base_rate_territory_factor.get("territory_factor")
        ilf_factor=get_ilf_factor()
        lcm_factor=get_lcm_factor()
        pollution_factor=get_pollution_factor()
        state_factor=get_state_factor()
        rate_control_factor=get_rate_control_factor()
        primary_factor=get_primary_factor()
        radius_factor=get_radius_factor(radius)
        use_type_factor=get_type_of_use_factor(usetype)
        trailer_type_factor=get_trailer_type_factor(trailer_type)
        if liability !='No':
            liability_limit_factor=get_liability_limit_factor(liability)
        else:
             liability_limit_factor=1
        safer_factor=get_safer_factor(saferfactor)
        
        liability_years_of_experience_factor=get_years_of_experience_factor(yxpliability)
        
        pd_years_of_experience_factor=get_years_of_experience_factor(yxpliability)
        cargo_years_of_experience_factor=get_years_of_experience_factor(yxpliability)
        secondary_class_factor=get_secondary_class_factor(secondary_class)
     
        type_of_use_factor=get_type_of_use_factor(usetype)
     
        base_ratefactor=1
        cargo_state_factor=1
        cargo_radius_factor=1
        cargo_limit_factor=1
        cargo_deductible_factor=1
     
        _cargo_refeer_deductible_factor=1
        
    #****************** Premium Totals **********************
        _liability_premium_total=0
        _um_premium_total=0
        _uim_premium_total=0
        _pip_premium_total=0
        _med_premium_total=0
        _pd_premium_total=0
        _ti_premium_total=0
        _tow_premium_total=0
        _cargo_premium_total=0
        _existing_submission='No'
        _existing_quote='No'
        if submission_id!=-1:
            _existing_submission='Yes'
        if quote_id!=-1:
            _existing_quote='Yes'

     
     
     
        if liability!='No':
            liability_limit_factor=get_liability_limit_factor(liability)
            
        if cargo_limit!='No':
            base_ratefactor=get_cargo_base_rate()
            cargo_state_factor=get_cargo_state_factor(state_code)
            cargo_radius_factor=get_cargo_radius_factor(radius)
            cargo_limit_factor=get_cargo_limit_factor(cargo_limit)
            cargo_deductible_factor=get_cargo_deductible_factor(cargo_deductible)
            if refeer_coverage_required!='':
                _cargo_refeer_deductible_factor=get_cargo_refeer_deductible_factor(refeer_coverage)
                
        #if(submission_id==-1) :   
            #agency_id=data["agency_id"]
        #user_id=data["user_id"]
        if submission_id==-1:
            submission_id= add_submission_new_db(agency_id, _effective_date,_expiration_date, broker_default_email, broker_default_phone, broker_bind_email, broker_endorsements_email,broker_cancellation_confirmation_email,user_id)
        _quotedate=datetime.datetime.now().strftime("%Y-%m-%d")
        #if submission_id > -1:
        
              
          
            #driver_factor_max=0
            #drv_factor=1
            #drivers_factors=[]
        if(submission_id==-1):
            res={"response":"Submission Failed"}
            return   Response(res, status=status.HTTP_200_OK)
        try:
            remove_insured_db(submission_id)
            insured_id=add_insured(insuredInfo,filingInfo,submission_id)   
     
            if quote_id==-1:
                quote_id=add_quote_new_db(submission_id,user_id,genInfo['company'],genInfo['lob'])
            else:
                if _existing_quote=='Yes':
                   update_quote_db(quote_id,user_id,genInfo['company'],genInfo['lob'])
                    
                    
            if _existing_quote=='Yes':
                remove_quote_coverage_with_quote_id(quote_id)
            
            coverages_id=add_coverages(coveragesInfo,secondary_class,quote_id)
            
            if _existing_quote=='Yes':
                remove_general_info_db(quote_id)
            general_info_id=add_general_info(coveragesInfo['quotetype'],coveragesInfo['policytype'],genInfo['company'],genInfo['lob'],coveragesInfo['billtype'],quote_id)
            
            if _existing_quote=='Yes':
                remove_radius_of_operations(quote_id)
            radius_id=add_radius_of_operation(radiusOfOperationsInfo['radius'],
                                         radiusOfOperationsInfo['Intrastate_interstate'],
                                         radiusOfOperationsInfo['state_1'],
                                         radiusOfOperationsInfo['state_2'],
                                         radiusOfOperationsInfo['state_3'],
                                         radiusOfOperationsInfo['state_4'],
                                         quote_id
                                         )
            #for commodity adding
            #print("Adding drivers")
            #print(drivers_factors)
            if _existing_quote=='Yes':
                remove_drivers(quote_id)
            for drvf in drivers_factors:
                drvf.quoteid=quote_id
                #print(drvf)
                driver_id=add_driver(drvf)
            if _existing_quote=='Yes':
                remove_quote_commodities(quote_id)
            for cdt in commoditiesSelected:
                cdt_id=add_quote_commodity(cdt,quote_id)
            _quotedate=datetime.datetime.now().strftime("%Y-%m-%d")
        except Exception as error:
            print(error,'quotdate')
        hired_auto_premium=0
        if hired_auto_liability!='':
            if hired_auto_type=='Primary':
                hired_auto_premium=0.02*int(cost_basis)
            else:
                hired_auto_premium=0.08*int(cost_basis) 
        if non_hired_auto_limit!='':
            if non_hired_auto_on_contratual_basis!='' and number_of_non_owned_units!='':
                #print(number_of_non_owned_units,type(number_of_non_owned_units),"Non owned units")
                non_hired_auto_premium=str(get_non_owned_auto_premium(number_of_non_owned_units))
                print(non_hired_auto_premium," Non owned units...")
               
        
        
     
                 
                 
        vehicle_type_factor=1
        vehicle_make_factor=1
        pd_base_rate_factor=1
        pd_state_factor=1
        pd_deductible_factor=1
        pd_um_amount=100
        _base_ratefactor=1
        _cargo_state_factor=1
        _cargo_radius_factor=1
        _cargo_limit_factor=1
        _cargo_deductible_factor=1
        _pd_base_rate_factor=1
        _pd_vehicle_make_factor=1
        _pd_state_factor=1
        _pd_deductible_factor=1
        #### Gross Premiums #########
        _gross_liability_premium=0
        _gross_pd_premium=0
        _gross_cargo_premium=0
        _gross_pip_premium=0
        ############################
        vehicle_trailer_interchange_premium=0
     
        power_units=0
        #print(len(vehicles),"vehicles count")
        #return
        if _existing_quote=='Yes':
            remove_vehicles(quote_id)
            remove_cargo_factors_xref(quote_id)
            remove_liability_factors_xref(quote_id)
            remove_pd_factors_xref(quote_id)
            
        for v in vehicles:
            
           
            if v["model"].upper()=='TRACTOR' or v["model"].upper()=='TRUCK':
                power_units=power_units+1
            vehicle_type_factor=get_vehicle_type_factor(v["model"])
            vehicle_model_factor=get_vehicle_weight_factor(v["weight"])
            
            vehicle_make_factor=get_pd_vehicle_make_factor(v["make"])
            pd_base_rate_factor=get_pd_base_rate_factor(v["stated_value"])
            pd_state_factor=get_pd_state_factor(state_code)
            print("########--------####")
            #print(v)
            print("#########---########")
            pd_deductible_factor=get_pd_deductible_factor(v["deductible"])
            # if um_limit!=''
            if um_limit!='No' and v['um']==True and ( v["model"].upper() !='TRAILER' and v["model"].upper() !='NON-OWNED-TRAILER'):
                
                    pd_um_amount=um_unit_rate
                    _um_premium_total=_um_premium_total+pd_um_amount
               
            else:
                pd_um_amount=0
            #if cargo_limit !=''
            if cargo_limit !='No' and ( v["model"] !='TRAILER' or v["model"] !='NON-OWNED-TRAILER'):
                _base_ratefactor=base_ratefactor
                _cargo_state_factor=cargo_state_factor
                _cargo_radius_factor=cargo_radius_factor
                _cargo_limit_factor=cargo_limit_factor
                _cargo_deductible_factor=cargo_deductible_factor
                
           
            else:
                _base_ratefactor=1
                _cargo_state_factor=1
                _cargo_radius_factor=1
                _cargo_limit_factor=1
                _cargo_deductible_factor=1
            liability_premium=0
            ttype_factor=1
            
            if liability !='No':
                try:
                    if  v["model"] =='TRAILER' or v["model"] =='NON-OWNED-TRAILER':
                        ttype_factor=0.05
                    else:
                        ttype_factor=trailer_type_factor
                     
                    liability_premium=calculate_liability_premium(base_rate,
                                                                  territory_factor,
                                                                  lcm_factor,
                                                          ilf_factor,
                                                          primary_factor,
                                                          pollution_factor,
                                                          state_factor,
                                                          rate_control_factor,
                                                          vehicle_model_factor,
                                                          radius_factor,
                                                          commodity_al_factor,
                                                          float(driver_factor),
                                                          float(loss_experience_factor_liability),
                                                          safer_factor,
                                                          liability_years_of_experience_factor,
                                                          float(uwcreditdebitfactor_liability),
                                                          liability_limit_factor,
                                                          type_of_use_factor,
                                                          secondary_class_factor
                                                          ,ttype_factor
                                                         
                                                          )
                   
                    
                    
                    #liability_premium=liability_premium+um_premium+uim_premium+hired_auto_premium+int(non_hired_auto_premium)
                    _gross_liability_premium=_gross_liability_premium+liability_premium
                    _liability_premium_total=_liability_premium_total+liability_premium
                    
                    _uim_premium_total=_uim_premium_total+uim_premium
                    
                    
                except Exception as e:
                   # print(e," problem with liability")
                   pass
                    
            
            cargo_premium=0
           
            if cargo_limit !='No' and  (v["model"].upper()=='TRACTOR' or v["model"].upper()=='TRUCK'):
                
                try:
                    cargo_premium=calculate_cargo_premium(_base_ratefactor,_cargo_state_factor,float(driver_factor),float(loss_experience_factor_cargo),
                                                  float(uwcreditdebitfactor_cargo),commodity_cargo_factor,
                                                  cargo_years_of_experience_factor,rate_control_factor,
                                                  safer_factor, _cargo_radius_factor,_cargo_limit_factor,_cargo_deductible_factor,
                                                  _cargo_refeer_deductible_factor) 
                    _gross_cargo_premium=_gross_cargo_premium+ cargo_premium
                    _cargo_premium_total=_cargo_premium_total+cargo_premium
                except Exception as e:
                    print(e," problem with cargo")
            else:
                  cargo_premium=0     
            pd_premium=0
            vehicle_towing_premium=0
           
            if pd=='Yes':
                
                _pd_base_rate_factor=get_pd_base_rate_factor(int(v['stated_value']))
                
                _pd_vehicle_make_factor=get_pd_vehicle_make_factor(v['make'])
                _pd_state_factor=get_pd_state_factor(state_code)
                _pd_deductible_factor=get_pd_deductible_factor(v['deductible'])
                
                if v['tow']==True:
                    vehicle_towing_premium=get_towing_premium(towing)
                else:
                    vehicle_towing_premium=0
                
                if v['tow']==True:
                    _tow_premium_total=_tow_premium_total+vehicle_towing_premium
                
                try:
                    
                   
                    pd_premium=calculate_pd_premium(float(v['stated_value']),pd_base_rate_factor,_pd_vehicle_make_factor,_pd_state_factor,
                                            float(driver_factor),float(loss_experience_factor_pd),float(uwcreditdebitfactor_pd),
                                            _pd_deductible_factor,commodity_pd_factor,
                                            pd_years_of_experience_factor,rate_control_factor,safer_factor)
                    
                    _pd_premium_total=_pd_premium_total+pd_premium
                    
                    
                   
                    _gross_pd_premium=_gross_pd_premium+pd_premium
                    
                    if trailer_interchange!='':
                        if v['model'].upper()=='TRACTOR' or v['model'].upper()=='TRAILER':
                            vehicle_trailer_interchange_premium=calculate_trailer_interchange_premium(
                            float(v['stated_value']),pd_base_rate_factor,_pd_vehicle_make_factor,_pd_state_factor,
                                            float(driver_factor),float(loss_experience_factor_pd),float(uwcreditdebitfactor_pd),
                                            _pd_deductible_factor,commodity_pd_factor,
                                            pd_years_of_experience_factor,rate_control_factor,safer_factor,trailer_type_factor,containers_selected
                            )  
                        else :   
                            vehicle_trailer_interchange_premium=0
                              
                #Trailer interchange Premium calculation################
                    _ti_premium_total=_ti_premium_total+vehicle_trailer_interchange_premium    
                    #print( _ti_premium_total, "Trailer interchange premium")
                
                except Exception as e:
                    print(e," problem with pd")
           
            um_premium=0
            uim_premium=0
            veh_medical_premium=0
            
            if medical_limit!='No':
                veh_medical_premium=get_medical_premium(state_code,medical_limit)
            else:
                veh_medical_premium=0
            _med_premium_total=_med_premium_total+veh_medical_premium
            
            vehicle_pip_limit=0
            
            
            vehicle_pip_premium=pip_liability_per_unit
            _pip_premium_total=_pip_premium_total+vehicle_pip_premium
           
            
            vehicle_cargo_reefer_factor=get_cargo_refeer_deductible_factor(refeer_coverage)
            
            um_premium=0
            if (v["model"].upper()=='TRUCK' or v["model"].upper()=='TRACTOR') and um_limit!='' :
                    
               
                    #print(v['um'],"**************************")
                try:    
                    if v['um']==True:
                            _um_premium_total=_um_premium_total+um_premium
                            um_premium=um_unit_rate
                    else:
                        um_premium=0
                except:
                    um_premium=0
               
            uim_premium=0
            #*****************************Medical limit ***********#
            print("###### mlimit")
            print(medical_limit)
            #return
            #****************************************
           
            #vehicle_model_factor=get_vehicle_model_factor(v["weight"])
            veh=Vehicle(v["make"], #1
                        v["model"], #2
                        v["year"], # 3
                        vehicle_type_factor, #4
                        vehicle_make_factor, #5
                        str(vehicle_model_factor), #6 vehicle
                        pd_deductible_factor,#7
                        v['stated_value'],#8
                        v['deductible'],#9
                        'true' if um_limit!='' else 'false', #10
                        str(um_premium), #11
                        '0' if um_limit=='No' else um_limit, #12
                        'true' if uim_limit !='No' else 'false',#13
                        
                        uim_premium, #14
                        'true' if medical_limit !='No' else 'false', #15
                        medical_limit if medical_limit!='No' else '0', #16
                        str(veh_medical_premium), #17
                        str(pd_premium), #18
                        'true' if liability !='No' else 'false', #19
                        '0' if liability=='No' else liability, #20
                        str(liability_premium), #21
                        'true' if pip_limit!='No' else 'false', #22
                        vehicle_pip_limit,#23
                        vehicle_pip_premium,#24
                        'true' if trailer_interchange!='Mo' else 'false', #25
                        '0' if trailer_interchange_units=='' else trailer_interchange_units , #26
                        vehicle_trailer_interchange_premium, #27
                        'true' if towing !='No' else 'false', #28
                        towing if v['tow'] ==True else  '0', #29
                        vehicle_towing_premium, #30
                        'true' if cargo_limit=='No' else 'false', #31
                        '0' if cargo_limit=='No' else cargo_limit, #32
                        '0' if cargo_limit=='No' else cargo_deductible, #33
                        str(cargo_deductible_factor),#34
                        str(cargo_premium),#35
                        'true' if refeer_coverage_required !='No' else 'false', #36
                        refeer_coverage, #37
                        str(vehicle_cargo_reefer_factor),#38
                        str(_cargo_refeer_deductible_factor),#39
                        str(quote_id),#40
                        _quotedate,v['weight'],v['vin'],v['o_l_rent']) #41
            
           
            if liability !='No':
                lxref=LiabilityXref(str(quote_id),str(base_rate),str(territory_factor),
                                             str(lcm_factor),str(ilf_factor),str(pollution_factor),
                                             str(state_factor),str(rate_control_factor),
                                             str(vehicle_model_factor),str(radius_factor),str(commodity_al_factor),
                                             str(driver_factor),str(safer_factor),
                                             str(liability_years_of_experience_factor),
                                             str(liability_limit_factor),str(secondary_class_factor),
                                             str(trailer_type_factor),str(primary_factor),
                                             str(uwcreditdebitfactor_liability),
                                             str(loss_experience_factor_liability),
                                             str(type_of_use_factor),)
            if  pd=='Yes':
                pdxref=PDXref(str(quote_id),
                              str(v['stated_value']),str(pd_base_rate_factor),
                              str(vehicle_make_factor),str(vehicle_model_factor),str(pd_state_factor),
                              str(rate_control_factor),
                              str(commodity_pd_factor),str(driver_factor),
                              str(safer_factor),str(pd_years_of_experience_factor),
                              str(pd_deductible_factor),uwcreditdebitfactor_pd,
                              loss_experience_factor_pd
                              )
            if  cargo_limit !='No':
                cargoxref=CargoXref(str(quote_id),
                                    str(_base_ratefactor),
                                     str(_cargo_state_factor),
                                     str(driver_factor),
                                     str(rate_control_factor),
                                     str(commodity_cargo_factor),
                                     str(safer_factor),
                                     str(cargo_years_of_experience_factor),
                                     str(_cargo_deductible_factor),
                                     str(vehicle_cargo_reefer_factor),
                                     uwcreditdebitfactor_cargo,
                                     loss_experience_factor_cargo,
                                     str( _cargo_radius_factor),
                                     str(_cargo_limit_factor)
                                     
                                     )
                                             
            
            try:
                #print(veh," vehicle details ")
                add_vehicledetails(veh)
                if liability !='No':
                    add_liabilityxref(lxref)
                if  pd=='Yes':
                    #print("Doing Pd")
                    add_pdxref(pdxref)
                if cargo_limit!='':
                    add_cargoxref(cargoxref)
            except Exception as e:
                print(e," error at vehicle adding")  
                continue
        _boker_liability_fee=get_liability_broker_fee(str(power_units)) 
        #print(_liability_premium_total,"Liability Total")
        lp_insured_premium_total=0
        if lp_endorsements>0:
            lp_insured_premium_total=lp_endorsements*100
        _broker_pd_fee=get_pd_broker_fee(str(int(_pd_premium_total)))+lp_insured_premium_total  
        #print(_cargo_premium_total," cargo premium total")
        _broker_cargo_fee=get_cargo_broker_fee(str(int(_cargo_premium_total)))
        _broker_total_fee=_boker_liability_fee+_broker_pd_fee+_broker_cargo_fee
        
        #update_quote(str(_quoteid),str( _broker_total_fee),str( _boker_liability_fee),str(_broker_pd_fee),
         #            str(_broker_cargo_fee),'true' if trailer_interchange=='Yes' else 'false',trailer_interchange_units,trailer_interchange_limit,str(_ti_premium_total))
        cf=[]
        cargo_factors=''
        #print(cargo_limit,' Cargo limit checking')
        if  cargo_limit !='No':
            cargo_factors=get_cargo_xref_factors(str(quote_id))
            for i in cargo_factors:
                cf.append(i[0])
                break
        pd_factors=''
        pf=[]
        #print(pd,' pd limit checking')
        if  pd=='Yes':
            pd_factors=get_pd_xref_factors(str(quote_id))
            for i in pd_factors:
                pf.append(i[0])
                break
        liability_factors=''
        lq=[]
        #print(liability," Liability checking")
        if liability !='No':
            liability_factors=get_liability_xref_factors(str(quote_id))
            lq=[]
            for i in liability_factors:
                lq.append(i[0])
                
                break
            
        vehicles=get_vehicles_premium(str(quote_id))
        #print(vehicles," vehicles data")
        vhs=[]
        
        for i in vehicles:
            vhs.append(i[0])
            #print(i[0])
        gross_premium={"liability":
            _liability_premium_total,
            "um":_um_premium_total,
            "uim":_uim_premium_total,
            "pip":_pip_premium_total,
            "med":_med_premium_total,
            "pd":_pd_premium_total,
            #"ti":_ti_premium_total,
            "tow":_tow_premium_total,
            "cargo":_cargo_premium_total
            
            }
        
        sum_of_liability=_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)
       
        addl_insured_premium_total=0
        if len(addlInfo)>0:
            addl_insured_premium_total=100*len(addlInfo)
        
        
        pw_endorsements_premium_total=0
        ws_endorsements_premium_total=0
        if pw_endorsements>0:
             pw_endorsements_premium_total=pw_endorsements*250
        if ws_endorsements>0:
            ws_endorsements_premium_total=ws_endorsements*250
        sum_of_liability=sum_of_liability+addl_insured_premium_total+pw_endorsements_premium_total+ws_endorsements_premium_total    
        liability_surplus_lines_tax=0
        liability_surplus_lines_tax=round((_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)+_boker_liability_fee+addl_insured_premium_total+pw_endorsements_premium_total+ws_endorsements_premium_total)*0.03,2)
        pd_surplus_lines_tax=round((_pd_premium_total+_ti_premium_total+lp_insured_premium_total+_broker_pd_fee)*0.03,2)
        cargo_surplus_lines_tax=0
        cargo_surplus_lines_tax=round((_cargo_premium_total+_broker_cargo_fee)*0.03,2)
        liability_stamping_fee=round((_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)+_boker_liability_fee+addl_insured_premium_total)*0.0025,2)
        pd_stamping_fee=(_pd_premium_total+_ti_premium_total+lp_insured_premium_total+_broker_pd_fee)*0.0025
        cargo_stamping_fee=(_cargo_premium_total+_broker_cargo_fee)*0.0025
        #liability_lob_cost=(_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)+_boker_liability_fee)+liability_surplus_lines_tax+liability_stamping_fee+addl_insured_premium_total+pw_endorsements_premium_total+ws_endorsements_premium_total
        liability_lob_cost=(_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium))+addl_insured_premium_total+pw_endorsements_premium_total+ws_endorsements_premium_total
        #pd_lob_cost=(_pd_premium_total+lp_insured_premium_total+_ti_premium_total+_broker_pd_fee)+pd_surplus_lines_tax+pd_stamping_fee
        pd_lob_cost=(_pd_premium_total+lp_insured_premium_total+_ti_premium_total)
        #cargo_lob_cost=(_cargo_premium_total+_broker_cargo_fee)+cargo_surplus_lines_tax+cargo_stamping_fee
        cargo_lob_cost=(_cargo_premium_total)
        try:
           
            if trailer_interchange_units=='':
                    trailer_interchange_units='0'
            if trailer_interchange_limit=='':
                trailer_interchange_limit='0'
            if cost_basis=='':
                cost_basis='0'
           
                     
        except Exception as e:
            exception_type, exception_object, exception_traceback = sys.exc_info()
            filename = exception_traceback.tb_frame.f_code.co_filename
            line_number = exception_traceback.tb_lineno
            #print(line_number)
            print(e.__str__)
        #print("******** Cargo Endorsement  ", _cargo_endorsements_totals)
        policy_level_premium={
            "Hired_auto_premium":hired_auto_premium,
            "Non_owned_Auto_Premium":non_hired_auto_premium,
            "Trailer_inter_change_premium":_ti_premium_total,
            "broker_fee_liability":_boker_liability_fee,
             "broker_fee_pd":_broker_pd_fee,
             "broker_cargo_fee":_broker_cargo_fee,
             "broker_total_fee": _broker_total_fee,
             "additional_insured":addl_insured_premium_total,
             "loss_payee":lp_insured_premium_total,
             "primary_wording":pw_endorsements_premium_total,
             "waiver_of_subrogation":ws_endorsements_premium_total,
             "cargo_endorsements": _cargo_endorsements_totals,
             "sum_of_liability": sum_of_liability,
             "sum_of_pd":_pd_premium_total+_ti_premium_total,
             "sum_of_cargo":_cargo_premium_total,
             "liability_surplus_lines_tax":liability_surplus_lines_tax,
             "pd_surplus_lines_tax":pd_surplus_lines_tax,
             "cargo_surplus_lines_tax": cargo_surplus_lines_tax,
             "liability_stamping_fee":liability_stamping_fee,
             "pd_stamping_fee":pd_stamping_fee,
             "cargo_stamping_fee":cargo_stamping_fee,
             "liability_lob_cost":liability_lob_cost,
             "pd_lob_cost":pd_lob_cost,
             "cargo_lob_cost":cargo_lob_cost,
             "package_cost":(liability_lob_cost+pd_lob_cost+cargo_lob_cost)
            
        }  
       
        
       
       
        file_name=str(uuid.uuid1())+".pdf"
       
        path_to_file = settings.MEDIA_ROOT + "pdf/"
        path_to_templates=settings.MEDIA_ROOT + "templates/"
        
        forms_info=get_quote_forms_list()
        #print(forms_info," forms info ")
        #print(insuredInfo,forms_info,state_code,um_limit,uim_limit,pip_limit,pw_endorsements,ws_endorsements,len(addlInfo),lp_endorsements,drivers,vvhs,path_to_file,file_name,path_to_templates)
        combine_pdf(insuredInfo,forms_info,state_code,um_limit,uim_limit,pip_limit,pw_endorsements,ws_endorsements,len(addlInfo),lp_endorsements,drivers,vvhs,path_to_file,file_name,path_to_templates)
        class_ids={'Surpluslines Tax':90,
               'Stamping Fee':91,
               'Auto Liability Premium':20,
               'Physical Damage Premium':40,
               'Cargo Premium':50,
               'Broker Fee':94,
               'Policy Fee':95
               
        
    }
        quote_premium={}
            
        quote_premium_item_count=0
        if _existing_quote=='Yes':
            remove_quote_premiums(quote_id)
            
        if(liability_lob_cost>0):
            quote_premium_item_count=quote_premium_item_count+1
            add_quote_premium(quote_id,20,round(liability_lob_cost,2))
            quote_premium["class_of_business_id_"+str(quote_premium_item_count)]=20
            quote_premium["class_of_business_id_"+str(quote_premium_item_count)+"_premium"]=round(liability_lob_cost,2)
            #quote_premium.add("class_of_business_id_"+str(quote_premium_item_count)+"_premium",round(liability_lob_cost,2))
        
        if(pd_lob_cost>0):
            quote_premium_item_count=quote_premium_item_count+1
            add_quote_premium(quote_id,40,round(pd_lob_cost,2))
            quote_premium["class_of_business_id_"+str(quote_premium_item_count)]=40
            quote_premium["class_of_business_id_"+str(quote_premium_item_count)+"_premium"]=round(pd_lob_cost,2)
        
        
        if(cargo_lob_cost>0):
            quote_premium_item_count=quote_premium_item_count+1
            add_quote_premium(quote_id,50,round(cargo_lob_cost,2))
            quote_premium["class_of_business_id_"+str(quote_premium_item_count)]=50
            quote_premium["class_of_business_id_"+str(quote_premium_item_count)+"_premium"]=round(cargo_lob_cost,2)
        
        
        if (liability_stamping_fee+pd_stamping_fee+cargo_stamping_fee) > 0:
              quote_premium_item_count=quote_premium_item_count+1  
              add_quote_premium(quote_id,91,round(liability_stamping_fee+pd_stamping_fee+cargo_stamping_fee,2)) 
              quote_premium["class_of_business_id_"+str(quote_premium_item_count)]=91
              quote_premium["class_of_business_id_"+str(quote_premium_item_count)+"_premium"]=round(liability_stamping_fee+pd_stamping_fee+cargo_stamping_fee,2)
        
        if (liability_surplus_lines_tax+pd_surplus_lines_tax+cargo_surplus_lines_tax) >0:
            quote_premium_item_count=quote_premium_item_count+1 
            add_quote_premium(quote_id,90,round(liability_surplus_lines_tax+pd_surplus_lines_tax+cargo_surplus_lines_tax,2)) 
            quote_premium["class_of_business_id_"+str(quote_premium_item_count)]=90
            quote_premium["class_of_business_id_"+str(quote_premium_item_count)+"_premium"]=round(liability_surplus_lines_tax+pd_surplus_lines_tax+cargo_surplus_lines_tax,2)
        
        if (_boker_liability_fee+_broker_pd_fee+_broker_cargo_fee) >0:
            quote_premium_item_count=quote_premium_item_count+1 
            add_quote_premium(quote_id,94,round(_boker_liability_fee+_broker_pd_fee+_broker_cargo_fee,2)) 
            quote_premium["class_of_business_id_"+str(quote_premium_item_count)]=94
            quote_premium["class_of_business_id_"+str(quote_premium_item_count)+"_premium"]=round(liability_surplus_lines_tax+pd_surplus_lines_tax+cargo_surplus_lines_tax,2)
           
        
        quote_pdf_bs64=get_pdf_data(file_name)
        #add_quote_premium_estimate_db --  
        res={"liability":lq,"cargo":cf,"pd": pf,"vehicles":vhs,"totals":gross_premium,"base_rate":base_rate,"ploicylevelpremium":policy_level_premium,"quotepdf":quote_pdf_bs64,"submission_id":submission_id,"quote_premium":quote_premium}
        try:
            data['submission_id']=submission_id
            #stringA = {y.decode('ascii'): res.get(y).decode('ascii') for y in res.keys()}
            #stringB = {y.decode('ascii'): data.get(y).decode('ascii') for y in data.keys()}
            #print(stringA)
            
            #add_quote_premium_estimate_db(quote_id,json.dump(res),json.dump(data)) # save premium quote in database
            add_quote_data_premium_estimate_db(quote_id,json.dumps(res,cls=BytesEncoder),json.dumps(data,cls=BytesEncoder))
        except Exception as e:
            print(e,"error in quote history adding")
            
        return   Response(res, status=status.HTTP_200_OK)   
              
    except Exception as e:
        exception_type, exception_object, exception_traceback = sys.exc_info()
        filename = exception_traceback.tb_frame.f_code.co_filename
        line_number = exception_traceback.tb_lineno
        print(line_number,exception_object)
        #print(e.__str__)
    lq=[]
    cf=[]
    pf=[]
    vhs=[]
    policy_level_premium=[]
    gross_premium=[]
    res={"liability":lq,"cargo":cf,"pd": pf,"vehicles":vhs,"totals":gross_premium,"base_rate":0,"ploicylevelpremium":policy_level_premium,"quotepdf":'quote_pdf_bs64',"submission_id":submission_id}    
    #res={"response":"Successfully generated premium"}
    return   Response(res, status=status.HTTP_200_OK)
    


     
@api_view(['POST'])
def get_premium_details1(request):   
    try:  
        data = json.loads(request.body.decode("utf-8"))
#********** Data received from front end ************#
        user_id=data['user_id']
        commodities_info=data['commoditiesInfo']
        commoditiesSelected=data['commoditiesSelected']
        coveragesInfo=data['coveragesInfo']
        drivers=data['drivers']
        print(drivers)
        
        filingInfo=data['filingInfo']
        genInfo=data['genInfo']
        insuredInfo=data['insuredInfo']
        radiusOfOperationsInfo=data['radiusOfOperationsInfo']
        vehiclesInfo=data['vehicleInfo']
        uwReviewInfo=data['uwReviewInfo']
        ai_insured=data['addlInfo']
        secondary_class=data['secondary_class']
        vehicles=data['vehicles']
        addlInfo=data['addlInfo']
        broker_info=data['broker_info']
    
        commodities_al_factor=data['commodities_al_factor']
        commodity_cargo_factor=data['commodity_cargo_factor']
        commodity_pd_factor=data['commodity_pd_factor']
        yxpliability=insuredInfo["years_of_experience"] #liability factor years of experience 
        containers_selected=data['containers_selected']
    #********** End of Data received from front end ************#
    
        class_ids={'Surpluslines Tax':90,
               'Stamping Fee':91,
               'Auto Liability Premium':20,
               'Physical Damage Premium':40,
               'Cargo Premium':50,
               'Broker Fee':94,
               'Policy Fee':95
               
        
    }
    
    
        #************ Underwriter modified factors received from UI *************#
    
        uwcreditdebitfactor_liability=uwReviewInfo["uw_credit_debit_factor"] # uw credit debit liability
        uwcreditdebitfactor_pd=uwReviewInfo["pd_uw_credit_debit_factor"] # uw credit debit pd
        uwcreditdebitfactor_cargo=uwReviewInfo["cargo_uw_credit_debit_factor"] # uw credit debit cargo
        loss_experience_factor_liability=uwReviewInfo["loss_experience_factor"]
        loss_experience_factor_pd=uwReviewInfo["pd_loss_experience_factor"]
        loss_experience_factor_cargo=uwReviewInfo["cargo_loss_experience_factor"]
        driver_factor=uwReviewInfo["driver_factor"]
    #************************End of underwriter modified data ********#
    
    #********** Producer Default contact emails and phone ***********#
        broker_default_email=broker_info['broker_default_email']
      
        broker_default_phone=broker_info['broker_default_phone']
        broker_bind_email=broker_info['broker_bind_email']
        broker_endorsements_email=broker_info['broker_endorsements_email']
        broker_cancellation_confirmation_email=broker_info['broker_cancellation_confirmation_email']
    #****************** end of producer email details ************#    
        state_code=insuredInfo['insured_garaging_state']  #garaging state code used in factors calculation
   #************ variables for selecting covearges********
        towing_yes='No' if coveragesInfo['towing']=='No' else 'Yes'
        pd_yes='No' if coveragesInfo['pd']=='No' else 'Yes'
        liability_yes='No' if coveragesInfo['liability']=='No' else 'Yes'
        cargo_yes='No' if coveragesInfo['cargo']=='No' else 'Yes'
        
        non_hired_auto_premium=''
        non_hired_auto_on_contratual_basis='No' if coveragesInfo['non_hired_auto_on_contratual_basis']=='No' else 'Yes'
        if non_hired_auto_on_contratual_basis=='Yes':
            non_hired_auto_premium=get_non_owned_auto_premium(coveragesInfo['number_of_non_owned_units'])
    
        is_pip_available=get_premium_type_availability_in_state(state_code,'PIP')
        pip_liability_per_unit=0
   
        if is_pip_available==True:
        
            pip_liability_per_unit=get_pip_premium(state_code,coveragesInfo['pip_limit'],radiusOfOperationsInfo['radius'].strip())
    
        is_uim_available=get_premium_type_availability_in_state(state_code,'UIM')
    
        if is_uim_available==False:
            uim_limit=0
        is_medical_available='No'
        trailer_interchange_yes= coveragesInfo['trailer_interchange']
        towing=0
        towing_yes='No' if coveragesInfo['towing']=='No' else 'Yes'
        if towing_yes=='Yes':
            towing=int(coveragesInfo['towing'])
        else:
            towing=0
    
        refeer_coverage_required=coveragesInfo['refeer_coverage_required'] 
        refeer_coverage=0
        if refeer_coverage_required=='Yes':
            refeer_coverage=coveragesInfo['refeer_coverage']
    
    
        usetype=vehiclesInfo['usetype']
        trailer_type=vehiclesInfo['trailer_type']
        secondry_class=commodities_info['secondary_class']
    
   
   
    #******* Variables related to premium calculation ***********#
        #_cargo_endorsements_totals=0
        riggers_cost=0
        contingent_transit_endorsement_cost=0
        nonowned_interchange_endorsement_cost=0
        ltl_endorsement_cost=0
        lp_endorsements=0
        theft_cost=0
        eggs_cost=0
        
        _gross_cargo_premium=0
        _gross_pd_premium=0
        _gross_liability_premium=0
        _liability_premium_total=0
        _um_premium_total=0
        _uim_premium_total=0
        _pip_premium_total=0
        _med_premium_total=0
        _pd_premium_total=0
        _ti_premium_total=0
        _tow_premium_total=0
        _cargo_premium_total=0
    
        broker_fees_liability=0
        broker_fees_pd=0
        broker_fees_cargo=0
    
        territory_code=get_territory_code_by_zipcode( insuredInfo['insured_garaging_zip'])
    
        ilf_factor=get_ilf_factor()
        lcm_factor=get_lcm_factor()
        pollution_factor=get_pollution_factor()
        state_factor=get_state_factor()
        rate_control_factor=get_rate_control_factor()
        primary_factor=get_primary_factor()
        radius_factor=get_radius_factor(radiusOfOperationsInfo['radius'])
        use_type_factor=get_type_of_use_factor(usetype)
        trailer_type_factor=get_trailer_type_factor(trailer_type)
    
    
    
    
    
    
    
    #******** Date conversion related to effective and expiration date ****#
        effective_date=genInfo['effective_date']
        expiration_date=genInfo['expiration_date']
        dparts=effective_date.split('/')
        _effective_date=dparts[2]+'/'+dparts[0]+'/'+dparts[1]
        dparts=expiration_date.split('/')
        _expiration_date=dparts[2]+'/'+dparts[0]+'/'+dparts[1]
    #print(_effective_date,_expiration_date)
   #********* variables needed in submission ********//
        agency_id=data["agency_id"]
        user_id=data["user_id"]
   
        submission_id= add_submission_new_db(agency_id, _effective_date,_expiration_date, broker_default_email, broker_default_phone, broker_bind_email, broker_endorsements_email,broker_cancellation_confirmation_email,user_id)
    
        if submission_id > -1:
        
            insured_id=add_insured(insuredInfo,filingInfo,submission_id)   
     
     
            quote_id=add_quote_new_db(submission_id,user_id,genInfo['company'],genInfo['lob'])
        
            coverages_id=add_coverages(coveragesInfo,secondary_class,quote_id)
            general_info_id=add_general_info(coveragesInfo['quotetype'],coveragesInfo['policytype'],genInfo['company'],genInfo['lob'],coveragesInfo['billtype'],quote_id)
            radius_id=add_radius_of_operation(radiusOfOperationsInfo['radius'],
                                         radiusOfOperationsInfo['Intrastate_interstate'],
                                         radiusOfOperationsInfo['state_1'],
                                         radiusOfOperationsInfo['state_2'],
                                         radiusOfOperationsInfo['state_3'],
                                         radiusOfOperationsInfo['state_4'],
                                         quote_id
                                         )
            #for commodity adding
            for cdt in commoditiesSelected:
                cdt_id=add_quote_commodity(cdt,quote_id)  
          
            driver_factor_max=0
            drv_factor=1
            drivers_factors=[]
            try:
                #Calculation of driver factor
                for drv in drivers:
                
                    age=calculateAge((drv["dob"]))
                
                    drv_factors=calculate_driver_factor((drv['licenseclasstype']),(drv['experience']),(drv['licensestate']),age,(drv['violations']))
                
                    if driver_factor_max==0:
                        driver_factor_max=drv_factors['factor']
                    elif driver_factor_max<drv_factors['factor']:
                        driver_factor_max=drv_factors['factor']
                
                    dtparts=(drv['dob']).split('/')
                    newdt=dtparts[2]+'-'+dtparts[0]+'-'+dtparts[1]
                
                    dv=Driver((drv['name']),
                          newdt,
                          (drv['licenseno']),
                          (drv['experience']),
                          (drv['licensestate']),
                          (drv['licenseclasstype']),
                          (drv['licensemedicalexp']),
                          (drv['licenseexpdate']),
                          (drv_factors['points']),
                          drv_factors['factor'])
               
                    drivers_factors.append(dv)
                if driver_factor_max==0:
                    driver_factor_max=1
           
            
                for drvf in drivers_factors:
                
                    driver_id=add_driver(dv) 
                
            except Exception as e:
                print(e," age ")
        #print("driver factor after calculation",driver_factor_max )
        
            if(driver_factor_max==0):
                driver_factor='1'
            else:
                driver_factor=str(driver_factor_max)
        
        
        
            lst_base_rate_territory_factor=get_base_rate_and_territory_factor( territory_code,state_code)
            base_rate=lst_base_rate_territory_factor.get("base_rate")
            um_premium=0
            uim_premium=0
            territory_code=get_territory_code_by_zipcode(state_code) 
            if base_rate==0:
                lq=[]
                cf=[]
                pf=[]
                vhs=[]
                gross_premium=[]
                res={"liability":lq,"cargo":cf,"pd": pf,"vehicles":vhs,"totals":gross_premium,"base_rate":0}
                return   Response(res, status=status.HTTP_200_OK) 
            territory_factor=lst_base_rate_territory_factor.get("territory_factor")
            ilf_factor=get_ilf_factor()
            lcm_factor=get_lcm_factor()
            pollution_factor=get_pollution_factor()
            state_factor=get_state_factor()
            rate_control_factor=get_rate_control_factor()
            primary_factor=get_primary_factor()
            radius_factor=get_radius_factor(radiusOfOperationsInfo['radius'])
            use_type_factor=get_type_of_use_factor(usetype)
            trailer_type_factor=get_trailer_type_factor(trailer_type)
            
            
            liability_limit_factor=1
            if liability_yes=='Yes':
                liability_limit_factor= get_liability_limit_factor(coveragesInfo['liability'])
            else:
                liability_limit_factor=1
             
            safer_factor=get_safer_factor(filingInfo['safer_factor'])
        
            liability_years_of_experience_factor=get_years_of_experience_factor(yxpliability)
        
            pd_years_of_experience_factor=get_years_of_experience_factor(yxpliability)
            cargo_years_of_experience_factor=get_years_of_experience_factor(yxpliability)
            secondary_class_factor=get_secondary_class_factor(data['secondary_class'])
     
            type_of_use_factor=get_type_of_use_factor(usetype)
     
            base_ratefactor=1
            cargo_state_factor=1
            cargo_radius_factor=1
            cargo_limit_factor=1
            cargo_deductible_factor=1
     
            _cargo_refeer_deductible_factor=1
            #coveragesInfo['cargo']
            #if cargo_limit!='No':
            if coveragesInfo['cargo']!='No':
                
                base_ratefactor=get_cargo_base_rate()
                cargo_state_factor=get_cargo_state_factor(state_code)
                cargo_radius_factor=get_cargo_radius_factor(radiusOfOperationsInfo['radius'])
                cargo_limit_factor=get_cargo_limit_factor(coveragesInfo['cargo'])
                cargo_deductible_factor=get_cargo_deductible_factor(coveragesInfo['cargo_deductible'])
                if refeer_coverage_required!='No':
                    _cargo_refeer_deductible_factor=get_cargo_refeer_deductible_factor(coveragesInfo['refeer_coverage'])
        
            if coveragesInfo['hired_auto_liability']!='No':
                if coveragesInfo['hired_auto_type']=='Primary':
                    hired_auto_premium=0.02*int(coveragesInfo['cost_basis'])
                else:
                    hired_auto_premium=0.08*int(coveragesInfo['cost_basis']) 
            if coveragesInfo['non_hired_auto_limit']!='No':
                if coveragesInfo['non_hired_auto_on_contratual_basis']!='No' and coveragesInfo['number_of_non_owned_units']!='':
                #print(number_of_non_owned_units,type(number_of_non_owned_units),"Non owned units")
                    non_hired_auto_premium=str(get_non_owned_auto_premium(coveragesInfo['number_of_non_owned_units']))
                #print(non_hired_auto_premium," Non owned units...")
                
            vehicle_type_factor=1
            vehicle_make_factor=1
            pd_base_rate_factor=1
            pd_state_factor=1
            pd_deductible_factor=1
            pd_um_amount=100
            _base_ratefactor=1
            _cargo_state_factor=1
            _cargo_radius_factor=1
            _cargo_limit_factor=1
            _cargo_deductible_factor=1
            _pd_base_rate_factor=1
            _pd_vehicle_make_factor=1
            _pd_state_factor=1
            _pd_deductible_factor=1
        
        
            vehicle_trailer_interchange_premium=0
     
            power_units=0
            pos=1
            for v in vehicles:
                #print(v,pos)
                pos=pos+1
          
                if v["model"].upper()=='TRACTOR' or v["model"].upper()=='TRUCK':
                    power_units=power_units+1
                vehicle_type_factor=get_vehicle_type_factor(v["model"])
                vehicle_model_factor=get_vehicle_weight_factor(v["weight"])
            
                vehicle_make_factor=get_pd_vehicle_make_factor(v["make"])
                pd_base_rate_factor=get_pd_base_rate_factor(v["stated_value"])
                pd_state_factor=get_pd_state_factor(state_code)
                pd_deductible_factor=get_pd_deductible_factor(v["deductible"])
                if coveragesInfo['um_limit']=='No' and v['um']==True and ( v["model"].upper() !='TRAILER' and v["model"].upper() !='NON-OWNED-TRAILER'):
                
                    pd_um_amount=data['um_unit_rate']
                    _um_premium_total=_um_premium_total+pd_um_amount
               
                else:
                    pd_um_amount=0
            
                if coveragesInfo['cargo'] !='No' and ( v["model"].upper() !='TRAILER' and v["model"].upper() !='NON-OWNED-TRAILER'):
                    #print("In cargo calculation 1")
                    _base_ratefactor=base_ratefactor
                    _cargo_state_factor=cargo_state_factor
                    _cargo_radius_factor=cargo_radius_factor
                    _cargo_limit_factor=cargo_limit_factor
                    _cargo_deductible_factor=cargo_deductible_factor
                
           
                else:
                    _base_ratefactor=1
                    _cargo_state_factor=1
                    _cargo_radius_factor=1
                    _cargo_limit_factor=1
                    _cargo_deductible_factor=1
            
            
            
                liability_premium=0
                uim_premium=0
                
                #print(coveragesInfo['liability']," liability premium calculation begin")
                if coveragesInfo['liability'] !='No':
                    #print(" calc liability premium")
                    try:
                        liability_premium=calculate_liability_premium(base_rate,
                                                                  territory_factor,
                                                                  lcm_factor,
                                                          ilf_factor,
                                                          primary_factor,
                                                          pollution_factor,
                                                          state_factor,
                                                          rate_control_factor,
                                                          vehicle_model_factor,
                                                          radius_factor,
                                                          commodities_al_factor,
                                                          float(driver_factor),
                                                          float(loss_experience_factor_liability),
                                                          safer_factor,
                                                          liability_years_of_experience_factor,
                                                          float(uwcreditdebitfactor_liability),
                                                          liability_limit_factor,
                                                          type_of_use_factor,
                                                          secondary_class_factor
                                                          ,trailer_type_factor
                                                         
                                                          )
                   
                    
                    
                    #liability_premium=liability_premium+um_premium+uim_premium+hired_auto_premium+int(non_hired_auto_premium)
                        _gross_liability_premium=_gross_liability_premium+liability_premium
                        _liability_premium_total=_liability_premium_total+liability_premium
                    
                        _uim_premium_total=_uim_premium_total+uim_premium
                
                    
                    
                    except Exception as e:
                        print(e," problem with liability XXXXXXX")
                        #pass
               
            cargo_premium=0
        
           
            if coveragesInfo['cargo'] !='No' and  (v["model"].upper()=='TRACTOR' or v["model"].upper()=='TRUCK'):
                #print(v["model"].upper(),"cargo cal")
                try:
                    cargo_premium=calculate_cargo_premium(_base_ratefactor,_cargo_state_factor,float(driver_factor),float(loss_experience_factor_cargo),
                                                  float(uwcreditdebitfactor_cargo),commodity_cargo_factor,
                                                  cargo_years_of_experience_factor,rate_control_factor,
                                                  safer_factor, _cargo_radius_factor,_cargo_limit_factor,_cargo_deductible_factor,
                                                  _cargo_refeer_deductible_factor) 
                    print(cargo_premium," in premium calculation")
                    _gross_cargo_premium=_gross_cargo_premium+ cargo_premium
                    _cargo_premium_total=_cargo_premium_total+cargo_premium
                    print(_gross_cargo_premium,"  Gross cargo premium")
                except Exception as e:
                    print(e," problem with cargo")
            else:
                print(v["model"].upper()," cargo calc")  
                cargo_premium=0     
            pd_premium=0
            vehicle_towing_premium=0
        
            if coveragesInfo['pd']!='No':
                
                _pd_base_rate_factor=get_pd_base_rate_factor(int(v['stated_value']))
                
                _pd_vehicle_make_factor=get_pd_vehicle_make_factor(v['make'])
                _pd_state_factor=get_pd_state_factor(state_code)
                _pd_deductible_factor=get_pd_deductible_factor(v['deductible'])
                
                if v['tow']==True:
                    vehicle_towing_premium=get_towing_premium(towing)
                else:
                    vehicle_towing_premium=0
                if v['tow']==True:
                        _tow_premium_total=_tow_premium_total+vehicle_towing_premium
                
                try:
                    
                   
                    pd_premium=calculate_pd_premium(float(v['stated_value']),pd_base_rate_factor,_pd_vehicle_make_factor,_pd_state_factor,
                                            float(driver_factor),float(loss_experience_factor_pd),float(uwcreditdebitfactor_pd),
                                            _pd_deductible_factor,commodity_pd_factor,
                                            pd_years_of_experience_factor,rate_control_factor,safer_factor)
                    
                    _pd_premium_total=_pd_premium_total+pd_premium
                    
                    
                   
                    _gross_pd_premium=_gross_pd_premium+pd_premium
                    
                    if coveragesInfo['trailer_interchange']!='No':
                        if v['model'].upper()=='TRACTOR' or v['model'].upper()=='TRAILER':
                            vehicle_trailer_interchange_premium=calculate_trailer_interchange_premium(
                            float(v['stated_value']),pd_base_rate_factor,_pd_vehicle_make_factor,_pd_state_factor,
                                            float(driver_factor),float(loss_experience_factor_pd),float(uwcreditdebitfactor_pd),
                                            _pd_deductible_factor,commodity_pd_factor,
                                            pd_years_of_experience_factor,rate_control_factor,safer_factor,trailer_type_factor,containers_selected
                            )  
                        else :   
                            vehicle_trailer_interchange_premium=0
                              
                #Trailer interchange Premium calculation################
                    _ti_premium_total=_ti_premium_total+vehicle_trailer_interchange_premium 
                except Exception as e:
                    print(e," problem with pd")
                    
            um_premium=0
            
            veh_medical_premium=0
            
            if coveragesInfo['medical_limit']!='No':
                veh_medical_premium=get_medical_premium(state_code,coveragesInfo['medical_limit'])
            else:
                veh_medical_premium=0
            _med_premium_total=_med_premium_total+veh_medical_premium
            
            vehicle_pip_limit=0
        
            vehicle_pip_premium=pip_liability_per_unit
            _pip_premium_total=_pip_premium_total+vehicle_pip_premium
           
            
            vehicle_cargo_reefer_factor=get_cargo_refeer_deductible_factor(refeer_coverage)
            
            um_premium=0
            #for v in vehicles:
            #    print(v["model"].upper(),"  in for loop")
            if (v["model"].upper()=='TRUCK' or v["model"].upper()=='TRACTOR') and coveragesInfo['um_limit']!='No' :
                    
               
                    #print(v['um'],"**************************")
                    if v['um']==True:
                        _um_premium_total=_um_premium_total+um_premium
                        um_premium=data['um_unit_rate']
                    else:
                        um_premium=0
               
                    uim_premium=0
                    _quotedate=datetime.datetime.now().strftime("%Y-%m-%d")
           
            #vehicle_model_factor=get_vehicle_model_factor(v["weight"])
                    veh=Vehicle(v["make"], #1
                        v["model"], #2
                        v["year"], # 3
                        vehicle_type_factor, #4
                        vehicle_make_factor, #5
                        str(vehicle_model_factor), #6 vehicle
                        pd_deductible_factor,#7
                        v['stated_value'],#8
                        v['deductible'],#9
                        'true' if coveragesInfo['um_limit']!='No' else 'false', #10
                        str(um_premium), #11
                        '0' if coveragesInfo['um_limit']=='No' else data['um_unit_rate'], #12
                        'true' if uim_limit !='' else 'false',#13
                        
                        uim_premium, #14
                        'true' if coveragesInfo['medical_limit'] !='No' else 'false', #15
                        coveragesInfo['medical_limit'] if coveragesInfo['medical_limit']!='No' else '0', #16
                        str(veh_medical_premium), #17
                        str(pd_premium), #18
                        'true' if coveragesInfo['liability'] !='No' else 'false', #19
                        '0' if coveragesInfo['liability']=='No' else coveragesInfo['liability'], #20
                        str(liability_premium), #21
                        'true' if coveragesInfo['pip_limit']!='No' else 'false', #22
                        vehicle_pip_limit,#23
                        vehicle_pip_premium,#24
                        'true' if coveragesInfo['trailer_interchange']!='No' else 'false', #25
                        '0' if coveragesInfo['trailer_interchange']=='No' else coveragesInfo['trailer_interchange_units'] , #26
                        vehicle_trailer_interchange_premium, #27
                        'true' if towing !='' else 'false', #28
                        towing if v['tow'] ==True else  '0', #29
                        vehicle_towing_premium, #30
                        'true' if coveragesInfo['cargo']!='No' else 'false', #31
                        '0'  if coveragesInfo['cargo']=='No' else coveragesInfo['cargo'], #32
                        '0' if coveragesInfo['cargo']=='No' else coveragesInfo['cargo_deductible'], #33
                        str(cargo_deductible_factor),#34
                        str(cargo_premium),#35
                        'true' if refeer_coverage_required !='' else 'false', #36
                        refeer_coverage, #37
                        str(vehicle_cargo_reefer_factor),#38
                        str(_cargo_refeer_deductible_factor),#39
                        str(quote_id),#40
                        _quotedate,v['weight'],v['vin'],v['o_l_rent']) #41
                    if coveragesInfo['liability'] !='No':
                        lxref=LiabilityXref(str(quote_id),str(base_rate),str(territory_factor),
                                             str(lcm_factor),str(ilf_factor),str(pollution_factor),
                                             str(state_factor),str(rate_control_factor),
                                             str(vehicle_model_factor),str(radius_factor),str(commodities_al_factor),
                                             str(driver_factor),str(safer_factor),
                                             str(liability_years_of_experience_factor),
                                             str(liability_limit_factor),str(secondary_class_factor),
                                             str(trailer_type_factor),str(primary_factor),
                                             str(uwcreditdebitfactor_liability),
                                             str(loss_experience_factor_liability),
                                             str(type_of_use_factor),)
                    if  coveragesInfo['pd']=='Yes':
                        pdxref=PDXref(str(quote_id),
                              str(v['stated_value']),str(pd_base_rate_factor),
                              str(vehicle_make_factor),str(vehicle_model_factor),str(pd_state_factor),
                              str(rate_control_factor),
                              str(commodity_pd_factor),str(driver_factor),
                              str(safer_factor),str(pd_years_of_experience_factor),
                              str(pd_deductible_factor),uwcreditdebitfactor_pd,
                              loss_experience_factor_pd
                              )
                    if  coveragesInfo['cargo'] !='No':
                        cargoxref=CargoXref(str(quote_id),
                                    str(_base_ratefactor),
                                     str(_cargo_state_factor),
                                     str(driver_factor),
                                     str(rate_control_factor),
                                     str(commodity_cargo_factor),
                                     str(safer_factor),
                                     str(cargo_years_of_experience_factor),
                                     str(_cargo_deductible_factor),
                                     str(vehicle_cargo_reefer_factor),
                                     uwcreditdebitfactor_cargo,
                                     loss_experience_factor_cargo,
                                     str( _cargo_radius_factor),
                                     str(_cargo_limit_factor)
                                     
                                     )
                                             
            
                    try:
                        add_vehicledetails(veh)
                        if coveragesInfo['liability'] !='No':
                            add_liabilityxref(lxref)
                        if  coveragesInfo['pd']=='Yes':
                    #print("Doing Pd")
                            add_pdxref(pdxref)
                        if coveragesInfo['cargo']!='No':
                            add_cargoxref(cargoxref)
                    except Exception as e:
                        print(e," error at vehicle adding")  
                        #continue
                    _boker_liability_fee=get_liability_broker_fee(str(power_units)) 
                    print(_liability_premium_total,"Liability Total")
                    lp_insured_premium_total=0
                    if lp_endorsements>0:
                        lp_insured_premium_total=lp_endorsements*100
                    _broker_pd_fee=get_pd_broker_fee(str(int(_pd_premium_total)))+lp_insured_premium_total  
                    print(_cargo_premium_total," cargo premium total")
                    _broker_cargo_fee=get_cargo_broker_fee(str(int(_cargo_premium_total)))
                    _broker_total_fee=_boker_liability_fee+_broker_pd_fee+_broker_cargo_fee
        
        #update_quote(str(_quoteid),str( _broker_total_fee),str( _boker_liability_fee),str(_broker_pd_fee),
         #            str(_broker_cargo_fee),'true' if trailer_interchange=='Yes' else 'false',trailer_interchange_units,trailer_interchange_limit,str(_ti_premium_total))
                    cf=[]
                    cargo_factors=''
        #print(coveragesInfo['cargo']!='No',' Cargo limit checking')
                    if  coveragesInfo['cargo']!='No':
                        cargo_factors=get_cargo_xref_factors(str(quote_id))
                    for i in cargo_factors:
                        cf.append(i[0])
                        break
                    pd_factors=''
                    pf=[]
                    if  coveragesInfo['pd']=='Yes':
                        pd_factors=get_pd_xref_factors(str(quote_id))
                    for i in pd_factors:
                        pf.append(i[0])
                        break
                    liability_factors=''
                    lq=[]
                    if coveragesInfo['liability'] !='No':
                        liability_factors=get_liability_xref_factors(str(quote_id))
                    lq=[]
                    for i in liability_factors:
                        lq.append(i[0])
                
                        break
            
                    vehicles=get_vehicles_premium(str(quote_id))
                    vhs=[]
        
                    for i in vehicles:
                        vhs.append(i[0])
                    gross_premium={"liability":
            _liability_premium_total,
            "um":_um_premium_total,
            "uim":_uim_premium_total,
            "pip":_pip_premium_total,
            "med":_med_premium_total,
            "pd":_pd_premium_total,
            #"ti":_ti_premium_total,
            "tow":_tow_premium_total,
            "cargo":_cargo_premium_total
            
            }
        #print(gross_premium," Gross Premium totals")
        
                    sum_of_liability=_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)
                    pw_endorsements=0
                    ws_endorsements=0
                    addl_insured_premium_total=0
                    if len(ai_insured)>0:
                        addl_insured_premium_total=100*len(ai_insured)
        
        
                    pw_endorsements_premium_total=0
                    ws_endorsements_premium_total=0
                    if pw_endorsements>0:
                        pw_endorsements_premium_total=pw_endorsements*250
                    if ws_endorsements>0:
                        ws_endorsements_premium_total=ws_endorsements*250
                    sum_of_liability=sum_of_liability+addl_insured_premium_total+pw_endorsements_premium_total+ws_endorsements_premium_total    
                    liability_surplus_lines_tax=0
                    liability_surplus_lines_tax=round((_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)+_boker_liability_fee+addl_insured_premium_total+pw_endorsements_premium_total+ws_endorsements_premium_total)*0.03,2)
                    pd_surplus_lines_tax=round((_pd_premium_total+_ti_premium_total+lp_insured_premium_total+_broker_pd_fee)*0.03,2)
                    cargo_surplus_lines_tax=0
                    cargo_surplus_lines_tax=round((_cargo_premium_total+_broker_cargo_fee)*0.03,2)
                    liability_stamping_fee=round((_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)+_boker_liability_fee+addl_insured_premium_total)*0.0025,2)
                    pd_stamping_fee=(_pd_premium_total+_ti_premium_total+lp_insured_premium_total+_broker_pd_fee)*0.0025
                    cargo_stamping_fee=(_cargo_premium_total+_broker_cargo_fee)*0.0025
                    liability_lob_cost=(_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)+_boker_liability_fee)+liability_surplus_lines_tax+liability_stamping_fee+addl_insured_premium_total+pw_endorsements_premium_total+ws_endorsements_premium_total
                    pd_lob_cost=(_pd_premium_total+lp_insured_premium_total+_ti_premium_total+_broker_pd_fee)+pd_surplus_lines_tax+pd_stamping_fee
                    cargo_lob_cost=(_cargo_premium_total+_broker_cargo_fee)+cargo_surplus_lines_tax+cargo_stamping_fee
                    try:
                        print(trailer_interchange_units," check 1")
                        if trailer_interchange_units=='0':
                            trailer_interchange_units='0'
                        print(trailer_interchange_limit," check 2")
                        if trailer_interchange_limit=='':
                            trailer_interchange_limit='0'
                        if cost_basis=='':
                            cost_basis='0'
            # update_quote_all(str(quote_id),
            #                  str( round(_broker_total_fee,2)),
            #                  str(round( _boker_liability_fee,2)),
            #                  str(round(_broker_pd_fee,2)),
            #          str(round(_broker_cargo_fee,2)),
            #          'true' if coveragesInfo['trailer_interchange']=='Yes' else 'false',coveragesInfo['trailer_interchange_units'] ,
            #          str(coveragesInfo['trailer_interchange_limit']),
            #          str(_ti_premium_total),
            #          'False'  if coveragesInfo['hired_auto']=='' else 'True',
            #          '0' if cost_basis=='' else cost_basis,
            #          str(hired_auto_premium),
            #          str(non_hired_auto_premium),
            #          str(liability_surplus_lines_tax+pd_surplus_lines_tax+cargo_surplus_lines_tax),
            #          str(liability_stamping_fee+pd_stamping_fee+cargo_stamping_fee),
            #          str(liability_lob_cost+pd_lob_cost+cargo_lob_cost),
            #          str(round(liability_lob_cost,2)),
            #          str(round(pd_lob_cost,2)),
            #          str(round(cargo_lob_cost,2)),
            #          str(addl_insured_premium_total),'True',str(lp_insured_premium_total),
            #          'True' if pw_endorsements>0 else 'False',
            #          str(pw_endorsements_premium_total),str(ws_endorsements_premium_total),
            #          str(ltl_endorsement_cost),
            #          str(eggs_cost),
            #          str(riggers_cost),
            #          'True',
            #          'True',
            #          'True','0',
            #          'True')
            # print(company," company")
            #if  quote_id > -1:
                #if coveragesInfo['liability'] !='No':
                    
                    #qinfo=QuoteInfo('','Y',submission_id,-1,_liability_app_id,10069,-1,-1,-1,-1)
                    #q_info_id=add_quote_info(qinfo)
                    #add_quote_premium(quote_id,20,round(liability_lob_cost,2))
                    #liability_surplus_lines_tax
                    #add_quote_premium(quote_id,90,round(liability_surplus_lines_tax,2))
                    #add_quote_premium(quote_id,90,round(liability_surplus_lines_tax,2))
                    
                #if coveragesInfo['cargo']!='No':
                    
                    #qinfo=QuoteInfo('','Y',submission_id,-1, _cargo_app_id,10069,-1,-1,-1,-1)
                    #q_info_id=add_quote_info(qinfo)
                    #add_quote_premium(quote_id,50,round(cargo_lob_cost,2))
                    #add_quote_premium(quote_id,90,round(cargo_surplus_lines_tax,2))
                #if  coveragesInfo['pd']=='Yes':
                    #qinfo=QuoteInfo('','Y',submission_id,-1, _pd_app_id,10069,-1,-1,-1,-1)
                    #q_info_id=add_quote_info(qinfo)
                    #add_quote_premium(quote_id,40,round(pd_lob_cost,2))
            #add_comp_lob_submission(str(company),str(lob),str(submission_id))
                     
                    except Exception as e:
                        exception_type, exception_object, exception_traceback = sys.exc_info()
                    filename = exception_traceback.tb_frame.f_code.co_filename
                    line_number = exception_traceback.tb_lineno
                    print(line_number)
                    print(e.__str__)
        #print("******** Cargo Endorsement  ", _cargo_endorsements_totals)
                    policy_level_premium={
            "Hired_auto_premium":hired_auto_premium,
            "Non_owned_Auto_Premium":non_hired_auto_premium,
            "Trailer_inter_change_premium":_ti_premium_total,
            "broker_fee_liability":_boker_liability_fee,
             "broker_fee_pd":_broker_pd_fee,
             "broker_cargo_fee":_broker_cargo_fee,
             "broker_total_fee": _broker_total_fee,
             "additional_insured":addl_insured_premium_total,
             "loss_payee":lp_insured_premium_total,
             "primary_wording":pw_endorsements_premium_total,
             "waiver_of_subrogation":ws_endorsements_premium_total,
             "cargo_endorsements": _cargo_endorsements_totals,
             "sum_of_liability": sum_of_liability,
             "sum_of_pd":_pd_premium_total+_ti_premium_total,
             "sum_of_cargo":_cargo_premium_total,
             "liability_surplus_lines_tax":liability_surplus_lines_tax,
             "pd_surplus_lines_tax":pd_surplus_lines_tax,
             "cargo_surplus_lines_tax": cargo_surplus_lines_tax,
             "liability_stamping_fee":liability_stamping_fee,
             "pd_stamping_fee":pd_stamping_fee,
             "cargo_stamping_fee":cargo_stamping_fee,
             "liability_lob_cost":liability_lob_cost,
             "pd_lob_cost":pd_lob_cost,
             "cargo_lob_cost":cargo_lob_cost,
             "package_cost":(liability_lob_cost+pd_lob_cost+cargo_lob_cost)
            
        }
        
        
    
    
                    file_name=str(uuid.uuid1())+".pdf"
       
                    path_to_file = settings.MEDIA_ROOT + "pdf/"
                    path_to_templates=settings.MEDIA_ROOT + "templates/"
        
                    forms_info=get_quote_forms_list()
        
                  #  combine_pdf(insuredInfo,forms_info,insuredInfo['insured_name'],state_code,coveragesInfo['um_limit'],coveragesInfo['uim_limit'],coveragesInfo['pip_limit'],pw_endorsements,ws_endorsements,addlInfo,lp_endorsements,drivers,vhs,path_to_file,file_name,path_to_templates)
        
                    quote_pdf_bs64=get_pdf_data(file_name)
                    print({"liability":lq,"cargo":cf,"pd": pf,"vehicles":vhs,"totals":gross_premium,"base_rate":base_rate,"ploicylevelpremium":policy_level_premium,"quotepdf":'quote_pdf_bs64',"submission_id":submission_id})
                    res={"liability":lq,"cargo":cf,"pd": pf,"vehicles":vhs,"totals":gross_premium,"base_rate":base_rate,"ploicylevelpremium":policy_level_premium,"quotepdf":'quote_pdf_bs64',"submission_id":submission_id}
       
                    return   Response(res, status=status.HTTP_200_OK)   
              
    except Exception as e:
            exception_type, exception_object, exception_traceback = sys.exc_info()
            filename = exception_traceback.tb_frame.f_code.co_filename
            line_number = exception_traceback.tb_lineno
            print(line_number," error line ")
            print(e.__str__)
    res={"response":"Successfully generated premium"}
    return   Response(res, status=status.HTTP_200_OK)
    
    #res={"response":data}
    
    #print(res)
    
    #return   Response(res, status=status.HTTP_200_OK)
    
@api_view(['POST'])
def generate_premium_details(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    try:
        _liability_app_id=100
        _liability_risk_company_id=210
        _liability_lob_id=120
        _liability_market_company_id=450
        
        _pd_app_id=101
        _pd_risk_company_id=210
        _pd_lob_id=123
        _pd_market_company_id=450
        
        _cargo_app_id=102
        _cargo_risk_company_id=210
        _cargo_lob_id=123
        _cargo_market_company_id=450
        _insured_id=-1
        _cargo_endorsements_totals=0
        
        #comapany_id=data['company']
        
        #print('copmany  ',comapany_id)
        #lod_id=data['lob']
        
        #print('lob ',lob)
        
        contingent_transit_endorsement=(data["contingent_transit_endorsement"])
        if contingent_transit_endorsement=='Yes':
            contingent_transit_endorsement_cost=(data["contingent_transit_endorsement_cost"])
           
            if contingent_transit_endorsement_cost.strip()!='':
                _cargo_endorsements_totals=_cargo_endorsements_totals+float(contingent_transit_endorsement_cost.strip())
        
        
        nonowned_interchange_endorsement=data["nonowned_interchange_endorsement"]
        if nonowned_interchange_endorsement=='Yes':
            nonowned_interchange_endorsement_cost=data["nonowned_interchange_endorsement_cost"]
           
            if nonowned_interchange_endorsement_cost.strip()!='':
                _cargo_endorsements_totals=_cargo_endorsements_totals+float(nonowned_interchange_endorsement_cost.strip())
        ltl_endorsement_cost='0'
        ltl_endorsement=data["ltl_endorsement"]
        if ltl_endorsement=='Yes':
            ltl_endorsement_cost=data["ltl_endorsement_cost"]
           
            if ltl_endorsement_cost.strip()!='':
                _cargo_endorsements_totals=_cargo_endorsements_totals+float(ltl_endorsement_cost.strip())
        eggs_cost='0'
        eggs_endorsement=data["eggs_endorsement"]
        if eggs_endorsement=='Yes':
            eggs_cost=data["eggs_cost"]
           
            
            if eggs_cost.strip()!='':
                _cargo_endorsements_totals=_cargo_endorsements_totals+float(eggs_cost.strip())
        
        theft_endorsement=data["theft_endorsement"]
        if theft_endorsement=='Yes':
            theft_cost=data["theft_cost"]
           
            if theft_cost.strip()!='':
                _cargo_endorsements_totals=_cargo_endorsements_totals+float(theft_cost.strip())
        riggers_cost='0'
        riggers_endorsement=data["riggers_endorsement"]
        if riggers_endorsement=='Yes':
            riggers_cost=data["riggers_cost"]
            
            if riggers_cost.strip()!='':
                _cargo_endorsements_totals=_cargo_endorsements_totals+float(riggers_cost.strip())
        
        
        insured_name=data["insured_name"]
        insured_dba=''
        #insured_entity=data['entity_type']
        efd=data["effective_date"]
        insured_email=''
        history=''
        #name_on_policy=data['insured_policy_name']
        entity_type=''
        insured_owner_operator=''
        insured_phone=''
        does_insured_have_dot_number='No'
        does_insured_need_state_filings='No'
        insured_rating_on_safer_fmcsa_website=''
        
        
        dparts=efd.split('/')
        _effective_date=dparts[2]+'/'+dparts[0]+'/'+dparts[1]
        
       
        company=data["company"]
        lob=data["lob"]
        submission_id=data["submission_id"]
        user_id=data["user_id"]
        dot_number=data["dot_number"]
        permit_number=data["permit_number"]
        mc_number=data["mc_number"]
        insured_name=data["insured_name"]
        effective_date=data["effective_date"]
        expiration_date=data["expiration_date"]
        years_of_experience=data["years_of_experience"]
        insured_garaging_city=data["insured_garaging_city"]
        insured_garazing_address=data["insured_garaging_address"]
        insured_garaging_state=data["insured_garaging_state"]
        insured_garazing_zip=data["insured_garaging_zip"]
        insured_mailing_address=data["insured_mailing_address"]
        insured_mailing_city=data["insured_mailing_city"]
        insured_mailing_state=data["insured_mailing_state"]
        insured_mailing_zip=data["insured_mailing_zip"]
        containers_selected=data["containers_selected"]
        
        insured_info={
            "insured_name":insured_name,
            "insured_garaging_address":insured_garazing_address,
            "insured_garaging_city":insured_garaging_city,
            "insured_garaging_state":insured_garaging_state,
            "insured_garazing_zip":insured_garazing_zip,
            "effective_date":effective_date,
            "expiration_date":expiration_date,
            "years_of_experience":years_of_experience
            
            
            
        }
        
       
                         
                         
                         
                         
                        
     
        towing_yes=data["towing"]
        pd=data["pd"]
    
     
        trailer_interchange=data["trailer_interchange"]
        
        trailer_interchange_limit=data["trailer_interchange_limit"]
        trailer_interchange_units=data["trailer_interchange_units"]
        
            
     
     
        liability=data["liability"] # liablity limit
        cargo_limit=data["cargo_limit"] # cargo limit
     
        um_limit=data["um_limit"] # um limit
        um_unit_rate=data["um_unit_rate"]
        uim_limit=data["uim_limit"] # uim limit
        pip_limit=data["pip_limit"] # pip limit
        medical_limit=data["medical_limit"] # medical limit
        
        hired_auto_liability=data["hired_auto_liability"] # hired auto limit
        hired_auto_type=data["hired_auto_type"]
        cost_basis=data["cost_basis"]
        non_hired_auto_limit=data["non_hired_auto_limit"]
        non_hired_auto_on_contratual_basis=data["non_hired_auto_on_contratual_basis"]
        number_of_non_owned_units=data["number_of_non_owned_units"]
        non_hired_auto_premium='0'
        state_code= insured_garaging_state
        vehicle_towing_premium='0'
        pw_endorsements=data["pw_endorsements"]
        ws_endorsements=data["ws_endorsements"]
        ai_endorsements=data["ai_endorsements"]
        lp_endorsements=data["lp_endorsements"]
        
        if non_hired_auto_on_contratual_basis=='Yes' and  number_of_non_owned_units!='':
            non_hired_auto_premium=str(get_non_owned_auto_premium(number_of_non_owned_units))
        um_premium=0
        uim_premium=0
        territory_code=get_territory_code_by_zipcode(zipcode)  
        
        pip_liability_per_unit=0  
        if  pip_limit!='':
           
            is_available=get_premium_type_availability_in_state(state_code,'PIP')
            
            if  is_available==True:
                    
                    pip_liability_per_unit=get_pip_premium(state_code,pip_limit,data["radius"].strip())
                    
            else:
                    pip_liability_per_unit=0
        if  uim_limit!='':
            if  get_premium_type_availability_in_state(state_code,'UIM')==False:
                    uim_limit=''
                    uim_premium=0
           
           
        
       
       
        trailer_interchange_units=data["trailer_interchange_units"]
        if towing_yes!='':
           towing=data["towing"]
           
        else:
            towing='0'
        towing_limit=towing
        
        cargo_deductible=data["cargo_deductible"]
        refeer_coverage_required=data["refeer_coverage_required"]
        if refeer_coverage_required=='Yes':
          refeer_coverage=data["refeer_coverage"] 
        else:
            refeer_coverage='0'
     
        zipcode=data["zcode"] # zipcode
        state_code=data["state"] # garaging state
        radius=data["radius"] # radius
        saferfactor=(data["safer_factor"]) # safer
        yxpliability=data["years_of_experience"] #liability factor years of experience 
    
        uwcreditdebitfactor_liability=data["uw_credit_debit_factor_liability"] # uw credit debit liability
        uwcreditdebitfactor_pd=data["uw_credit_debit_factor_pd"] # uw credit debit pd
        uwcreditdebitfactor_cargo=data["uw_credit_debit_factor_cargo"] # uw credit debit cargo
        loss_experience_factor_liability=data["uw_loss_experince_factor_liability"]
        loss_experience_factor_pd=data["uw_loss_experince_factor_pd"]
        loss_experience_factor_cargo=data["uw_loss_experince_factor_cargo"]
        #driver_factor=data["driver_factor"]
        driver_factor=1
        usetype=data["usetype"] # type of use
        secondary_class=data["secondary_class"] #secondary class
        trailer_type=data["trailer_type"] #trailer type
        commodity_al_factor=data["commodities_al_factor"]
        commodity_pd_factor=data["commodity_pd_factor"]
        commodity_cargo_factor=data["commodity_cargo_factor"]
        #**************vehicles data**************** 
        vehicles=data["vehicles"]
        vvhs=vehicles
        #***************************************
        #******* Drivers data **********#
        drivers=data["drivers"]
       
        driver_factor_max=0
        drv_factor=1
        drivers_factors=[]
        try:
            
            for drv in drivers:
                
                age=calculateAge((drv["dob"]))
                #print(age," Driver age")
                drv_factors=calculate_driver_factor((drv['licenseclasstype']),(drv['experience']),(drv['licensestate']),age,(drv['violations']))
                #print("Driver factor ......",drv_factors['factor'])
                if driver_factor_max==0:
                    driver_factor_max=drv_factors['factor']
                elif driver_factor_max<drv_factors['factor']:
                    driver_factor_max=drv_factors['factor']
                
                dtparts=(drv['dob']).split('/')
                newdt=dtparts[2]+'-'+dtparts[0]+'-'+dtparts[1]
                
                dv=Driver((drv['name']),
                          newdt,
                          (drv['licenseno']),
                          (drv['experience']),
                          (drv['licensestate']),
                          (drv['licenseclasstype']),
                          (drv['licensemedicalexp']),
                          (drv['licenseexpdate']),
                          (drv_factors['points']),
                          drv_factors['factor'])
               
                drivers_factors.append(dv)
            if driver_factor_max==0:
                driver_factor_max=1
           
            
            for drvf in drivers_factors:
                
                driver_id=add_driver(dv)
                
        except Exception as e:
            print(e," age ")
        print("driver factor after calculation",driver_factor_max )
        
        if(driver_factor_max==0):
            driver_factor='1'
        else:
            driver_factor=str(driver_factor_max)
        #**************************************
        #********************Broker fees ***************#
        #driver_factor=1
        
        
        broker_fees_liability=0
        broker_fees_pd=0
        broker_fees_cargo=0
     #********* Get common factors ***********######
        um_premium=0
        uim_premium=0
        territory_code=get_territory_code_by_zipcode(zipcode)
        #print(territory_code,"******* tcode")
       
        lst_base_rate_territory_factor=get_base_rate_and_territory_factor( territory_code,state_code)
        base_rate=lst_base_rate_territory_factor.get("base_rate")
        if base_rate==0:
            lq=[]
            cf=[]
            pf=[]
            vhs=[]
            gross_premium=[]
            res={"liability":lq,"cargo":cf,"pd": pf,"vehicles":vhs,"totals":gross_premium,"base_rate":0}
        #create_premium_document(lq,pf,cf,vhs,gross_premium)
            return   Response(res, status=status.HTTP_200_OK) 
        #print(base_rate,"**********")
        territory_factor=lst_base_rate_territory_factor.get("territory_factor")
        ilf_factor=get_ilf_factor()
        lcm_factor=get_lcm_factor()
        pollution_factor=get_pollution_factor()
        state_factor=get_state_factor()
        rate_control_factor=get_rate_control_factor()
        primary_factor=get_primary_factor()
        radius_factor=get_radius_factor(radius)
        use_type_factor=get_type_of_use_factor(usetype)
        trailer_type_factor=get_trailer_type_factor(trailer_type)
        if liability !='No':
            liability_limit_factor=get_liability_limit_factor(liability)
        else:
             liability_limit_factor=1
        safer_factor=get_safer_factor(saferfactor)
        
        liability_years_of_experience_factor=get_years_of_experience_factor(yxpliability)
        
        pd_years_of_experience_factor=get_years_of_experience_factor(yxpliability)
        cargo_years_of_experience_factor=get_years_of_experience_factor(yxpliability)
        secondary_class_factor=get_secondary_class_factor(secondary_class)
     
        type_of_use_factor=get_type_of_use_factor(usetype)
     
        base_ratefactor=1
        cargo_state_factor=1
        cargo_radius_factor=1
        cargo_limit_factor=1
        cargo_deductible_factor=1
     
        _cargo_refeer_deductible_factor=1
        
    #****************** Premium Totals **********************
        _liability_premium_total=0
        _um_premium_total=0
        _uim_premium_total=0
        _pip_premium_total=0
        _med_premium_total=0
        _pd_premium_total=0
        _ti_premium_total=0
        _tow_premium_total=0
        _cargo_premium_total=0
        
    
     
     
     
        if liability!='No':
            liability_limit_factor=get_liability_limit_factor(liability)
            
        if cargo_limit!='':
            base_ratefactor=get_cargo_base_rate()
            cargo_state_factor=get_cargo_state_factor(state_code)
            cargo_radius_factor=get_cargo_radius_factor(radius)
            cargo_limit_factor=get_cargo_limit_factor(cargo_limit)
            cargo_deductible_factor=get_cargo_deductible_factor(cargo_deductible)
            if refeer_coverage_required!='':
                _cargo_refeer_deductible_factor=get_cargo_refeer_deductible_factor(refeer_coverage)
                
        if(submission_id==-1) :   
            submission=Submission(insured_name,_effective_date,user_id,dot_number,mc_number,permit_number,insured_garazing_address,insured_garaging_city,insured_garaging_state,insured_garazing_zip,insured_mailing_address,insured_mailing_city,insured_mailing_state,insured_mailing_zip,'','','','')
            submission_id=add_submission(submission)
        if(submission_id==-1):
            res={"response":"Submission Failed"}
            return   Response(res, status=status.HTTP_200_OK)
        try:
            ins_info=Insured(-1,insured_name,insured_dba,insured_entity,
                         insured_mailing_address,
                         insured_mailing_city,
                         insured_mailing_state,
                         insured_mailing_zip,insured_garazing_address,
                         insured_garaging_city,insured_garaging_state,
                         insured_garazing_zip,
                         insured_phone,
                         insured_email,history,
                         name_on_policy,entity_type,insured_owner_operator,
                         years_of_experience,does_insured_have_dot_number,
                         dot_number,does_insured_need_state_filings,does_insured_need_state_filings,
                         mc_number,permit_number,insured_rating_on_safer_fmcsa_website,submission_id)
            _insured_id=add_insured_info(ins_info)
            _quotedate=datetime.datetime.now().strftime("%Y-%m-%d")
        except Exception as error:
            print(error,'quotdate')
        hired_auto_premium=0
        if hired_auto_liability!='':
            if hired_auto_type=='Primary':
                hired_auto_premium=0.02*int(cost_basis)
            else:
                hired_auto_premium=0.08*int(cost_basis) 
        if non_hired_auto_limit!='':
            if non_hired_auto_on_contratual_basis!='' and number_of_non_owned_units!='':
                #print(number_of_non_owned_units,type(number_of_non_owned_units),"Non owned units")
                non_hired_auto_premium=str(get_non_owned_auto_premium(number_of_non_owned_units))
                print(non_hired_auto_premium," Non owned units...")
               
        try:
            quote=InsQuote(submission_id,
                    _quotedate,
                    'true' if hired_auto_liability!='' else 'false',
                    cost_basis if hired_auto_liability!='' else '0',
                    str(hired_auto_premium),
                    'true' if non_hired_auto_limit!='' else 'false',
                 non_hired_auto_premium,
                 '0',
                 '0',
                 '0',
                 '0',
                 '0',
                 '0',
                 '0',
                 '0',
                 '0',
                 '0',
                 '0',
                
                  _effective_date)
       
            _quoteid=add_quote(quote)
            
            
        except Exception as exp1:
           
            #print(exp1)  
            res={"response":"Adding quote Failed"}
            return   Response(res, status=status.HTTP_200_OK)
        
     
        if _quoteid == -1:
            res={"response":"Adding quote Failed"}
            return   Response(res, status=status.HTTP_200_OK)
                 
                 
        vehicle_type_factor=1
        vehicle_make_factor=1
        pd_base_rate_factor=1
        pd_state_factor=1
        pd_deductible_factor=1
        pd_um_amount=100
        _base_ratefactor=1
        _cargo_state_factor=1
        _cargo_radius_factor=1
        _cargo_limit_factor=1
        _cargo_deductible_factor=1
        _pd_base_rate_factor=1
        _pd_vehicle_make_factor=1
        _pd_state_factor=1
        _pd_deductible_factor=1
        #### Gross Premiums #########
        _gross_liability_premium=0
        _gross_pd_premium=0
        _gross_cargo_premium=0
        _gross_pip_premium=0
        ############################
        vehicle_trailer_interchange_premium=0
     
        power_units=0
        for v in vehicles:
           
            if v["model"].upper()=='TRACTOR' or v["model"].upper()=='TRUCK':
                power_units=power_units+1
            vehicle_type_factor=get_vehicle_type_factor(v["model"])
            vehicle_model_factor=get_vehicle_weight_factor(v["weight"])
            
            vehicle_make_factor=get_pd_vehicle_make_factor(v["make"])
            pd_base_rate_factor=get_pd_base_rate_factor(v["stated_value"])
            pd_state_factor=get_pd_state_factor(state_code)
            pd_deductible_factor=get_pd_deductible_factor(v["deductible"])
            if um_limit!='' and v['um']==True and ( v["model"].upper() !='TRAILER' and v["model"].upper() !='NON-OWNED-TRAILER'):
                
                    pd_um_amount=um_unit_rate
                    _um_premium_total=_um_premium_total+pd_um_amount
               
            else:
                pd_um_amount=0
            
            if cargo_limit !='' and ( v["model"] !='TRAILER' or v["model"] !='NON-OWNED-TRAILER'):
                _base_ratefactor=base_ratefactor
                _cargo_state_factor=cargo_state_factor
                _cargo_radius_factor=cargo_radius_factor
                _cargo_limit_factor=cargo_limit_factor
                _cargo_deductible_factor=cargo_deductible_factor
                
           
            else:
                _base_ratefactor=1
                _cargo_state_factor=1
                _cargo_radius_factor=1
                _cargo_limit_factor=1
                _cargo_deductible_factor=1
            liability_premium=0
          
            
            if liability !='No':
                try:
                    liability_premium=calculate_liability_premium(base_rate,
                                                                  territory_factor,
                                                                  lcm_factor,
                                                          ilf_factor,
                                                          primary_factor,
                                                          pollution_factor,
                                                          state_factor,
                                                          rate_control_factor,
                                                          vehicle_model_factor,
                                                          radius_factor,
                                                          commodity_al_factor,
                                                          float(driver_factor),
                                                          float(loss_experience_factor_liability),
                                                          safer_factor,
                                                          liability_years_of_experience_factor,
                                                          float(uwcreditdebitfactor_liability),
                                                          liability_limit_factor,
                                                          type_of_use_factor,
                                                          secondary_class_factor
                                                          ,trailer_type_factor
                                                         
                                                          )
                   
                    
                    
                    #liability_premium=liability_premium+um_premium+uim_premium+hired_auto_premium+int(non_hired_auto_premium)
                    _gross_liability_premium=_gross_liability_premium+liability_premium
                    _liability_premium_total=_liability_premium_total+liability_premium
                    
                    _uim_premium_total=_uim_premium_total+uim_premium
                    
                    
                except Exception as e:
                   # print(e," problem with liability")
                   pass
                    
            
            cargo_premium=0
           
            if cargo_limit !='' and  (v["model"].upper()=='TRACTOR' or v["model"].upper()=='TRUCK'):
                
                try:
                    cargo_premium=calculate_cargo_premium(_base_ratefactor,_cargo_state_factor,float(driver_factor),float(loss_experience_factor_cargo),
                                                  float(uwcreditdebitfactor_cargo),commodity_cargo_factor,
                                                  cargo_years_of_experience_factor,rate_control_factor,
                                                  safer_factor, _cargo_radius_factor,_cargo_limit_factor,_cargo_deductible_factor,
                                                  _cargo_refeer_deductible_factor) 
                    _gross_cargo_premium=_gross_cargo_premium+ cargo_premium
                    _cargo_premium_total=_cargo_premium_total+cargo_premium
                except Exception as e:
                    print(e," problem with cargo")
            else:
                  cargo_premium=0     
            pd_premium=0
            vehicle_towing_premium=0
           
            if pd=='Yes':
                
                _pd_base_rate_factor=get_pd_base_rate_factor(int(v['stated_value']))
                
                _pd_vehicle_make_factor=get_pd_vehicle_make_factor(v['make'])
                _pd_state_factor=get_pd_state_factor(state_code)
                _pd_deductible_factor=get_pd_deductible_factor(v['deductible'])
                
                if v['tow']==True:
                    vehicle_towing_premium=get_towing_premium(towing)
                else:
                    vehicle_towing_premium=0
                
                if v['tow']==True:
                    _tow_premium_total=_tow_premium_total+vehicle_towing_premium
                
                try:
                    
                   
                    pd_premium=calculate_pd_premium(float(v['stated_value']),pd_base_rate_factor,_pd_vehicle_make_factor,_pd_state_factor,
                                            float(driver_factor),float(loss_experience_factor_pd),float(uwcreditdebitfactor_pd),
                                            _pd_deductible_factor,commodity_pd_factor,
                                            pd_years_of_experience_factor,rate_control_factor,safer_factor)
                    
                    _pd_premium_total=_pd_premium_total+pd_premium
                    
                    
                   
                    _gross_pd_premium=_gross_pd_premium+pd_premium
                    
                    if trailer_interchange!='':
                        if v['model'].upper()=='TRACTOR' or v['model'].upper()=='TRAILER':
                            vehicle_trailer_interchange_premium=calculate_trailer_interchange_premium(
                            float(v['stated_value']),pd_base_rate_factor,_pd_vehicle_make_factor,_pd_state_factor,
                                            float(driver_factor),float(loss_experience_factor_pd),float(uwcreditdebitfactor_pd),
                                            _pd_deductible_factor,commodity_pd_factor,
                                            pd_years_of_experience_factor,rate_control_factor,safer_factor,trailer_type_factor,containers_selected
                            )  
                        else :   
                            vehicle_trailer_interchange_premium=0
                              
                #Trailer interchange Premium calculation################
                    _ti_premium_total=_ti_premium_total+vehicle_trailer_interchange_premium    
                    print( _ti_premium_total, "Trailer interchange premium")
                
                except Exception as e:
                    print(e," problem with pd")
           
            um_premium=0
            uim_premium=0
            veh_medical_premium=0
            
            if medical_limit!='':
                veh_medical_premium=get_medical_premium(state_code,medical_limit)
            else:
                veh_medical_premium=0
            _med_premium_total=_med_premium_total+veh_medical_premium
            
            vehicle_pip_limit=0
            
            
            vehicle_pip_premium=pip_liability_per_unit
            _pip_premium_total=_pip_premium_total+vehicle_pip_premium
           
            
            vehicle_cargo_reefer_factor=get_cargo_refeer_deductible_factor(refeer_coverage)
            
            um_premium=0
            if (v["model"].upper()=='TRUCK' or v["model"].upper()=='TRACTOR') and um_limit!='' :
                    
               
                    print(v['um'],"**************************")
                    if v['um']==True:
                        _um_premium_total=_um_premium_total+um_premium
                        um_premium=um_unit_rate
                    else:
                        um_premium=0
               
            uim_premium=0
           
            #vehicle_model_factor=get_vehicle_model_factor(v["weight"])
            veh=Vehicle(v["make"], #1
                        v["model"], #2
                        v["year"], # 3
                        vehicle_type_factor, #4
                        vehicle_make_factor, #5
                        str(vehicle_model_factor), #6 vehicle
                        pd_deductible_factor,#7
                        v['stated_value'],#8
                        v['deductible'],#9
                        'true' if um_limit!='' else 'false', #10
                        str(um_premium), #11
                        '0' if um_limit=='' else um_limit, #12
                        'true' if uim_limit !='' else 'false',#13
                        
                        uim_premium, #14
                        'true' if medical_limit !='' else 'false', #15
                        medical_limit if medical_limit!='' else '0', #16
                        str(veh_medical_premium), #17
                        str(pd_premium), #18
                        'true' if liability !='No' else 'false', #19
                        '0' if liability=='No' else liability, #20
                        str(liability_premium), #21
                        'true' if pip_limit!='' else 'false', #22
                        vehicle_pip_limit,#23
                        vehicle_pip_premium,#24
                        'true' if trailer_interchange!='' else 'false', #25
                        '0' if trailer_interchange_units=='' else trailer_interchange_units , #26
                        vehicle_trailer_interchange_premium, #27
                        'true' if towing !='' else 'false', #28
                        towing if v['tow'] ==True else  '0', #29
                        vehicle_towing_premium, #30
                        'true' if cargo_limit=='' else 'false', #31
                        '0' if cargo_limit=='' else cargo_limit, #32
                        '0' if cargo_limit=='' else cargo_deductible, #33
                        str(cargo_deductible_factor),#34
                        str(cargo_premium),#35
                        'true' if refeer_coverage_required !='' else 'false', #36
                        refeer_coverage, #37
                        str(vehicle_cargo_reefer_factor),#38
                        str(_cargo_refeer_deductible_factor),#39
                        str(_quoteid),#40
                        _quotedate,v['weight'],v['vin'],v['o_l_rent']) #41
            
           
            if liability !='No':
                lxref=LiabilityXref(str(_quoteid),str(base_rate),str(territory_factor),
                                             str(lcm_factor),str(ilf_factor),str(pollution_factor),
                                             str(state_factor),str(rate_control_factor),
                                             str(vehicle_model_factor),str(radius_factor),str(commodity_al_factor),
                                             str(driver_factor),str(safer_factor),
                                             str(liability_years_of_experience_factor),
                                             str(liability_limit_factor),str(secondary_class_factor),
                                             str(trailer_type_factor),str(primary_factor),
                                             str(uwcreditdebitfactor_liability),
                                             str(loss_experience_factor_liability),
                                             str(type_of_use_factor),)
            if  pd=='Yes':
                pdxref=PDXref(str(_quoteid),
                              str(v['stated_value']),str(pd_base_rate_factor),
                              str(vehicle_make_factor),str(vehicle_model_factor),str(pd_state_factor),
                              str(rate_control_factor),
                              str(commodity_pd_factor),str(driver_factor),
                              str(safer_factor),str(pd_years_of_experience_factor),
                              str(pd_deductible_factor),uwcreditdebitfactor_pd,
                              loss_experience_factor_pd
                              )
            if  cargo_limit !='':
                cargoxref=CargoXref(str(_quoteid),
                                    str(_base_ratefactor),
                                     str(_cargo_state_factor),
                                     str(driver_factor),
                                     str(rate_control_factor),
                                     str(commodity_cargo_factor),
                                     str(safer_factor),
                                     str(cargo_years_of_experience_factor),
                                     str(_cargo_deductible_factor),
                                     str(vehicle_cargo_reefer_factor),
                                     uwcreditdebitfactor_cargo,
                                     loss_experience_factor_cargo,
                                     str( _cargo_radius_factor),
                                     str(_cargo_limit_factor)
                                     
                                     )
                                             
            
            try:
                add_vehicledetails(veh)
                if liability !='No':
                    add_liabilityxref(lxref)
                if  pd=='Yes':
                    #print("Doing Pd")
                    add_pdxref(pdxref)
                if cargo_limit!='':
                    add_cargoxref(cargoxref)
            except Exception as e:
                print(e," error at vehicle adding")  
                continue
        _boker_liability_fee=get_liability_broker_fee(str(power_units)) 
        print(_liability_premium_total,"Liability Total")
        lp_insured_premium_total=0
        if lp_endorsements>0:
            lp_insured_premium_total=lp_endorsements*100
        _broker_pd_fee=get_pd_broker_fee(str(int(_pd_premium_total)))+lp_insured_premium_total  
        print(_cargo_premium_total," cargo premium total")
        _broker_cargo_fee=get_cargo_broker_fee(str(int(_cargo_premium_total)))
        _broker_total_fee=_boker_liability_fee+_broker_pd_fee+_broker_cargo_fee
        
        #update_quote(str(_quoteid),str( _broker_total_fee),str( _boker_liability_fee),str(_broker_pd_fee),
         #            str(_broker_cargo_fee),'true' if trailer_interchange=='Yes' else 'false',trailer_interchange_units,trailer_interchange_limit,str(_ti_premium_total))
        cf=[]
        cargo_factors=''
        print(cargo_limit,' Cargo limit checking')
        if  cargo_limit !='':
            cargo_factors=get_cargo_xref_factors(str(_quoteid))
            for i in cargo_factors:
                cf.append(i[0])
                break
        pd_factors=''
        pf=[]
        if  pd=='Yes':
            pd_factors=get_pd_xref_factors(str(_quoteid))
            for i in pd_factors:
                pf.append(i[0])
                break
        liability_factors=''
        lq=[]
        if liability !='No':
            liability_factors=get_liability_xref_factors(str(_quoteid))
            lq=[]
            for i in liability_factors:
                lq.append(i[0])
                
                break
            
        vehicles=get_vehicles_premium(str(_quoteid))
        vhs=[]
        
        for i in vehicles:
            vhs.append(i[0])
        gross_premium={"liability":
            _liability_premium_total,
            "um":_um_premium_total,
            "uim":_uim_premium_total,
            "pip":_pip_premium_total,
            "med":_med_premium_total,
            "pd":_pd_premium_total,
            #"ti":_ti_premium_total,
            "tow":_tow_premium_total,
            "cargo":_cargo_premium_total
            
            }
        
        sum_of_liability=_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)
       
        addl_insured_premium_total=0
        if ai_endorsements>0:
            addl_insured_premium_total=100*ai_endorsements
        
        
        pw_endorsements_premium_total=0
        ws_endorsements_premium_total=0
        if pw_endorsements>0:
             pw_endorsements_premium_total=pw_endorsements*250
        if ws_endorsements>0:
            ws_endorsements_premium_total=ws_endorsements*250
        sum_of_liability=sum_of_liability+addl_insured_premium_total+pw_endorsements_premium_total+ws_endorsements_premium_total    
        liability_surplus_lines_tax=0
        liability_surplus_lines_tax=round((_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)+_boker_liability_fee+addl_insured_premium_total+pw_endorsements_premium_total+ws_endorsements_premium_total)*0.03,2)
        pd_surplus_lines_tax=round((_pd_premium_total+_ti_premium_total+lp_insured_premium_total+_broker_pd_fee)*0.03,2)
        cargo_surplus_lines_tax=0
        cargo_surplus_lines_tax=round((_cargo_premium_total+_broker_cargo_fee)*0.03,2)
        liability_stamping_fee=round((_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)+_boker_liability_fee+addl_insured_premium_total)*0.0025,2)
        pd_stamping_fee=(_pd_premium_total+_ti_premium_total+lp_insured_premium_total+_broker_pd_fee)*0.0025
        cargo_stamping_fee=(_cargo_premium_total+_broker_cargo_fee)*0.0025
        liability_lob_cost=(_liability_premium_total+hired_auto_premium+float(non_hired_auto_premium)+_boker_liability_fee)+liability_surplus_lines_tax+liability_stamping_fee+addl_insured_premium_total+pw_endorsements_premium_total+ws_endorsements_premium_total
        pd_lob_cost=(_pd_premium_total+lp_insured_premium_total+_ti_premium_total+_broker_pd_fee)+pd_surplus_lines_tax+pd_stamping_fee
        cargo_lob_cost=(_cargo_premium_total+_broker_cargo_fee)+cargo_surplus_lines_tax+cargo_stamping_fee
        try:
           
            if trailer_interchange_units=='':
                    trailer_interchange_units='0'
            if trailer_interchange_limit=='':
                trailer_interchange_limit='0'
            if cost_basis=='':
                cost_basis='0'
            update_quote_all(str(_quoteid),
                             str( round(_broker_total_fee,2)),
                             str(round( _boker_liability_fee,2)),
                             str(round(_broker_pd_fee,2)),
                     str(round(_broker_cargo_fee,2)),
                     'true' if trailer_interchange=='Yes' else 'false',trailer_interchange_units ,
                     str(trailer_interchange_limit),
                     str(_ti_premium_total),
                     'False'  if hired_auto_liability=='' else 'True',
                     '0' if cost_basis=='' else cost_basis,
                     str(hired_auto_premium),
                     str(non_hired_auto_premium),
                     str(liability_surplus_lines_tax+pd_surplus_lines_tax+cargo_surplus_lines_tax),
                     str(liability_stamping_fee+pd_stamping_fee+cargo_stamping_fee),
                     str(liability_lob_cost+pd_lob_cost+cargo_lob_cost),
                     str(round(liability_lob_cost,2)),
                     str(round(pd_lob_cost,2)),
                     str(round(cargo_lob_cost,2)),
                     str(addl_insured_premium_total),'True',str(lp_insured_premium_total),
                     'True' if pw_endorsements>0 else 'False',
                     str(pw_endorsements_premium_total),str(ws_endorsements_premium_total),
                     str(ltl_endorsement_cost),
                     str(eggs_cost),
                     str(riggers_cost),
                     'True',
                     'True',
                     'True','0',
                     'True')
            print(company," company")
            if  _quoteid > -1:
                if liability!='No':
                    
                    qinfo=QuoteInfo('','Y',submission_id,-1,_liability_app_id,10069,-1,-1,-1,-1)
                    q_info_id=add_quote_info(qinfo)
                    add_quote_premium(q_info_id,100,round(liability_lob_cost,2))
                if cargo_limit!='':
                    
                    qinfo=QuoteInfo('','Y',submission_id,-1, _cargo_app_id,10069,-1,-1,-1,-1)
                    q_info_id=add_quote_info(qinfo)
                    add_quote_premium(q_info_id,100,round(cargo_lob_cost,2))
                if pd=='Yes':
                    qinfo=QuoteInfo('','Y',submission_id,-1, _pd_app_id,10069,-1,-1,-1,-1)
                    q_info_id=add_quote_info(qinfo)
                    add_quote_premium(q_info_id,100,round(pd_lob_cost,2))
            add_comp_lob_submission(str(company),str(lob),str(submission_id))
                     
        except Exception as e:
            exception_type, exception_object, exception_traceback = sys.exc_info()
            filename = exception_traceback.tb_frame.f_code.co_filename
            line_number = exception_traceback.tb_lineno
            print(line_number)
            print(e.__str__)
        #print("******** Cargo Endorsement  ", _cargo_endorsements_totals)
        policy_level_premium={
            "Hired_auto_premium":hired_auto_premium,
            "Non_owned_Auto_Premium":non_hired_auto_premium,
            "Trailer_inter_change_premium":_ti_premium_total,
            "broker_fee_liability":_boker_liability_fee,
             "broker_fee_pd":_broker_pd_fee,
             "broker_cargo_fee":_broker_cargo_fee,
             "broker_total_fee": _broker_total_fee,
             "additional_insured":addl_insured_premium_total,
             "loss_payee":lp_insured_premium_total,
             "primary_wording":pw_endorsements_premium_total,
             "waiver_of_subrogation":ws_endorsements_premium_total,
             "cargo_endorsements": _cargo_endorsements_totals,
             "sum_of_liability": sum_of_liability,
             "sum_of_pd":_pd_premium_total+_ti_premium_total,
             "sum_of_cargo":_cargo_premium_total,
             "liability_surplus_lines_tax":liability_surplus_lines_tax,
             "pd_surplus_lines_tax":pd_surplus_lines_tax,
             "cargo_surplus_lines_tax": cargo_surplus_lines_tax,
             "liability_stamping_fee":liability_stamping_fee,
             "pd_stamping_fee":pd_stamping_fee,
             "cargo_stamping_fee":cargo_stamping_fee,
             "liability_lob_cost":liability_lob_cost,
             "pd_lob_cost":pd_lob_cost,
             "cargo_lob_cost":cargo_lob_cost,
             "package_cost":(liability_lob_cost+pd_lob_cost+cargo_lob_cost)
            
        }  
       
        
       
       
        file_name=str(uuid.uuid1())+".pdf"
       
        path_to_file = settings.MEDIA_ROOT + "pdf/"
        path_to_templates=settings.MEDIA_ROOT + "templates/"
        
        forms_info=get_quote_forms_list()
        print(forms_info)
        
        #combine_pdf(insuredInfo,forms_info,insured_name,state_code,um_limit,uim_limit,pip_limit,pw_endorsements,ws_endorsements,ai_endorsements,lp_endorsements,drivers,vvhs,path_to_file,file_name,path_to_templates)
        
        quote_pdf_bs64=get_pdf_data(file_name)
        
        res={"liability":lq,"cargo":cf,"pd": pf,"vehicles":vhs,"totals":gross_premium,"base_rate":base_rate,"ploicylevelpremium":policy_level_premium,"quotepdf":quote_pdf_bs64,"submission_id":submission_id}
       
        return   Response(res, status=status.HTTP_200_OK)   
              
    except Exception as e:
        exception_type, exception_object, exception_traceback = sys.exc_info()
        filename = exception_traceback.tb_frame.f_code.co_filename
        line_number = exception_traceback.tb_lineno
        print(line_number)
        print(e.__str__)
    res={"response":"Successfully generated premium"}
    return   Response(res, status=status.HTTP_200_OK)

def get_pdf_data(quote_file):
    """_summary_

    Args:
        quote_file (_type_): _description_

    Returns:
        _type_: _description_
    """
    path_to_file = settings.MEDIA_ROOT + "pdf/"+quote_file
    print(path_to_file)
    #print(path_to_file)
    f = open(path_to_file, 'rb')
   
    pdfFile = File(f)
    pdfdata=pdfFile.read()
    pdfbs64data=base64.b64encode(pdfdata)
    return pdfbs64data

@api_view(['POST'])
def DownloadQuotePDF(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    path_to_file = settings.MEDIA_ROOT + "pdf/sample.pdf"
    
    f = open(path_to_file, 'rb')
   
    pdfFile = File(f)
    pdfdata=pdfFile.read()
    pdfbs64data=base64.b64encode(pdfdata)
   
    
    res={'fileContent':pdfbs64data,'ext':'pdf',"message":'SUCCESS'}
   
    return   Response(res, status=status.HTTP_200_OK)                              

@api_view(['POST'])
def get_quotes_by_submission_id(request):  
    data = json.loads(request.body.decode("utf-8"))
    _submission_id=-1
    _quotes=[]
    _submission={}
    try:
       
        _submission_id=(data["submission_id"])
        _quotes=get_quotes_by_submission_id(str(_submission_id))
        _submission=get_submission_details_by_submission_id(str(_submission_id))
        res={"response":"Quote retrieved ","quotes": _quotes,"submission":_submission}             
    except Exception as e:
        exception_type, exception_object, exception_traceback = sys.exc_info()
        filename = exception_traceback.tb_frame.f_code.co_filename
        line_number = exception_traceback.tb_lineno
        print(line_number)
        print(e.__str__)
        res={"response":"Could not retrieve quotes","quotes": _quotes,"submission":_submission}                
    return   Response(res, status=status.HTTP_200_OK)      
# To get quote forms
@api_view(['GET'])
def get_quote_forms(request):
    """This is the function to get the quote forms data.
    Parameter : request
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        _forms = get_quote_forms_list()
        res = {"forms": _forms}
        return Response(res, status=status.HTTP_200_OK)
    except(Exception) as error:
        print(error)
        return Response(res, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    



@api_view(['GET'])
def get_all_forms(request):
    """This is the function to get all the form-master data.
    Parameter : request
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        _forms = get_all_forms_list_db()
        res = {"forms": _forms}
        return Response(res, status=status.HTTP_200_OK)
    except(Exception) as error:
        print(error)
        return Response(res, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    


# To insert quote forms
@api_view(['POST'])
def create_quote_form_details(request):
    """This function is used to save new form-master data.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        form_data = data["quotes_forms"]
        filesData = data["fileData"]
        file_location=''
        # form_data = request.data
        if request.method == 'POST':
            try:
                # print(request.data)
            
                form_name = form_data['form_name']
                form_edition = form_data['form_edition']
                form_description = form_data['form_description']
                form_category = form_data['form_category']
                form_state = form_data['form_state']
                form_condition = form_data['form_condition']
                form_type = form_data['form_type']
                form_active = form_data['form_active']
                mandatory = form_data['mandatory']
                form_order = form_data['form_order']
                file_location = form_data['file_location']
                company_id = form_data['company_id']
                lob_id = form_data['lob_id']
                #filname=  filesData[0]['name']
                if filesData !=None and filesData !=[]:
                    file_id = uuid.uuid4()
                    file_location="media/templates/"+file_id.hex+"_"+filesData[0]['name']
                    with open(file_location, 'wb') as file_to_save:
                        decoded_file_data = base64.decodebytes(filesData[0]['filecontent'])
                        print(decoded_file_data)
                        file_to_save.write(decoded_file_data)

            
                form_data = ins_forms_master(0,form_name, form_edition, form_description, form_category,
                form_state, form_condition, form_type, form_active, mandatory, form_order,file_location,company_id,lob_id)
                #print(form_data, ' data')
                res = {"status": add_forms_details_db(form_data)}
                if res['status'] != "FAIL":
                    data = {"message": res, "Claimant Updated": True}
                else:
                    data = {"message": "Some thing wento wrong..",
                            "Claimant Updated": False}
                # claimantres =  (form_data)

            except Exception as error:
                print(error)

                data = {"message": "not a post method"}
        return Response(data, status=status.HTTP_200_OK)
    except(Exception) as error:
         print(error)
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)       
   

# To update quote forms
@api_view(['POST', 'OPTIONS'])
def update_quote_form_details(request):
    """This is the function to update all the fields of form-master data.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    data = request.data
    form = data["quotes_forms"]
    filesData = data["fileData"]
    #print(filesData)
    if request.method == 'POST':
        try:
            # print(request.data)
            id = int(form['id'])
            form_name = form['form_name']
            form_edition = form['form_edition']
            form_description = form['form_description']
            form_category = form['form_category']
            form_state = form['form_state']
            form_condition = form['form_condition']
            form_type = form['form_type']
            form_active = form['form_active']
            mandatory = form['mandatory']
            form_order = form['form_order']
            file_location = form['file_location']
            company_id = form['company_id']
            lob_id = form['lob_id']
            if filesData !=None and filesData !=[]:
                 filname=  filesData[0]['name']
                 file_id = uuid.uuid4()
                 file_location="media/templates/"+file_id.hex+"_"+filesData[0]['name']
                 base64_file_bytes = filesData[0]['filecontent'].encode('utf-8')
                 with open(file_location, 'wb') as file_to_save:
                  decoded_file_data = base64.decodebytes(base64_file_bytes)
                  print(decoded_file_data)
                  file_to_save.write(decoded_file_data)
           
        

            form_data = ins_forms_master(id, form_name, form_edition, form_description, form_category,
            form_state, form_condition, form_type, form_active, mandatory, form_order,file_location,company_id,lob_id)
            #print(form_data, ' data')
            res = {"status": update_form_details_db(form_data)}
            if res['status'] != "FAIL":
                data = {"message": res, "Claimant Updated": True}
            else:
                data = {"message": "Some thing wento wrong..",
                        "Claimant Updated": False}
            # claimantres =  (form_data)

        except Exception as error:
            print(error)
            data = {"message": "not a post method"}
        return Response(data, status=status.HTTP_200_OK)



# To make forms Inactive or Active
@api_view(['POST', 'OPTIONS'])
def set_active_status(request):
    """This function is used to make form status inactive.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    data = json.loads(request.body.decode("utf-8"))
    id = data["form_id"]
    if request.method == 'POST':
           try:
                # print(request.data)

               
                #form_data = ins_forms_master(id,form_active)
                res = {"status": set_active_form_status_db(id)}
                if res['status'] != "FAIL":
                    data = {"message": "SUCSESS", "Form Updated": True}
                else:
                    data = {"message": "Some thing wento wrong..",
                            "Form Updated": False}
           except Exception as error:
                print(error)
                data = {"message": "not a post method"}
           return Response(data, status=status.HTTP_200_OK)

## To Get Uploaded file Data
@api_view(['POST', 'OPTIONS'])
def get_formmaster_by_id(request):
    """This function is used to get the formmaster by id.

    Args:
        request HttpRequest: HttpRequest object
        id (integer): formmaster id

    Returns:
        _type_: HttpResponse 
    """
    try:
        form_id = json.loads(request.body.decode("utf-8"))
        #form_id = data["form_id"]
        res = get_all_forms_master_ById_db(form_id)
        with open(res[0][0]['file_location'], "rb") as pdf_file:
            encoded_string = base64.b64encode(pdf_file.read())
        data = {"message": encoded_string}
        return Response(data, status=status.HTTP_200_OK)   
    except Exception as error:
            print(error)
            data = {"message": "not a post method"}
            return Response(data, status=status.HTTP_200_OK)
       
@api_view(['POST', 'OPTIONS'])
def get_agency_info(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    u_id=data['userid']
    print(u_id)
    agency_info=get_agency_details(u_id)
    #print(agency_info)
    data={"agency_info":agency_info}
    return Response(data, status=status.HTTP_200_OK)


@api_view(['POST', 'OPTIONS'])
def update_upload_file(request):
    """This is the function to update uploaded file of form-master.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    data = request.data
    form_id = data['form_id']
    filesData = data["fileData"]
    #print(filesData)
    if request.method == 'POST':
        try:
            # print(request.data)
            id = int(form_id)
            if filesData !=None and filesData !=[]:
                 filname=  filesData[0]['name']
                 file_id = uuid.uuid4()
                 file_location="media/templates/"+file_id.hex+"_"+filesData[0]['name']
                 base64_file_bytes = filesData[0]['filecontent'].encode('utf-8')
                 with open(file_location, 'wb') as file_to_save:
                  decoded_file_data = base64.decodebytes(base64_file_bytes)
                  print(decoded_file_data)
                  file_to_save.write(decoded_file_data)
           

            form_data = ins_forms_master(id,'','','','','','','','','',0,file_location,0,0)
            #print(form_data, ' data')
            res = {"status": update_uploaded_file_db(form_data)}
            if res['status'] != "FAIL":
                data = {"message": res}
            else:
                data = {"message": "Some thing wento wrong.."}

        except Exception as error:
            print(error)

            data = {"message": "not a post method"}
        return Response(data, status=status.HTTP_200_OK)  
    
@api_view(['POST', 'OPTIONS'])
def get_quote_details(request): 
    data = json.loads(request.body.decode("utf-8"))
    quote_id=data['quote_id'] 
    quote_info=get_quote_info_by_quoteid(quote_id)
    quote_premium_info=get_quote_premium_info_by_quoteid(quote_id)
    submission_id=quote_info['submission_id']
    insured_info=get_insured_info_by_quoteid(submission_id)
    app_type_id=quote_info['application_type_id']
    app_type_info=get_app_type_info_by_app_type_id(app_type_id)
    quote_details={"quote_info":quote_info,"quote_premium_info":quote_premium_info,
                   "insured_info":insured_info,"app_type_info":app_type_info}
    filehandler = open("g:/quote_info.json", 'wt')
    data = str(quote_details)
    filehandler.write(data)
    return Response(quote_details, status=status.HTTP_200_OK)

@api_view(['POST', 'OPTIONS'])
def get_policy_details_of_quote(request):
    """sumary_line
    
    Keyword arguments:
    argument -- description
    Return: return_description
    """
     
    data = json.loads(request.body.decode("utf-8"))
    quote_id=data['quote_id'] 
   
    
    quote_info=get_quote_info_by_quoteid(quote_id)
    #print(quote_info)
   # filehandler4 = open("g:/quote_info.json", 'wt')
   # data = str(quote_info)
   # filehandler4.write(data)
   
    #print(quote_info)
    print("****** end quote info ******")
    submission_id=quote_info['user_id']
    user_id=quote_info['user_id']
    
    agency_info=get_agency_info_by_userid(user_id) # agency information
    #filehandler5 = open("g:/agency_info.json", 'wt')
    
    #print(agency_info)
    print("******** end of agency info *******")
    #data = str(quote_info)
    #filehandler5.write(data)
    app_type_id= quote_info['application_type_id']
    
    #quote_premium_info=get_quote_premium_info_by_quoteid(quote_id)
    
    submission_id=quote_info['submission_id']
    #quote_premium_info=get_quote_premium_details(submission_id,app_type_id)
    
    #print(quote_premium_info)
    print("********* end premium info ")
    #filehandler1 = open("g:/quote_premium_info.json", 'wt')
    #data = str(quote_info)
    #filehandler1.write(data)
    insured_info=get_insured_info_by_quoteid(submission_id)
    #filehandler2 = open("g:/insured_info.json", 'wt')
    #data = str(quote_info)
    #filehandler2.write(data)
    #print(insured_info)
    print("******** end of insured info")
    app_type_id=quote_info['application_type_id']
    #app_type_info=get_app_type_info_by_app_type_id(app_type_id)
    #print(app_type_info)
    print("******** app type info *********")
    #filehandler3 = open("g:/app_type_info.json", 'wt')
    #data = str(quote_info)
    #filehandler3.write(data)
    quote_premium_details=get_premium_details_with_class_id_by_quote(quote_id)
    
    #print(quote_premium_details)
    print("******** end of quote premium details *****")
    #quote_details={"quote_info":quote_info,"quote_premium_info":quote_premium_info,
    #               "insured_info":insured_info,"app_type_info":app_type_info}
    
    quote_details={"quote_info":quote_info,"broker_info":agency_info,"insured_info":insured_info,
                 
                   "quote_premium_details":quote_premium_details}
    app_type_data=app_type_related_data_of_quote(app_type_id)
    
    filehandler = open("g:/quote_info.json", 'wt')
    data = str(quote_details)
    filehandler.write(data)
    broker_fee=0
     
    app_quote_details={'quote_id':quote_id,'policy_number':quote_info['policy_number'],
                       'insured_id':insured_info['insured_id'],
                      'submission_id':submission_id,
                       'insured_name':insured_info['insured_name'],
                      'insured_name':insured_info['insured_name'],
                      'insured_mailing_address':insured_info['insured_mailing_address'],
                      'insured_mailing_city':insured_info['insured_mailing_city'],
                      'insured_mailing_state': insured_info['insured_mailing_state'],
                      'insured_mailing_zip':insured_info['insured_mailing_zip'],
                      'insured_garaging_addres':insured_info['insured_garaging_address'],
                      'insured_garaging_city':insured_info['insured_garaging_city'],
                      'insured_garaging_state':insured_info['insured_garaging_state'],
                      'insured_garaging_zip':insured_info['insured_garaging_zip'],
                      'has_filings':insured_info['does_insured_require_icc_filings'],
                      'effective_date': '2022-07-28',
                        'expiration_date': '2023-07-28',
                       'application_type_id':quote_info['application_type_id'],
                        'lob_id':quote_info['lob_id'],
                        #'class_of_business_id':quote_premium_details['class_of_business_id'],
                        #'class_of_business_id_premium':quote_premium_details['premium'],
                        'agency_id':agency_info['agency_id'],
                        'transaction_type_id': 1,
                        'cost_of_policy': '3252.38',
                        'user_id':user_id,
                        'bill_type_id':2,
                        'transaction_effectivedate':'2022-07-28',
                        'risk_company_id':210,
                        'market_company_id':450,
                        'tax_company_id':450,
                        'received_comm':0.20,
                        'paid_comm':0.10,
                        'override':0,
                        'status_id':9,
                        "quote_premium_details":quote_premium_details
                      }
    
    filehandler1 = open("g:/app_quote_info.json", 'wt')
    data = str(app_quote_details)
    filehandler1.write(data)
    return Response(app_quote_details, status=status.HTTP_200_OK)
    
    
    
    
    
    
           
            
        
        
        
        
        
     
     
     
     
    
