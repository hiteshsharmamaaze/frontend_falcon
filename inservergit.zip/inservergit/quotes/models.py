from this import s
from unicodedata import name
from django.db import models
from adminapp.dboperations import *

# Create your models here.

class Submission:
    def __init__ (self,insured_name , 
                  effective_date,
	user_id , 
	dot_number , 
	mc_number , 
	permit_number , 
	garagingaddress , 
	garagingcity , 
	garagingstate , 
	garagingzip , 
	mailingaddress , 
	mailingcity , 
	mailingstate, 
	mailingzip , 
	submissionstatus , 
	submissionqueue , 
	quotebound , 
	quotecurrentlyendorsed) :
        self.insured_name=insured_name
        self.effective_date=effective_date
        self.user_id=user_id
        self.dot_number=dot_number
        self.mc_number=mc_number
        self.permit_number=permit_number
        self.garagingaddress=garagingaddress
        self.mc_number=mc_number
        self.permit_number=permit_number
        self.garagingaddress=garagingaddress
        self.garagingcity=garagingcity
        self.garagingstate=garagingstate
        self.garagingzip=garagingzip
        self.mailingaddress=mailingaddress
        self.mailingcity=mailingcity
        self.mailingstate=mailingstate
        self.mailingzip=mailingzip
        self.submissionstatus=submissionstatus
        self.submissionqueue=submissionqueue
        self.quotebound=quotebound
        self.quotecurrentlyendorsed=quotecurrentlyendorsed
        
    def convert_to_tuple(self):
        tp=[self.insured_name,self.effective_date,self.user_id,self.dot_number,
            self.mc_number,self.permit_number,self.garagingaddress,self.garagingcity,
            self.garagingstate,self.garagingzip,
            self.mailingaddress,self.mailingcity,self.mailingstate,self.mailingzip,
            self.submissionstatus,self.submissionqueue,self.quotebound,self.quotecurrentlyendorsed,]
        return tp

#submissionid, quotedatetime, hiredauto, hiredauto_cost, hiredauto_premium, nonownedauto, 
# nonownedauto_premium, broker_fee_total, broker_fee_liability, broker_fee_pd, 
# broker_fee_cargo, surpluslinetax, stampingfee, costofpackage, costofliability, 
# costofpd, costofcargo, ai_total_cost, effectivedate, expirationdate)

class InsQuote:
    def __init__(self,
                 submissionid,
                 quotedatetime,
                 hiredauto,
                 hiredauto_cost,
                 hiredauto_premium,
                 nonownedauto,
                 nonownedauto_premium,
                 broker_fee_total,
                 broker_fee_liability,
                 broker_fee_pd,
                 broker_fee_cargo,
                 surpluslinetax,
                 stampingfee,
                 costofpackage,
                 costofliability,
                 costofpd,
                 costofcargo,
                 ai_total_cost,
                 effectivedate):
        self.submissionid=submissionid
        self.quotedatetime=quotedatetime
        self.hiredauto=hiredauto
        self.hiredauto_cost=hiredauto_cost
        self.hiredauto_premium=hiredauto_premium
        self.nonownedauto=nonownedauto
        self.nonownedauto_premium=nonownedauto_premium
        self.broker_fee_total=broker_fee_total
        self.broker_fee_liability=broker_fee_liability
        self.broker_fee_pd=broker_fee_pd
        self.broker_fee_cargo=broker_fee_cargo
        self.surpluslinetax=surpluslinetax
        self.stampingfee=stampingfee
        self.costofpackage=costofpackage
        self.costofliability=costofliability
        self.costofpd=costofpd
        self.costofcargo=costofcargo
        self.ai_total_cost=ai_total_cost
        self.effectivedate=effectivedate,
        
        
    def convert_to_tuple(self):
        return (self.submissionid,
                self.quotedatetime,
                self.hiredauto,
                self.hiredauto_cost,
                self.hiredauto_premium,
                self.nonownedauto,
                self.nonownedauto_premium,
                self.broker_fee_total,
                self.broker_fee_liability,
                self.broker_fee_pd,
                self.broker_fee_cargo,
                self.surpluslinetax,
                self.stampingfee,
                self.costofpackage,
                self.costofliability,
                self.costofpd,
                self.costofcargo,
                self.ai_total_cost,
                self.effectivedate)
        
    
   
        
             
                
             
         
       
# vehiclemake, vehiclemodel, vehicleyear, vehicletypefactor, vehiclemakefactor, 
# vehiclemodelfactor, vehicledeductiblefactor, vehiclestatedamount, vehicledeductible, 
# vehicle_um, vehicle_um_premium, vehicle_um_limit, vehicle_uim, vehicle_uim_premium, 
# vehicle_medical, vehicle_medical_limit, vehicle_medical_premium, vehicle_pd_premium, 
# vehicle_liability, vehicle_liability_limit, vehicle_liability_premium, vehicle_pip, 
# vehicle_pip_limit, vehicle_pip_premium, vehicle_trailer_interchange, 
# vehicle_trailer_interchange_limit, vehicle_trailer_interchange_premium, 
# vehicle_towing, vehicle_towing_limit, vehicle_towing_premium, vehicle_cargo, 
# vehicle_cargo_limit, vehicle_cargo_deductible, vehicle_cargo_deductible_factor, 
# vehicle_cargo_premium, vehicle_cargo_reefer, vehicle_cargo_reefer_limit, 
# vehicle_cargo_reefer_factor, quoteid, vehicle_add_date                
class Vehicle:
    def __init__(self,
                 vehiclemake, 
                 vehiclemodel, 
                 vehicleyear, 
                 vehicletypefactor, 
                 vehiclemakefactor
                 ,vehiclemodelfactor, 
                 vehicledeductiblefactor,
                 vehiclestatedamount,
                 vehicledeductible,
                 vehicle_um, 
                 vehicle_um_premium,
                 vehicle_um_limit,
                 vehicle_uim,
                 vehicle_uim_premium,
                 vehicle_medical,
                 vehicle_medical_limit,
                 vehicle_medical_premium,
                 vehicle_pd_premium, 
                vehicle_liability,
                vehicle_liability_limit,
                vehicle_liability_premium,
                vehicle_pip,
                vehicle_pip_limit,
                vehicle_pip_premium,
                vehicle_trailer_interchange, 
                vehicle_trailer_interchange_limit,
                vehicle_trailer_interchange_premium,
                vehicle_towing,
                vehicle_towing_limit,
                vehicle_towing_premium,
                vehicle_cargo,
                vehicle_cargo_limit,
                vehicle_cargo_deductible,
                vehicle_cargo_deductible_factor, 
                vehicle_cargo_premium,
                vehicle_cargo_reefer,
                vehicle_cargo_reefer_limit,
                vehicle_cargo_reefer_factor,
                vehicle_cargo_refeer_deductible_factor,
                quoteid, 
                vehicle_add_date,
                weight,
                vin,
                o_l_rent
            ):
        
        self.vehiclemake=vehiclemake
        self.vehiclemodel=vehiclemodel
        self.vehicleyear=vehicleyear
        self.vehicletypefactor=vehicletypefactor
        self.vehiclemakefactor=vehiclemakefactor
        self.vehiclemodelfactor=vehiclemodelfactor
        self.vehicledeductiblefactor=vehicledeductiblefactor
        self.vehiclestatedamount=vehiclestatedamount
        self.vehicledeductible =vehicledeductible
        self.vehicle_um=vehicle_um
        self.vehicle_um_premium=vehicle_um_premium
        self.vehicle_um_limit=vehicle_um_limit
        self.vehicle_uim=vehicle_uim
        self.vehicle_uim_premium =vehicle_uim_premium
        self.vehicle_medical=vehicle_medical
        self.vehicle_medical_limit=vehicle_medical_limit
        self.vehicle_medical_premium=vehicle_medical_premium
        self.vehicle_pd_premium=vehicle_pd_premium
        self.vehicle_liability=vehicle_liability
        self.vehicle_liability_limit=vehicle_liability_limit
        self.vehicle_liability_premium=vehicle_liability_premium
        self.vehicle_pip =vehicle_pip
        self.vehicle_pip_limit=vehicle_pip_limit
        self.vehicle_pip_premium=vehicle_pip_premium
        self.vehicle_trailer_interchange=vehicle_trailer_interchange
        self.vehicle_trailer_interchange_limit=vehicle_trailer_interchange_limit
        self.vehicle_trailer_interchange_premium=vehicle_trailer_interchange_premium
        self.vehicle_towing =vehicle_towing
        self.vehicle_towing_limit=vehicle_towing_limit
        self.vehicle_towing_premium=vehicle_towing_premium
        self.vehicle_cargo =vehicle_cargo
        self.vehicle_cargo_limit=vehicle_cargo_limit
        self.vehicle_cargo_deductible=vehicle_cargo_deductible
        self.vehicle_cargo_deductible_factor=vehicle_cargo_deductible_factor
        self.vehicle_cargo_premium=vehicle_cargo_premium
        self.vehicle_cargo_reefer=vehicle_cargo_reefer
        self.vehicle_cargo_reefer_limit =vehicle_cargo_reefer_limit
        self.vehicle_cargo_reefer_factor=vehicle_cargo_reefer_factor
        self.vehicle_cargo_refeer_deductible_factor=vehicle_cargo_refeer_deductible_factor
        self.quoteid=quoteid
        self.vehicle_add_date =vehicle_add_date 
        self.weight=weight
        self.vin=vin
        self.o_l_rent=o_l_rent
    
    def get_liability_xref_obj(self,quoteid):
        xref=None
        #base_rate=
        
        pass
    def get_pd_xref_obj():
        pass
    def get_cargo_xref_obj():
        pass
        
    def convert_to_tuple(self):
        print( self.vehiclestatedamount," stated amt")
        return (self.vehiclemake,
                self.vehiclemodel,
                self.vehicleyear,
                str(self.vehicletypefactor),
                str(self.vehiclemakefactor),
                str(self.vehiclemodelfactor),
                str(self.vehicledeductiblefactor),
                self.vehiclestatedamount,
                self.vehicledeductible,
                self.vehicle_um,
                str(self.vehicle_um_premium),
                str(self.vehicle_um_limit),
                self.vehicle_uim,
                str(self.vehicle_uim_premium),
                str(self.vehicle_medical),
                str(self.vehicle_medical_limit),
                str(self.vehicle_medical_premium),
                str(self.vehicle_pd_premium),
                self.vehicle_liability,
                str(self.vehicle_liability_limit),
                str(self.vehicle_liability_premium),
                self.vehicle_pip,
                str(self.vehicle_pip_limit),
                str(self.vehicle_pip_premium),
                self.vehicle_trailer_interchange,
                str(self.vehicle_trailer_interchange_limit),
                str(self.vehicle_trailer_interchange_premium),
                self.vehicle_towing,
                str(self.vehicle_towing_limit),
                str(self.vehicle_towing_premium),
                self.vehicle_cargo,
                str(self.vehicle_cargo_limit),
                self.vehicle_cargo_deductible,
                self.vehicle_cargo_deductible_factor,
                self.vehicle_cargo_premium,
                self.vehicle_cargo_reefer,
                self.vehicle_cargo_reefer_limit,
                self.vehicle_cargo_reefer_factor,
                self.quoteid,
                self.vehicle_add_date,
                
                )  
class LiabilityXref:
    def __init__(self, quoteid, base_rate, territory_factor, lcm_factor, ilf_factor,
                 pollution_factor, state_factor, rate_control_factor, 
                 vehicle_type_factor, radius_factor, commodity_al_factor,
                 driver_factor, safer_factor, years_of_experience_factor, 
                 liability_factor, secondary_class_factor, trailer_type_factor, 
                 primary_factor, uw_credit_debit_factor, loss_experience_factor,type_of_use_factor):
        self.quoteid=quoteid 
        self.base_rate=base_rate
        self.territory_factor=territory_factor
        self.lcm_factor=lcm_factor
        self.ilf_factor=ilf_factor
        self.pollution_factor=pollution_factor
        self.state_factor=state_factor
        self.rate_control_factor=rate_control_factor
        self.vehicle_type_factor=vehicle_type_factor
        self.radius_factor=radius_factor 
        self.commodity_al_factor=commodity_al_factor
        self.driver_factor=driver_factor
        self.safer_factor=safer_factor
        self.years_of_experience_factor=years_of_experience_factor
        self.liability_factor=liability_factor
        self.secondary_class_factor=secondary_class_factor
        self.trailer_type_factor=trailer_type_factor 
        self.primary_factor=primary_factor
        self.uw_credit_debit_factor=uw_credit_debit_factor
        self.loss_experience_factor=loss_experience_factor
        self.type_of_use_factor=type_of_use_factor
        
    def convert_to_tuple(self):
        return (self.quoteid,
                self.base_rate,
                self.territory_factor,
                self.lcm_factor,
                self.ilf_factor,
                self.pollution_factor,
                self.state_factor,
                self.rate_control_factor,
                self.vehicle_type_factor,
                self.radius_factor,
                self.commodity_al_factor,
                self.driver_factor,
                self.safer_factor,
                self.years_of_experience_factor,
                self.liability_factor,
                self.secondary_class_factor,
                self.trailer_type_factor,
                self.primary_factor,
                self.uw_credit_debit_factor,
                self.loss_experience_factor,
                self.type_of_use_factor,)
        
class PDXref:
    def __init__(self, quoteid, stated_value, base_rate_factor, vehicle_make_factor, 
                 vehicle_model_factor, state_factor, rate_control_factor, 
                 commodity_factor, driver_factor, safer_factor, years_of_experience_factor, 
                 deductible_factor, uw_credit_debit_factor, loss_experience_factor):
        self.quoteid=quoteid 
        self.stated_value=stated_value
        self.base_rate_factor=base_rate_factor
        self.vehicle_make_factor=vehicle_make_factor
        self.vehicle_model_factor=vehicle_model_factor
        self.state_factor=state_factor
        self.rate_control_factor=rate_control_factor
        self.commodity_factor=commodity_factor
        
        self.driver_factor=driver_factor
        self.safer_factor=safer_factor
        self.years_of_experience_factor=years_of_experience_factor
        self.deductible_factor=deductible_factor
        
        self.uw_credit_debit_factor=uw_credit_debit_factor
        self.loss_experience_factor=loss_experience_factor
    def convert_to_tuple(self):
        return (self.quoteid,
                self.stated_value,
                self.base_rate_factor,
                self.vehicle_make_factor,
                self.vehicle_model_factor,
                self.state_factor,
                self.rate_control_factor,
                self.commodity_factor,
                self.driver_factor,
                self.safer_factor,
                self.years_of_experience_factor,
                self.deductible_factor,
                self.uw_credit_debit_factor,
                self.loss_experience_factor,)
        
class CargoXref:
    def __init__(self,  quoteid, base_rate_factor, state_factor, driver_factor,
	            rate_control_factor, 
	            commodity_factor, 
	            safer_factor, years_of_experience_factor, 
	            deductible_factor, refeer_deductible_factor, 
	            uw_credit_debit_factor, loss_experience_factor, radius_factor, limit_factor):
        self.quoteid=quoteid 
        self.base_rate_factor=base_rate_factor
       
        self.state_factor=state_factor
        self.rate_control_factor=rate_control_factor
        self.commodity_factor=commodity_factor
        
        self.driver_factor=driver_factor
        self.safer_factor=safer_factor
        self.years_of_experience_factor=years_of_experience_factor
        self.deductible_factor=deductible_factor
        self.refeer_deductible_factor=refeer_deductible_factor
        
        self.uw_credit_debit_factor=uw_credit_debit_factor
        self.loss_experience_factor=loss_experience_factor
        self.radius_factor=radius_factor
        self.limit_factor=limit_factor
    
    def convert_to_tuple(self):
        return (self.quoteid,self.base_rate_factor,self.state_factor,
               self.rate_control_factor,
                self.commodity_factor, self.driver_factor,self.safer_factor,
                self.years_of_experience_factor,
                self.deductible_factor,self.refeer_deductible_factor,
                self.uw_credit_debit_factor,self.loss_experience_factor,
                self.radius_factor,self.limit_factor,)


class Agency(models.Model):
    #id = models.BigIntegerField(primary_key=True)
    id=models.BigAutoField(primary_key=True)
    agencyname=models.CharField(max_length=100,unique=True)
    address=models.CharField(max_length=100,null=False)
    city=models.CharField(max_length=100,null=False)
    state=models.CharField(max_length=100,null=False)
    zipcode=models.CharField(max_length=100,null=False)
    contact_number_office=models.CharField(max_length=20)
    contact_number_mobile=models.CharField(max_length=20)
    email=models.CharField(max_length=100,unique=True)
    fax=models.CharField(max_length=20,null=True)
    years_in_business=models.IntegerField()

    class Meta:
        managed = True
        db_table = 'agency'
        
    
class AgencyUser(models.Model):
    id=models.BigAutoField(primary_key=True)    
    first_name=models.CharField(max_length=100)
    last_name=models.CharField(max_length=100)
    middle_name=models.CharField(max_length=100)
    email=models.CharField(max_length=100,unique=True)
    contact_number_office=models.CharField(max_length=20)
    contact_number_mobile=models.CharField(max_length=20)
    user_type=models.CharField(max_length=100)
    password=models.TextField(max_length=512)
    agency=models.ForeignKey('Agency', models.DO_NOTHING, blank=True, null=True)
    class Meta:
        managed = True
        db_table = 'agency_user'
    
class CoverageType(models.Model):
    id=models.BigAutoField(primary_key=True)
    name:models.CharField(max_length=100)
    description=models.CharField(max_length=1024)
        
    class Meta:
        managed = True
        db_table = 'coverage_type'

class AgencyCoverage(models.Model):
    id=models.BigAutoField(primary_key=True)
    agency=models.ForeignKey('Agency', models.DO_NOTHING, blank=True, null=True)
    coveragetype=models.ForeignKey('AgencyCoverage', models.DO_NOTHING, blank=True, null=True)
    
    class Meta:
        managed = True
        db_table = 'agency_coverage'

class Quote(models.Model):
    id=models.BigAutoField(primary_key=True)
    quote_number=models.IntegerField(null=False,unique=True)
    state=models.CharField(max_length=10,null=False,default="SAVED")
    msg_to_underwriter=models.TextField(max_length=1024)
    general_liability=models.BooleanField(default=True)
    physical_damage=models.BooleanField(default=False)
    cargo_taken=models.BooleanField(default=False)
    date_of_generation=models.DateTimeField(auto_now=True)
    date_of_modification=models.DateTimeField(auto_now=True)
    
    
    
    class Meta:
        managed = True
        db_table = 'quote'

class Geninfo:
    id = models.BigAutoField(primary_key=True)  # Field name made lowercase.
    insured_name = models.CharField(db_column='Insured_Name', max_length=100)  # Field name made lowercase.
    ca_num = models.CharField(max_length=50, blank=True, null=True)
    contact_name = models.CharField(max_length=100, blank=True, null=True)
    contact_number = models.CharField(max_length=15, blank=True, null=True)
    business_phone = models.CharField(max_length=15, blank=True, null=True)
    mobile_phone=models.CharField(max_length=15, blank=True, null=True)
    effective_date_from = models.DateField(blank=True, null=True)
    effective_date_to = models.DateField(blank=True, null=True)
    entity_type = models.CharField(max_length=100, blank=True, null=True)
    garaging_address = models.CharField(max_length=100, blank=True, null=True)
    garaging_city = models.CharField(max_length=100, blank=True, null=True)
    garaging_state = models.CharField(max_length=50, blank=True, null=True)
    mailing_address = models.CharField(max_length=100, blank=True, null=True)
    mailing_city = models.CharField(max_length=100, blank=True, null=True)
    mailing_state = models.CharField(max_length=50, blank=True, null=True)
    mailing_zip = models.CharField(max_length=10, blank=True, null=True)
    mc_number = models.CharField(max_length=50)
    us_dot_num = models.CharField(max_length=50, blank=True, null=True)
    years_in_business = models.CharField(max_length=50, blank=True, null=True)
    experience_in_trucking_business=models.CharField(max_length=50, blank=True, null=True)
    garaging_zip = models.CharField(max_length=10, blank=True, null=True)
    state_filings=models.BooleanField(default=False)
    fein_ss=models.CharField(max_length=20, blank=True, null=True)
    fein_ss=models.CharField(max_length=20, blank=True, null=True)
    permit_no=models.CharField(max_length=20, blank=True, null=True)
    mailing_and_gagaraging_address_same=models.BooleanField(default=False)
    quote=models.ForeignKey(Quote, models.DO_NOTHING)
    
    
    
        

   
        
class Liability(models.Model):
    id = models.BigAutoField(primary_key=True)
    limit=models.IntegerField(default=750000)  
    hired_auto=models.BooleanField(default=False)  
    cost_of_hire=models.IntegerField(null=True)
    non_owned_auto=models.BooleanField(default=False)
    number_of_employees=models.IntegerField(default=0)
    um=models.BooleanField(default=False)
    um_limit=models.FloatField(default=0.00)
    medical_limit=models.FloatField(default=0.00)
    quote=models.ForeignKey(Quote, models.DO_NOTHING)
    
    class Meta:
        db_table='liability'
        managed=True  

class PD(models.Model):
     id = models.BigAutoField(primary_key=True)
     trailer_interchange=models.BooleanField(default=True)
     trailer_interchange_limit=models.FloatField()
     trailer_interchange_trailers=models.IntegerField()
     non_owned_trailer=models.BooleanField(default=False)
     non_owned_trailer_limit=models.BooleanField()
     non_owned_trailers=models.IntegerField()
     quote=models.ForeignKey(Quote, models.DO_NOTHING)
     
     class Meta:
            db_table='pd'
            managed=True
            
class Cargo(models.Model):
      id = models.BigAutoField(primary_key=True)
      any_one_unit=models.CharField(max_length=100,null=True)
      any_one_unit_deductible=models.FloatField(default=0.00,null=True)
      any_one_loss=models.FloatField(default=0.00,null=True)
      increased_limit_for_specific_shipper=models.FloatField(default=0.00,null=True)
      shipper_name=models.CharField(max_length=100,null=True)
      refriegiration_break_down=models.BooleanField(default=False)
      refeer_deductible=models.FloatField(default=0.00,null=True)
      quote=models.ForeignKey(Quote, models.DO_NOTHING)
      class Meta:
            db_table='cargo'
            managed=True 

class Equipment(models.Model):
    id = models.BigAutoField(primary_key=True)
    year=models.CharField(max_length=4)
    make=models.CharField(max_length=50)
    type=models.CharField(max_length=50)
    value=models.CharField(max_length=50)
    vin=models.CharField(max_length=100)
    quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
    
    class Meta:
        managed=True
        db_table='equipment'
class DriverViolation:
    def __init__(self,quoteid,driverid,violationdate,violation):
        self.quoteid=quoteid
        self.driverid=driverid
        self.violationdate=violationdate
        self.violation=violation

class Driver:
        def __init__(self,name,dob ,license_no ,experience ,license_state ,license_class_type , license_medical_exp ,	license_exp_date,    violation_points,factor,quoteid):
            self.name=name
            self.dob=dob
            self.license_no=license_no
            self.experience=experience
            self.license_state=license_state
            self.license_class_type=license_class_type
            self.license_medical_exp=license_medical_exp
            self.license_exp_date=license_exp_date
            self.violation_points=violation_points,
            self.factor=factor
            self.quoteid=quoteid
            
        
    #id = models.BigAutoField(primary_key=True)
    #name=models.CharField(max_length=100)
    #license=models.CharField(max_length=50)
    #state=models.CharField(max_length=50)
    #experience=models.CharField(max_length=10)
    
    #quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
    
    #class Meta:
        #managed=True
        #db_table='driver'

class RequiredDocument(models.Model):
     id = models.BigAutoField(primary_key=True)
     name=models.CharField(max_length=100)
     filetype=models.CharField(max_length=50)
     quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
     
     class Meta:
         managed=True
         db_table='requireddocument'

class Radius(models.Model):
     id = models.BigAutoField(primary_key=True)       
     inter_state=models.BooleanField(default=True)
     percent_0_to_100=models.FloatField(default=100.00)
     percent_101_to_300=models.FloatField(default=0.00)
     percent_301_to_500=models.FloatField(default=0.00)
     percent_500_plus=models.FloatField(default=0.00)
     
     quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
     
     class Meta:
         managed=True
         db_table='radius'

class ShipperRequirements(models.Model):
    id = models.BigAutoField(primary_key=True)  
    refuse_wastage_garbage=models.BooleanField(default=False)
    property_non_hazardous=models.BooleanField(default=False)
    hazardous_substances_requiring_1_million_liability_or_less:models.BooleanField(default=False) 
    hazardous_substances_requiring_1_million_liability_above:models.BooleanField(default=False)
    quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
    
    class Meta:
         managed=True
         db_table='shipperrequirements'
class HaulingCommodities(models.Model):
    id = models.BigAutoField(primary_key=True)  
    steel_materials=models.BooleanField(default=False)
    haul_refuse_wastage_garbage=models.BooleanField(default=False)
    livestock_animals=models.BooleanField(default=False)
    cement_mixers=models.BooleanField(default=False)
    scrap_metal=models.BooleanField(default=False)
    auto_mobiles=models.BooleanField(default=False)
    tankers=models.BooleanField(default=False)
    boats=models.BooleanField(default=False)
    quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
    
    class Meta:
         managed=True
         db_table='haulingcommodities'
class Commodity(models.Model):
    id = models.BigAutoField(primary_key=True)
    commodity_name=models.CharField(max_length=200)
    percent_of_loads=models.FloatField(default=0.00)
    avg_amount_per_load=models.FloatField(default=0.00)
    max_amount_per_load=models.FloatField(default=0.00)
    quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
    
    
    class Meta:
         managed=True
         db_table='commodity'
         
class UnitRevenueAndMileage(models.Model):
    id = models.BigAutoField(primary_key=True)
    year=models.IntegerField(null=False)
    units=models.IntegerField(null=False)
    expected_revenue=models.FloatField(null=False)
    current_revenue=models.FloatField(null=False)
    expected_mileage=models.FloatField(null=False)
    current_mileage=models.FloatField(null=False)
    quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
    
    class Meta:
         managed=True
         db_table='unitrevenueandmileage'
         
class InsuranceHistoryAndLossExperience(models.Model):
    id = models.BigAutoField(primary_key=True)
    policy_term_inception_exipration=models.CharField(max_length=200)
    insurance_company=models.CharField(max_length=100)
    policy_number=models.CharField(max_length=20)
    number_of_units=models.IntegerField(null=False)
    any_claims=models.BooleanField(default=False)
    claim_details=models.TextField(max_length=8000)
    cancelled_or_non_renewed_policy_last_3_years:models.BooleanField(default=False)
    reason_for_cancelling_or_non_renewing_policy_last_3_years:models.TextField(max_length=8000)
    quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
    
    
    class Meta:
         managed=True
         db_table='insurancehistoryandlossexperience'

class AdditionalInsured(models.Model):
    id = models.BigAutoField(primary_key=True)
    insured_name=models.CharField(max_length=100)
    address=models.CharField(max_length=200)
    city=models.CharField(max_length=100)
    state=models.CharField(max_length=100)
    zip=models.CharField(max_length=100)
       
    quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
    
    class Meta:
         managed=True
         db_table='additionalinsured'

class Coverage(models.Model):
    id = models.BigAutoField(primary_key=True)
    liability=models.BooleanField(default=True)
    combined_single_limit=models.FloatField(default=0.00)
    motor_truck_cargo=models.BooleanField(default=True)
    limit_per_conveyance=models.FloatField(default=0.00)
    general_liability=models.BooleanField(default=True)
    per_occurance_aggregate=models.FloatField(default=0.00)
   
       
    quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
    
    class Meta:
         managed=True
         db_table='coverage'
         
class UnderwriterQuestions(models.Model):
    id = models.BigAutoField(primary_key=True)
    are_filings_required=models.BooleanField(default=False)
    docket_number=models.CharField(max_length=50,null=True)
    mcp=models.CharField(max_length=50,null=True)
    others=models.CharField(max_length=200,null=True)
    actas_freight_broker_freight_forwarder_arrange_loads_for_others=models.BooleanField(default=False)
    brokerage_name=models.CharField(max_length=200,null=True)
    annual_brokerage_revenue=models.CharField(max_length=50,null=True)
    equipment_operated_under_applicant_authority=models.BooleanField(default=False)
    explanation_equipment_non_operated_under_applicant_authority=models.CharField(max_length=200,null=True)
    all_owned_equipment_scheduled_on_application=models.BooleanField(default=False)
    explanation_all_owned_equipment_not_scheduled_on_application=models.CharField(max_length=200,null=True)
    all_scheduled_equipment_owned=models.BooleanField(default=False)
    explanation_all_scheduled_equipment_not_owned=models.CharField(max_length=200,null=True)
    sub_haul_lease_or_hire_equipment_from_others=models.BooleanField(default=False)
    permanently_leased_scheduled_on_the_application=models.BooleanField(default=False)
    permanently_leased_autos_with_drivers=models.BooleanField(default=False)
    trip_leases=models.BooleanField(default=False)
    cost_of_hire_current_year=models.CharField(max_length=15,null=True)
    cost_of_hire_previous_year=models.CharField(max_length=15,null=True)
    leased_to_others=models.BooleanField(default=False)
    do_provide_primary_insurance_leased_to_others=models.BooleanField(default=False)
    coverage_desired_for_primary_insurance_leased_to_others=models.CharField(max_length=200,null=True)
    do_pull_doubles=models.BooleanField(default=False)
    do_pull_tribles=models.BooleanField(default=False)
    haul_containers_or_containerized_freight=models.BooleanField(default=False)
    haul_oversize_or_overweight=models.BooleanField(default=False)
    haul_hazardous_material_or_commodity_require_HAZMAT=models.BooleanField(default=False)
    haul_waste_hauling_involving_residential_exposure=models.BooleanField(default=False)
    haul_electronics=models.BooleanField(default=False)
    shipper_and_percentage_of_the_load=models.CharField(max_length=200,null=True)
    
    quote=models.ForeignKey(Quote, models.DO_NOTHING, blank=True, null=True)
    
    class Meta:
         managed=True
         db_table='underwriterquestions'
class ins_forms_master:
    def __init__(self,id,form_name,form_edition,form_description,form_category,
            form_state,form_condition,form_type,form_active,mandatory,form_order,file_location,company_id,lob_id):
            self.id = id
            self.form_name = form_name
            self.form_edition = form_edition
            self.form_description = form_description
            self.form_category = form_category
            self.form_state = form_state
            self.form_condition = form_condition
            self.form_type = form_type
            self.form_active = form_active
            self.mandatory = mandatory
            self.form_order = form_order
            self.file_location=file_location
            self.company_id =company_id
            self.lob_id =lob_id
class Application:
     def __init__(self,app_id,coverage,insured_id,submission_id,quote_id,
                  policy_number,effective_date,expiration_date,
                  company_id,lob_id,cost_of_policy,has_filings,
                  bill_type_id, status,transaction_type_id,handler_id,
                  invoice_history_exists):
         self.app_id=app_id
         self.coverage=coverage
         self.insured_id=insured_id
         self.submission_id=submission_id
         self.quote_id=quote_id
         self.policy_number=policy_number
         self.effective_date=effective_date
         self.expiration_date=expiration_date
         self.company_id=company_id
         self.lob_id=lob_id
         self.cost_of_policy=cost_of_policy
         self.has_filings=has_filings
         self.bill_type_id=bill_type_id
         self.status=status
         self.transaction_type_id=transaction_type_id
         self.handler_id=handler_id
         self.invoice_history_exists=invoice_history_exists
     def convert_to_tuple(self):
         return (
         
         self.coverage,
         self.insured_id,
         self.submission_id,
         self.quote_id,
         self.policy_number,
         self.effective_date,
         self.expiration_date,
         self.company_id,
         self.lob_id,
         self.cost_of_policy,
         self.has_filings,
         self.bill_type_id,
         self.status,
         self.transaction_type_id,
         self.handler_id,
         self.invoice_history_exists,
         )
         
class Insured:
    def __init__(self,insured_id,
                insured_name,
                insured_dba,
                insured_entity,
	            insured_mailing_address,
	            insured_mailing_city,
	            insured_mailing_state,
	            insured_mailing_zip,
	            insured_garaging_address,
	            insured_garaging_city,
	            insured_garaging_state,
	            insured_garaging_zip,
	            insured_phone,
	            insured_email,
	            history,
                name_on_policy,
	            entity_type,
	            insured_owner_operator,
	            years_of_experience,
	            does_insured_have_dot_number,
	            dot_number,
	            does_insured_require_icc_filings ,
	            does_insured_need_state_filings ,
	            mc_number ,
	            permit_number,
	            insured_rating_on_safer_fmcsa_website,submission_id ):
                self.insured_id=insured_id
                self.insured_name=insured_name
                self.insured_dba=insured_dba
                self.insured_entity=insured_entity
                self.insured_mailing_address=insured_mailing_address
                self.insured_mailing_city=insured_mailing_city
                self.insured_mailing_state=insured_mailing_state
                self.insured_mailing_zip=insured_mailing_zip
                self.insured_garaging_address=insured_garaging_address
                self.insured_garaging_city=insured_garaging_city
                self.insured_garaging_state=insured_garaging_state
                self.insured_garaging_zip=insured_garaging_zip
                self.insured_phone=insured_phone
                self.insured_email=insured_email
                self.history=history
                self.name_on_policy=name_on_policy
                self.insured_email=insured_email
                self.entity_type=entity_type
                self.insured_owner_operator=insured_owner_operator
                self.years_of_experience=years_of_experience
                self.does_insured_have_dot_number=does_insured_have_dot_number  
                self.dot_number=dot_number
                self.does_insured_require_icc_filings=does_insured_require_icc_filings
                self.mc_number=mc_number
                self.does_insured_need_state_filings=does_insured_need_state_filings
                self.permit_number=permit_number
                self.insured_rating_on_safer_fmcsa_website=insured_rating_on_safer_fmcsa_website,
                self.submission_id=submission_id
	
 
    def convert_to_tuple(self):
        return (            
        self.insured_name,
        self.insured_dba,
                self.insured_entity,
                self.insured_mailing_address,
                self.insured_mailing_city,
                self.insured_mailing_state,
                self.insured_mailing_zip,
                self.insured_garaging_address,
                self.insured_garaging_city,
                self.insured_garaging_state,
                self.insured_garaging_zip,
                self.insured_phone,
                self.insured_email,
                self.history,
                self.name_on_policy,
                
                self.insured_owner_operator,
                self.years_of_experience,
                self.does_insured_have_dot_number,  
                self.dot_number,
                self.does_insured_require_icc_filings,
                self.mc_number,
                self.does_insured_need_state_filings,
                self.permit_number,
                self.insured_rating_on_safer_fmcsa_website,
                self.submission_id,
        )
class Coverage:
        def __init__(self,
                     rating_type,liability,
    liability_limit  ,
    hired_auto ,
	hired_auto_type ,
	hired_auto_cost_basic ,
	non_owned_auto_liability ,
	is_non_owned_auto_liability_contractual_basis ,
	no_of_non_owned_units, 
    pd ,
    trailer_interchange ,
	trailer_interchange_limit ,
	trailer_interchange_no_of_units ,
    towing  ,
	towing_limit ,
	cargo  ,
	cargo_limit ,
	cargo_deductible ,
	reefer  ,
	reefer_deductible,
 submission_id):
                      self.rating_type =rating_type
                      self.liability=liability
                      self.liability_limit=liability_limit
                      self.hired_auto=hired_auto
                      self.hired_auto_type=hired_auto_type
                      self.hired_auto_cost_basic=hired_auto_cost_basic
                      self.non_owned_auto_liability=non_owned_auto_liability
                      self.is_non_owned_auto_liability_contractual_basis=is_non_owned_auto_liability_contractual_basis
                      self.no_of_non_owned_units=no_of_non_owned_units
                      self.pd=pd
                      self.trailer_interchange=trailer_interchange
                      self.trailer_interchange_limit=trailer_interchange_limit
                      self.trailer_interchange_no_of_units=trailer_interchange_no_of_units
                      self.towing= towing
                      self.towing_limit=towing_limit
                      self.cargo=cargo
                      self.cargo_limit=cargo_limit
                      self.cargo_deductible=cargo_deductible
                      self.reefer=reefer
                      self.reefer_deductible=reefer_deductible
                      self.submission_id=submission_id
        def convert_to_tuple(self):
            return (            
        self.rating_type ,
                      self.liability,
                      self.liability_limit,
                      self.hired_auto,
                      self.hired_auto_type,
                      self.hired_auto_cost_basic,
                      self.non_owned_auto_liability,
                      self.is_non_owned_auto_liability_contractual_basis,
                      self.no_of_non_owned_units,
                      self.pd,
                      self.trailer_interchange,
                      self.trailer_interchange_limit,
                      self.trailer_interchange_no_of_units,
                      self.towing,
                      self.towing_limit,
                      self.cargo,
                      self.cargo_limit,
                      self.cargo_deductible,
                      self.reefer,
                      self.reefer_deductible,
                      self.submission_id
        )
            
class QuoteInfo:
    def __init__(self,policy_number, 
	agency_apptype_comm, 
	submission_id, 
	status_id, 
	application_type_id, 
	user_id, 
	underwriter_id, 
	underwriter_asst_id, 
	renewal_underwriter_id, 
	handler_id):
        self.policy_number=policy_number
        self.agency_apptype_comm=agency_apptype_comm
        self.submission_id=submission_id
        self.status_id=status_id
        self.application_type_id=application_type_id
        self.user_id=user_id
        self.underwriter_id=underwriter_id
        self.underwriter_asst_id=underwriter_asst_id
        self.renewal_underwriter_id=renewal_underwriter_id
        self.handler_id=handler_id
        
    def convert_to_tuple(self):
            return (    
        self.policy_number,
        self.agency_apptype_comm,
        self.submission_id,
        self.status_id,
        self.application_type_id,
        self.user_id,
        self.underwriter_id,
        self.underwriter_asst_id,
        self.renewal_underwriter_id,
        self.handler_id,
            )
      
         
    

   
        
    
    
    
    
     
     

    
    
    
    
    
    

