from django.db import models

# Create your models here.

class Carrier:
    def __init__(self,id,carrier_name,date_of_incorporation,fein,registered_office_address,city,state,zip,current_status):
        self.id=id
        self.carrier_name=carrier_name
        self.date_of_incorporation=date_of_incorporation
        self.fein=fein
        self.registered_office_address=registered_office_address
        self.city=city
        self.state=state
        self.zip=zip
        self.current_status=current_status
class QuoteSection:
    
        def __init__(self,id,section_name,tabname):
             
             self.section_name=section_name
             self.tabname=tabname
        def get_section_data_without_id(self):
            tp=(self.section_name,self.tabname)
            return tp
    
class QuoteSectionDetails:
    def __init__(self,id,field_name,data_type,section_name,inputtype,size,conversion):
        self.id=-1
        self.field_name=field_name
        self.data_type=data_type
        self.section_name=section_name
        self.inputtype=inputtype
        self.size=size
        self.conversion=conversion
        
    def get_section_details_without_id(self):
            tp=(self.field_name,self.data_type,self.section_name,self.inputtype,self.size,self.conversion)
            return tp
class User:
         def __init__(self,first_name,middle_name,last_name,address,city,state,zip_code,contact_number_office,contact_number_mobile
                      ,email,user_type_id,gender,password):
             self.first_name=first_name
             self.middle_name=middle_name
             self.last_name=last_name
             self.address=address
             self.city=city
             self.state=state
             self.zipcode=zip_code
             self.contact_number_office=contact_number_office
             self.contact_number_mobile=contact_number_mobile
             self.email=email
             self.user_type_id=user_type_id
             self.gender=gender
             self.password=password
             self.agency_id=-1
             self.id=-1
         
class Agency:
    def __init__(self,agency_name,contact_person,address,city,state,zipcode,contact_number_office,contact_number_mobile
                     ,fax ,email,licence_number,password) :
        self.agency_name=agency_name
        self.contact_person=contact_person
        self.address=address
        self.city=city
        self.state=state
        self.zipcode=zipcode
        self.contact_number_office=contact_number_office
        self.contact_number_mobile=contact_number_mobile
        self.fax=fax
        self.email=email
        self.licence_number=licence_number
        self.password=password
class Companymaster:
    def __init__(self,id,company_id,id_name,company_name,phone,active,mga_commission,mga_fees,effective_date,exp_date):
             self.id=id
             self.company_id=company_id
             self.id_name=id_name
             self.company_name=company_name
             self.phone=phone
             self.active=active
             self.mga_commission=mga_commission  
             self.mga_fees=mga_fees
             self.effective_date=effective_date 
             self.exp_date=exp_date 

class lobmaster:   
    def __init__(self,id,lob,lob_id ,name):
             self.id=id
             self.lob=lob
             self.lob_id=lob_id 
             self.name=name 

class companylobmaster:   
    def __init__(self,company_id,lob_id,id):
             self.company_id=company_id
             self.lob_id=lob_id
             self.id=id



class policymaster:   
    def __init__(self,policy_type_id,policy_type_description):
             self.policy_type_id=policy_type_id
             self.policy_type_description=policy_type_description

class usertype:   
    def __init__(self,id,user_type):
             self.id=id
             self.user_type=user_type

class Classofbusiness:
    def __init__(self,id,class_id,class_id_name,bank_id,agent_comm,payable,mga_comm,priority,class_type,percentage):
             self.id=id
             self.class_id=class_id
             self.class_id_name=class_id_name
             self.bank_id=bank_id
             self.agent_comm=agent_comm
             self.payable=payable
             self.mga_comm=mga_comm  
             self.priority=priority
             self.class_type=class_type 
             self.percentage=percentage 

                    
            

             
             
             