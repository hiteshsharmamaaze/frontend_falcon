from django.db import connections

from adminapp.utils import log_errordata
from .models import *
import psycopg2

#ps_connection = psycopg2.connect(user="postgres",
#                                     password="Shamanth@1994",
#                                     host="localhost",
#                                     port="5432",
#                                     database="FalconDB")

dbConnection= connections['default'].cursor()


def get_all_submissions():
    dbConnection= connections['default'].cursor()
    result = []
    try:
        dbConnection.execute("select udf_get_ins_submissions_json();", ())
        rows=dbConnection.fetchall()
        result = rows
        return result
    except (Exception, psycopg2.DatabaseError) as error:
        #print(error)
        logstatus = "Internal Server Error"
    return logstatus


# def add_carrier(carrier):
#     pass

# def add_sections(section):
#     #cursor = dbConnection.cursor()
#     #cursor = ps_connection.cursor()
#     try:
#         dbConnection= connections['default'].cursor()
#         res=dbConnection.callproc('usp_add_quote_sections',section.get_section_data_without_id())
#         if dbConnection.rowcount >0 :
#             return "SUCESS"
    
#     except (Exception, psycopg2.DatabaseError) as error:
#         pass
    
#     return "FAIL"
    
# def add_section_details(sectiondetails):
#     #cursor = dbConnection.cursor()
#     #cursor = ps_connection.cursor()
#     try:
#         dbConnection= connections['default'].cursor()
#         res=dbConnection.callproc('usp_add_quote_sections',sectiondetails.get_section_data_without_id())
#         if dbConnection.rowcount >0 :
#             return "SUCESS"
    
#     except (Exception, psycopg2.DatabaseError) as error:
#         pass
    
#     return "FAIL"

# def get_quote_sections():
#     #cursor = dbConnection.cursor()
#     #cursor = ps_connection.cursor()
   
#     try:
#         dbConnection= connections['default'].cursor()
#         res=dbConnection.callproc('uf_get_quote_sections_json')
#         result = dbConnection.fetchall()
        
#         return result
    
#     except (Exception, psycopg2.DatabaseError) as error:
#         pass
    
#     return "FAIL"
def get_agency_name(email):
    #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
    logstatus=''
    try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_user_agency ( %s);", (email,))
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                logstatus=rows[0][0].get('agency_name')
                
                print(logstatus)
            else:
                logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
          
           logstatus="Internal Server Error"
    return  logstatus
    

# def get_quote_section_details():
#     #cursor = dbConnection.cursor()
#     #cursor = ps_connection.cursor()
   
#     try:
        
#         dbConnection= connections['default'].cursor()
#         res=dbConnection.callproc('uf_get_quote_section_fields_json')
#         result = dbConnection.fetchall()
        
#         return result
    
#     except (Exception, psycopg2.DatabaseError) as error:
#         pass
    
#     return "FAIL"
def get_agency_details_db(agency_id):
    
    # udf_get_liability_base_rate_and_territory_factor_json('107','AZ')
    #dbConnection = ps_connection.cursor()
    dbConnection= connections['default'].cursor()
    
    agency_info = {"id_name":'',"agency_id":-1,"agency_name":'',"phone":''}
    
    try:
            
            query= dbConnection.mogrify("select udf_get_agency_details(%s);", (agency_id,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            print(rows,' agency rows')
            if len(rows)>0:
               
                id_name=rows[0][0].get('id_name')
                agency_id=rows[0][0].get('agency_id')
                agency_name=rows[0][0].get('agency_name')
                phone=rows[0][0].get('phone')
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
                agency_info = {"id_name":id_name,"agency_id":agency_id,"agency_name":agency_name,"phone":phone}
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           log_errordata(error,'test')
           agency_info = {"id_name":'',"agency_id":-1,"agency_name":'',"phone":''}
           u_id=-1

    return  agency_info

def login(userid,pwd):
       
       #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
       logstatus=''
       user_dict={}
       
       try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_user_login(%s, %s);", (userid, pwd))
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                logstatus="SUCCESS"
                user_dict=rows[0][0]
                print(user_dict)
               
            else:
                logstatus='FAILURE'            
            #return logstatus
           
        
       except (Exception, psycopg2.DatabaseError) as error:
          
           logstatus="Internal Server Error with database"
           logstatus="FAILURE"
           print(error)
           #logstatus=error.__str__
       return  logstatus,user_dict
   
def add_agency(agency):
       #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
       res=get_agency_name_status(agency.agency_name) 
       if res!='':
           return res
       res=get_agency_email_status(agency.email)
      
       if res!='':
           return res
       try:
            dbConnection= connections['default'].cursor()   
            a_id=-1
            qry=dbConnection.mogrify ('select udf_add_agency(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);' ,
                                (agency.agency_name,
                                 agency.contact_person,
            agency.address,  
            agency.city,
            agency.state,
            agency.zipcode,   
           
            agency.contact_number_office,
            agency.contact_number_mobile,
            agency.email,
            agency.fax,
            agency.licence_number,
            agency.password)         
           )
            
            dbConnection.execute(qry.decode('utf-8'))  
           
             
                      
            #ps_connection.commit()
            dbConnection.commit()
               
            rows=dbConnection.fetchall()
           
            if len(rows)>0 :
                user_id=rows[0][0]
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
        
       except Exception as error:
          
           print(error)
           res="Internal Server Error"
       return  res 
def get_admin_user(id):
        #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
        print(id)
        rows=[]
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_user_by_id_json(%s);", (id,))
            dbConnection.execute(query)
            rows=cursor.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            #if len(rows)>0:
            #   u_id=rows[0][0].get('id')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           
          print(error)
        return  rows
    
   
def get_user_type_id(user_type):
       #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
       u_id=-1;
       try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_user_type_by_name_json(%s);", (user_type,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                u_id=rows[0][0].get('id')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
       except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=1
       return  u_id
   
   
def add_user(user):
       #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
       user_id=-1
       
       u_t_id=get_user_type_id(user.user_type_id)
       
       
       res=get_user_email_status(user.email)
       if res!='':
           return res
       try:
            
            dbConnection= connections['default'].cursor()
            qry=dbConnection.mogrify ('select udf_add_admin_user(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);' ,(user.first_name,
                 
            user.middle_name,
            user.last_name,
            user.address,
            user.city,
            user.state,
            user.zipcode,
            user.contact_number_office,
            user.contact_number_mobile,
            user.email,
            str(u_t_id),
            user.password,
            user.gender,
            str(user.agency_id),
            str(user_id)))
            
            dbConnection.execute(qry.decode('utf-8'))  
           
             
                      
            #ps_connection.commit()
            dbConnection.commit()
            #print("Completed")   
            rows=dbConnection.fetchall()
            #print("Fetched")
            #len(rows)
            if len(rows)>0 :
                user_id=rows[0][0]
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
        
       except Exception as error:
          
           print(error)
           res="Internal Server Error"
       return  res 
   
def get_user_type_id(user_type):
       #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
       u_id=1;
       try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_user_type_by_name_json(%s);", (user_type,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                u_id=rows[0][0].get('id')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
       except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
       return  u_id
def get_agency_name_status(agencyname):
    #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
    msg=''
       
    try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_get_agency_name_status_json(%s);", (agencyname,))
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                u_id=rows[0][0].get('id')
                msg='other Agency already registered with the '+agencyname      
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           pass
    return  msg

def get_agency_email_status(email):
    #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
    msg=''
       
    try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_get_agency_email_status_json(%s);", (email,))
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                u_id=rows[0][0].get('id')
                msg='other agency already registered with the '+email      
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           pass
    return  msg
    
   
def get_user_email_status(email):
    #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
    msg=''
       
    try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_get_user_type_email_json(%s);", (email,))
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                u_id=rows[0][0].get('id')
                msg='other user already registered with the '+email      
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           pass
    return  msg


def get_agency_user_types():
        #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
        
        try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_get_agency_user_type_json();",())
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(rows)
            
            reult=rows            
            return reult
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           logstatus="Internal Server Error"
           
        return  logstatus

def get_claims_user_types():
        #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
        
        try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_get_claims_user_type_json();",())
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(rows)
            
            reult=rows            
            return reult
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           logstatus="Internal Server Error"
           
        return  logstatus

def get_all_user_types():
        #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
        
        try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_get_user_type_json();",())
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(rows)
            
            reult=rows            
            return reult
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           logstatus="Internal Server Error"
           
        return  logstatus
def get_all_agencies():
        #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
        result=[]
        try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_get_agencies_json();",())
            rows=dbConnection.fetchall()
            
            
            reult=rows            
            return reult
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           logstatus="Internal Server Error"
        return  logstatus  

def get_agency_id(agency_name):
    #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
    msg=''
       
    try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_get_agency_id_with_agnecy_name(%s);", (agency_name,))
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                u_id=rows[0][0].get('id')
            else:
                u_id=-1         
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
            msg=u_id
    except (Exception, psycopg2.DatabaseError) as error:
           
           pass
    return  msg
    
def get_all_agency_users(agency_name):
    
        agency_id= get_agency_id(agency_name)
        #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
        result=[]
        try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_get_agency_users_json();",(agency_id,))
            rows=dbConnection.fetchall()
            
            #print(rows) 
            result=rows            
            return result
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           logstatus="Internal Server Error"
        return  logstatus  
    
def get_all_users():
        #cursor = dbConnection.cursor()
    #cursor = ps_connection.cursor()
        result=[]
        try:
            dbConnection= connections['default'].cursor()
            dbConnection.execute("select udf_get_users_json();",())
            rows=dbConnection.fetchall()
            
            
            reult=rows            
            return reult
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           logstatus="Internal Server Error"
        return  logstatus
def get_medical_premium(state,limit):
    #udf_get_medical_premium_json
    #print(state,limit,'medical')
    premium=0
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_medical_premium_json(%s,%s);", (state,limit,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
           
            
            if len(rows)>0:
                premium=rows[0][0].get('premium')
               
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
    return premium
    
    
    return  base_rate_dict

def get_territory_code_by_zipcode(zipcode):
    
    
    
    territory_code=0
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_state_territory_code_by_zipcode_json(%s);", (zipcode,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                territory_code=rows[0][0].get('territory')
                #territory_factor=rows[0][0].get('territory_factor')
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
    return territory_code
    
    
    return  base_rate_dict
    
def get_base_rate_and_territory_factor(territory_code,state):
    # udf_get_liability_base_rate_and_territory_factor_json('107','AZ')
    base_rate=0
    territory_factor=0
    
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_liability_base_rate_and_territory_factor_json(%s,%s);", (territory_code.strip(),state.strip(),))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
                print(len(rows),' length')
                base_rate=rows[0][0].get('base_rate')
               
                territory_factor=rows[0][0].get('territory_factor')
                print(territory_factor)
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error,"In query.....")
           u_id=-1
    base_rate_dict={"base_rate":base_rate,"territory_factor":territory_factor}
    print(base_rate_dict," base rate dict")
    return  base_rate_dict
    #pass
def get_territory_factor(territory_code):
    pass
def get_lcm_factor():
    lcm_fcator=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_lcm_factor_json();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               lcm_factor=rows[0][0].get('lcm_factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return 1.87
def get_ilf_factor():
    ilf_fcator=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_ilf_factor_json();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               ilf_factor=rows[0][0].get('ilf_factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return 1.88

def get_pollution_factor():
    #udf_get_pollution_factor_json
    pollution_fcator=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_pollution_factor_json();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               pollution_fcator=rows[0][0].get('pollution_factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return   pollution_fcator

def get_state_factor():
    #udf_get_state_factor_json
    state_fcator=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_ins_state_factor_json();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               state_factor=rows[0][0].get('state_factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return   state_fcator

def get_primary_factor():
    primary_factor=1
    
    #udf_get_primary_factor_json
    
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_primary_factor_json();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               primary_factor=rows[0][0].get('primary_factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return  1.45
    
def get_rate_control_factor():
    #udf_get_rate_control_factorr_json
    rate_control_fcator=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_rate_control_factorr_json();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               rate_control_fcator=rows[0][0].get('rate_control_factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return   rate_control_fcator


def get_vehicle_weight_factor(vehcile_type):
    #udf_get_ins_vehicle_type_factor
    
    vehicle_weight_factor=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_ins_vehicle_model_factor(%s);", (vehcile_type,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               vehicle_weight_factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
    if vehicle_weight_factor==0:
        vehicle_weight_factor=1
           
    return   vehicle_weight_factor
    
def get_vehicle_type_factor(vehcile_type):
    #udf_get_ins_vehicle_type_factor
    vehicle_type_factor=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_ins_vehicle_type_factor(%s);", (vehcile_type,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               vehicle_type_factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return   vehicle_type_factor
   
def get_radius_factor(radius):
    radius_factor=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_radius_factor(%s);", (radius,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               radius_factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return   radius_factor
def  get_commodityies():
        data=""
        try:
            
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_ins_commodity_json();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            #print(rows)
            if len(rows)>0:
              
              
              data=rows;
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           u_id=-1
    #print(data)       
        return   data
    
def get_commodity_factor(commodity):
    print(commodity)
    commodity_al_factor=1
    commodity_pd_factor=1
    commodity_cargo_factor=1
    commodity_eligibility=''
    #print(commodity)
    data={'commodity_al_factor':commodity_al_factor,'commdity_pd_factor':commodity_pd_factor,'commodity_cargo_factor':commodity_cargo_factor,'commodity_eligibility':commodity_eligibility }
    print(commodity+" in views")
    try:
            
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_commodity_factor(%s);", (commodity,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            #print(rows)
            if len(rows)>0:
              
              commodity_al_factor=rows[0][0].get('commodity_al_factor')
              commodity_pd_factor=rows[0][0].get('commodity_pd_factor')
              commodity_cargo_factor=rows[0][0].get('commodity_cargo_factor')
              commodity_eligibility= rows[0][0].get('commodity_eligibility') 
              data={'commodity_al_factor':commodity_al_factor,'commodity_pd_factor':commodity_pd_factor,'commodity_cargo_factor':commodity_cargo_factor,'commodity_eligibility':commodity_eligibility }
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           u_id=-1
    #print(data)       
    return   data
    
#def get_commodity_factor(commodity):
    #pass
def get_years_of_experience_factor(yxp):
    factor=1
    if(int(yxp)>5):
        yxp='5'
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_years_of_experience_factor_json(%s);", (yxp,))
           
                
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                factor=rows[0][0].get('years_factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           u_id=-1
    return  factor
def get_liability_limit_factor(liability):
    factor=1
    
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select  udf_liability_limit_factor_factor_json(%s);", (liability,))
           
                
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           u_id=-1
    return  factor
    
def get_type_of_use_factor(usetype):
    factor=1
    
    try:
            dbConnection= connections['default'].cursor()           
            query= dbConnection.mogrify("select  udf_type_of_use_factor_json(%s);", (usetype,))
           
                
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           u_id=-1
    return  factor
def get_secondary_class_factor(sclass):
    
    factor=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_secondary_class_factor_json(%s);", (sclass,))
           
                
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           u_id=-1
    return  factor
def get_trailer_type_factor(trailer_type):
    factor=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_trailer_type_factor_json(%s);", (trailer_type,))
           
                
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
                factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           u_id=-1
    return  factor
#udf_trailer_type_factor_json

def get_safer_factor(description):
    
    factor=1
    
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_safer_factor_json(%s);", (description,))
           
                
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            #print(type(rows[0]))
            
            if len(rows)>0:
                factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           u_id=-1
    return  factor
################# pd #####################

def get_pd_deductible_factor(deductible):
    
    factor=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_pd_deductible_factor_json(%s);", (deductible,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               #data={"base_rate":rows[0][0].get('base_rate'),"factor":rows[0][0].get('factor')}
               factor=rows[0][0].get('factor')
               
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error + " problem in deductions")
           u_id=-1
          
    return  factor


def get_pd_state_factor(state):
    
    factor=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_pd_state_factor_json(%s);", (state,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               #data={"base_rate":rows[0][0].get('base_rate'),"factor":rows[0][0].get('factor')}
               factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return  factor



def get_pd_base_rate_factor(stated_value):
    #udf_get_ins_vehicle_type_factor
    #data={"base_rate":1,"factor":1}
    factor=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_pd_base_rate_json(%s);", (stated_value,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               #data={"base_rate":rows[0][0].get('base_rate'),"factor":rows[0][0].get('factor')}
               factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return  factor



def get_pd_vehicle_make_factor(vmake):
    #udf_get_ins_vehicle_type_factor
    vehicle_make_factor=1
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_pd_vehicle_make_factor_json(%s);", (vmake,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               vehicle_make_factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return  vehicle_make_factor

################ UM PREMIUM #################
def get_um_premium_rate_per_vehicle(st,cov):
    #udf_get_ins_vehicle_type_factor
    premium_rate=1;
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_um_premium_rate(%s,%s);", (st,cov,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               data={"premium_rate":rows[0][0].get('cost_per_unit')}
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
    return  premium_rate
    ############### cargo ######################
    
def get_cargo_base_rate():
        #udf_get_ins_vehicle_type_factor
        factor=1
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_cargo_base_rate_factor_json();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               factor=rows[0][0].get('base_rate')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
          
           u_id=-1
        print(factor," base rate")   
        return  factor
def get_cargo_state_factor(state):
        #udf_get_ins_vehicle_type_factor
        factor=1
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_cargo_state_factor_json(%s);", (state,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
        return  factor
    
    
def get_cargo_radius_factor(radius):
        #udf_get_ins_vehicle_type_factor
        factor=1
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_ins_cargo_radius_factor_by_description_json(%s);", (radius,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
        return  factor
    
def get_cargo_limit_factor(limit):
        #udf_get_ins_vehicle_type_factor
        factor=1
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_cargo_limit_factor_factor_json(%s);", (limit,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
        return  factor
def get_cargo_deductible_factor(limit):
        #udf_get_ins_vehicle_type_factor
        factor=1
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_cargo_deductible_factor_json(%s);", (limit,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
        return  factor


    
def get_cargo_refeer_deductible_factor(limit):
            #udf_get_ins_vehicle_type_factor
        factor=1
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_refeer_cargo_deductible_factor_json(%s);", (limit,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
        return  factor
    

def get_towing_premium(limit):
        
        premium=0
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_towing_premium_json(%s);", (limit,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               premium=rows[0][0].get('charge')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
           
        return  premium
    
def get_non_owned_auto_premium(limit):
        
        charges=0
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_non_owned_auto_premium_rate_json(%s);", (limit,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               charges=rows[0][0].get('charges')
              
                
            
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           print(error," exception ")
           charges=0
           
        return  charges
def get_pip_premium(state,limit,radius):
    premium=0
    print(state,limit,radius)
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_pip_premium_json(%s,%s,%s);", (state.strip(),limit.strip(),radius.strip(),))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            
            if len(rows)>0:
                tp=rows[0][0]
                
                if radius.strip()=='Local': 
                    
                    charges=tp['local']
                elif  radius.strip()=='Intermediate':  
                    charges=tp['intermediate']
                elif  radius.strip()=='Intermediateplus':  
                    charges=tp['intermediateplus']
            premium=charges
                
                
            
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           premium=0
           print(error,"error in pip")
           
    return  premium
       
def get_premium_type_availability_in_state(state_code,premium_type ) :
    print(state_code,premium_type)
    is_available=False
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_is_premium_available_by_state_json(%s,%s);", (state_code,premium_type,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(rows)
            
            if len(rows)>0:
               availability=rows[0][0]
               print(availability)
              
               if availability=='Yes':
                   is_available=True
                
            
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           is_available=False
           
    print(is_available)       
    return  is_available    
def get_vehicle_model_factor(model):  

        factor=1
        try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_pd_vehicle_make_factor_json(%s);", (model,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            
            if len(rows)>0:
               factor=rows[0][0].get('factor')
                
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
           
        
        except (Exception, psycopg2.DatabaseError) as error:
           
           pass
           
        return  factor  
def get_um_range_per_state(_state) :
    is_available=False
    um_status={"available":False,"minlimit":0,"maxlimit":0,"rate":0}
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_um_premium_rate_factor_json(%s);", (_state,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(rows)
            
            if len(rows)>0:
               um_status={"available":True,"minlimit":rows[0][0].get('minval'),"maxlimit":rows[0][0].get('maxval'),"unit_cost":rows[0][0].get('unit_cost')}
                
            
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           is_available=False
           
       
    return   um_status  
def get_driver_violation_points(_violation) :
    points=1
    
    try:
            dbConnection= connections['default'].cursor()
            query= dbConnection.mogrify("select udf_get_ins_driver_violation_points(%s);", (_violation,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            print(rows)
            
            if len(rows)>0:
               #um_status={"available":True,"minlimit":rows[0][0].get('minval'),"maxlimit":rows[0][0].get('maxval'),"unit_cost":rows[0][0].get('unit_cost')}
              
              points=  rows[0][0]["points"]
              
            
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           print(error," error in points retrieval")
           #is_available=False
           
    #print(points," points returned")   
    print(points,_violation)
    return   points  

def add_company_master_db(Companymaster):
       dbConnection= connections['default'].cursor()
       user_id=-1
       try:
            query= dbConnection.mogrify ('select public.udf_add_company_master(%s,%s,%s,%s,%s,%s,%s,%s,%s);' ,(
            int(Companymaster.company_id),
            Companymaster.id_name,
            Companymaster.company_name,
            Companymaster.phone,
            Companymaster.active,
            int(Companymaster.mga_commission),
            int(Companymaster.mga_fees),
            Companymaster.effective_date,
            Companymaster.exp_date    
             
             ))        
            try:
                dbConnection.execute(query) 
            except:
                pass     
             
                     
           # dbConnection.commit()
            #print("Completed")  
            rows=dbConnection.fetchall()
            #print("Fetched")
           
            #len(rows)
            if len(rows)>0 :
                user_id=rows[0][0]
                print(user_id)
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
       
       except Exception as error:
         
           print(error)
           res="Internal Server Error"
       finally:
        dbConnection.close()
       return  res


def  get_company_master_db():
        dbConnection= connections['default'].cursor()
        data=[]
        try:
           
            
            query= dbConnection.mogrify("SELECT public.udf_get_ins_companies_from_master();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            print(rows,"THIS IS THE ROWS VALUES")
            if len(rows)>0:
              for r in rows:
                data.append(r[0])
            #    logstatus='FAILURE'            
            #return logstatus
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           #u_id=-1
        #    print(data)
        finally:
            dbConnection.close()      
        return data

def get_company_master_by_id_db(_id):
    dbConnection= connections['default'].cursor()
    # udf_get_liability_base_rate_and_territory_factor_json('107','AZ')
   
   
    try:
           
            query= dbConnection.mogrify("select public.udf_get_ins_company_from_master_by_id(%s);", (_id,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            print(rows,"vvv ")
            if len(rows)>0:
               
                id_name=rows[0][0].get('id_name')
                company_name=rows[0][0].get('company_name')
                phone=rows[0][0].get('phone')
                active=rows[0][0].get('active')
                mga_commission=rows[0][0].get('mga_commission')
                mga_fees=rows[0][0].get('mga_fees')
                effective_date=rows[0][0].get('effective_date')
               
               
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
            master_company_details={"id_name":id_name,"company_name":company_name,"phone":phone,"active":active,"mga_commission":mga_commission,"mga_fees":mga_fees,"effective_date":effective_date}
           
       
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
    finally:
            dbConnection.close() 

    return  master_company_details


def update_company_master_db(companymaster):
        dbConnection= connections['default'].cursor()
        print(id)
        rows=[]
        res=''
        try:
           
            query= dbConnection.mogrify("select public.udf_update_company_master(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", (
            int(companymaster.company_id),
            companymaster.id_name,
            companymaster.company_name,
            companymaster.phone,
            companymaster.active,
            int(companymaster.mga_commission),
            int(companymaster.mga_fees),
            companymaster.effective_date,
            companymaster.exp_date,
            companymaster.id

             
            ))
            dbConnection.execute(query)
           # ps_connection.commit()
            rows=dbConnection.fetchall()
            #print(type(rows))
            if len(rows)>0 :
                user_id=rows[0][0]
                print(user_id,"the values are")
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
                data={"id":user_id,"Message":res}  
        except (Exception, psycopg2.DatabaseError) as error:
           
          print(error)
        finally:
            dbConnection.close() 
        return  data




def  get_lobmaster_db():
        dbConnection= connections['default'].cursor()
        data=[]
        try:
            
            query= dbConnection.mogrify("SELECT public.udf_get_ins_lob_from_master();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            print(rows,"THIS IS THE ROWS VALUES")
            if len(rows)>0:
              for r in rows:
                data.append(r[0])
              
            #    logstatus='FAILURE'            
            #return logstatus
        except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           #u_id=-1
           print(data) 
        finally:
            dbConnection.close()      
        return   data

def get_lobmaster_by_id_db(_id):
    dbConnection= connections['default'].cursor()
    try:
            query= dbConnection.mogrify("select public.udf_get_ins_lob_from_master_by_id(%s);", (_id,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            print(rows,"vvv ")
            if len(rows)>0:
               
                lob=rows[0][0].get('lob')
                id=_id

                name=rows[0][0].get('name')
                

            #else:
            #    logstatus='FAILURE'            
            #return logstatus
            lob_master_details={"id":id,"lob":lob,"name":name}
           
        
    except (Exception, psycopg2.DatabaseError) as error:
           
           u_id=-1
    finally:
            dbConnection.close() 

    return  lob_master_details

def add_lobmaster_db(lobmaster):
       dbConnection= connections['default'].cursor()
       user_id=-1
       try:
            query= dbConnection.mogrify ('select public.udf_add_lob_master(%s,%s,%s);' ,(int(lobmaster.lob),
            lobmaster.lob_id,
            lobmaster.name
             ))        
            dbConnection.execute(query)      
           # dbConnection.commit()
            #print("Completed")   
            rows=dbConnection.fetchall()
            #print("Fetched")
            #len(rows)
            if len(rows)>0 :
                user_id=rows[0][0]
                print(user_id)
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
       except Exception as error:
           print(error)
           res="Internal Server Error"
       finally:
            dbConnection.close() 
       return  res 

def update_lob_master_db(lobmaster):
        dbConnection= connections['default'].cursor()
        print(id)
        rows=[]
        res=''
        try:
            query= dbConnection.mogrify("select public.udf_update_lob_master(%s,%s,%s,%s);", (
            int(lobmaster.lob),
            lobmaster.lob_id,
            lobmaster.name,
            int(lobmaster.id),
            ))
            dbConnection.execute(query)
           # ps_connection.commit()
            rows=dbConnection.fetchall()
            #print(type(rows))
            if len(rows)>0 :
                user_id=rows[0][0]
                print(user_id,"the values are")
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
        except (Exception, psycopg2.DatabaseError) as error:
          print(error)
        finally:
            dbConnection.close() 
        return  res
#udf_get_all_lobs

def get_lobs():
    dbConnection= connections['default'].cursor()
   
    master_lob_details=[]
   
    try:
           
            query= dbConnection.mogrify("select udf_get_all_lobs();")
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            if len(rows)>0:
               
               for row in rows:
                id=row[0]['lob_id']
                lob=row[0]['lob_id_name']
                name=row[0]['description']
                master_lob_details.append({"id":id,"lob":lob,"name":name})
               
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
         
           
       
    except (Exception, psycopg2.DatabaseError) as error:
           return error
           u_id=-1
    finally:
            dbConnection.close() 

    return  master_lob_details

def get_lobs_by_company_id_db(_id):
    dbConnection= connections['default'].cursor()
   
    master_lob_details=[]
   
    try:
           
            query= dbConnection.mogrify("select public.udf_get_lobs_from_xref_by_comapny_id(%s);", (_id,))
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            
            if len(rows)>0:
               
               for row in rows:
                id=row[0]['id']
                lob=row[0]['lob']
                name=row[0]['name']
                master_lob_details.append({"id":id,"lob":lob,"name":name})
               
            #else:
            #    logstatus='FAILURE'            
            #return logstatus
         
           
       
    except (Exception, psycopg2.DatabaseError) as error:
           return error
           u_id=-1
    finally:
            dbConnection.close() 

    return  master_lob_details

def get_all_forms_listby_companyid_lobid_db(objData):
    dbConnection= connections['default'].cursor()
    """This function is used to get all forms list by using company id and lob id.

    Args:
        objData (HTTP request): company id, lob id are the parameters recieved with the object data.

    Returns:
        dict: returns Json data with in the form of dictionary.
    """
    formslist=[]
    try:
            
            company_id=objData.data['company_id']
            lob_id=objData.data['lob_id']
            form_type =objData.data['form_type']
            query= dbConnection.execute("select udf_get_all_forms_bycompanyid_lobid_json(%s,%s,%s);",(company_id,lob_id,form_type))
            rows=dbConnection.fetchall()
            formslist=rows
            # if len(rows)>0:
            #    for frm in rows:
            #     formslist.append(frm[0])   
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
    finally:
            dbConnection.close()      
    return  formslist



def set_active_company_status_db(_id):
    dbConnection = connections['default'].cursor()

    try:
        
        qry = dbConnection.mogrify(
            "select udf_set_company_master_status(%s);", (_id,)
        )

       # print(qry,' form_update')
        dbConnection.execute(qry)
        #dbConnection.commit()
        res="Company Deleted successfully"
        data={"Message":res} 
        return data
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
            dbConnection.close()
    return "FAIL"

def get_company_lob_master_db():
    dbConnection= connections['default'].cursor()
    data=[]
    try:
            
            query= dbConnection.mogrify("SELECT public.udf_get_comapny_lob_from_xref();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            print(rows,"THIS IS THE ROWS VALUES")
            if len(rows)>0:
              for r in rows:
                data.append(r[0])
              
            #    logstatus='FAILURE'            
            #return logstatus
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           #u_id=-1
           print(data) 
    finally:
            dbConnection.close()      
    return   data


def add_company_lob_master_db(_companylobmaster):
       dbConnection= connections['default'].cursor()
       user_id=-1
       try:
            query= dbConnection.mogrify ('select public.udf_add_comapny_lob_to_xref(%s,%s);' ,(int(_companylobmaster.company_id),
            int(_companylobmaster.lob_id),

             ))        
            dbConnection.execute(query)      
           # dbConnection.commit()
            #print("Completed")   
            rows=dbConnection.fetchall()
            #print("Fetched")
            #len(rows)
            if len(rows)>0 :
                result=rows[0][0]
                print(result)
                if result=='success' :
                    res="SUCCESS"
                else:
                    res="FAILURE"
       except Exception as error:
           print(error)
           res="Internal Server Error"
       finally:
            dbConnection.close()
       return  res 


def update_company_lob_master_db(_companylobmaster):
        dbConnection= connections['default'].cursor()
        print(id)
        rows=[]
        res=''
        try:
            query= dbConnection.mogrify("select public.udf_update_company_master(%s,%s,%s);", (int(_companylobmaster.company_id),
            int(_companylobmaster.lob_id),
            int(_companylobmaster.id),
            ))
            dbConnection.execute(query)
           # ps_connection.commit()
            rows=dbConnection.fetchall()
            #print(type(rows))
            if len(rows)>0 :
                user_id=rows[0][0]
                print(user_id,"the values are")
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
                data={"id":user_id,"Message":res}  
        except (Exception, psycopg2.DatabaseError) as error:
          print(error)
        finally:
            dbConnection.close()
        return  data




def get_policy_type_master_db():
    dbConnection= connections['default'].cursor()
    data=[]
    try:
            
            query= dbConnection.mogrify("SELECT public.udf_get_ins_policy_from_type();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            print(rows,"THIS IS THE ROWS VALUES")
            if len(rows)>0:
              for r in rows:
                data.append(r[0])
              
            #    logstatus='FAILURE'            
            #return logstatus
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           #u_id=-1
           print(data)
    finally:
            dbConnection.close()       
    return   data

def add_policy_type_master_db(_policymaster):
       dbConnection= connections['default'].cursor()
       user_id=-1
       try:
            query= dbConnection.mogrify ('select public.udf_add_policy_type(%s);' ,(
            _policymaster.policy_type_description,
             ))        
            dbConnection.execute(query)      
           # dbConnection.commit()
            #print("Completed")   
            rows=dbConnection.fetchall()
            #print("Fetched")
            #len(rows)
            if len(rows)>0 :
                user_id=rows[0][0]
                print(user_id)
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
       except Exception as error:
          
           print(error)
           res="Internal Server Error"
       finally:
            dbConnection.close()
       return  res 

def update_policy_type_master_db(_policymaster):
        dbConnection= connections['default'].cursor()
        print(id)
        rows=[]
        res=''
        try:
           
            query= dbConnection.mogrify("select public.udf_update_policy_type(%s,%s);", (
            
            _policymaster.policy_type_description,
            int(_policymaster.policy_type_id),
            ))
            dbConnection.execute(query)
           # ps_connection.commit()
            rows=dbConnection.fetchall()
            #print(type(rows))
            if len(rows)>0 :
                user_id=rows[0][0]
                print(user_id,"the values are")
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
                data={"id":user_id,"Message":res}  
        except (Exception, psycopg2.DatabaseError) as error:
           
          print(error)
        finally:
            dbConnection.close()
        return  data



def get_user_type_db():
    dbConnection= connections['default'].cursor()
    data=[]
    try:
            
            query= dbConnection.mogrify("SELECT public.udf_get_user_type_json();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            print(rows,"THIS IS THE ROWS VALUES")
            if len(rows)>0:
              for r in rows:
                data.append(r[0])
              
            #    logstatus='FAILURE'            
            #return logstatus
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           #u_id=-1
           print(data)  
    finally:
            dbConnection.close()     
    return   data


def add_user_type_db(_usertype):
       dbConnection= connections['default'].cursor()
       user_id=-1
       try:
            query= dbConnection.mogrify ('select public.udf_add_user_type(%s);' ,(
            _usertype.user_type,
             ))        
            dbConnection.execute(query)      
           # dbConnection.commit()
            #print("Completed")   
            rows=dbConnection.fetchall()
            #print("Fetched")
            #len(rows)
            if len(rows)>0 :
                user_id=rows[0][0]
                print(user_id)
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
       except Exception as error:
          
           print(error)
           res="Internal Server Error"
       finally:
            dbConnection.close()
       return  res 


def update_user_type_db(_usertype):
        dbConnection= connections['default'].cursor()
        print(id)
        rows=[]
        res=''
        try:
            query= dbConnection.mogrify("select public.udf_update_user_type(%s,%s);", (int(_usertype.id),
            _usertype.user_type
            ))
            dbConnection.execute(query)
           # ps_connection.commit()
            rows=dbConnection.fetchall()
            #print(type(rows))
            if len(rows)>0 :
                user_id=rows[0][0]
                print(user_id,"the values are")
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
                data={"id":user_id,"Message":res}  
        except (Exception, psycopg2.DatabaseError) as error:
          print(error)
        finally:
            dbConnection.close()
        return  data


def get_class_of_business_db():
    dbConnection= connections['default'].cursor()
    data=[]
    try:
            
            query= dbConnection.mogrify("SELECT public.udf_get_class_of_business();", ())
            dbConnection.execute(query)
            rows=dbConnection.fetchall()
            #print(type(rows))
            #print(type(rows[0]))
            print(rows,"THIS IS THE ROWS VALUES")
            if len(rows)>0:
              for r in rows:
                data.append(r[0])
              
            #    logstatus='FAILURE'            
            #return logstatus
    except (Exception, psycopg2.DatabaseError) as error:
           print(error)
           #u_id=-1
           print(data)
    finally:
            dbConnection.close()       
    return   data


def add_class_of_business_db(_classofbusiness):
       dbConnection= connections['default'].cursor()
       user_id=-1
       try:
            query= dbConnection.mogrify ('select public.udf_add_class_of_business(%s,%s,%s,%s,%s,%s,%s,%s,%s);' ,(_classofbusiness.class_id,
            _classofbusiness.class_id_name,
            int(_classofbusiness.bank_id),
            _classofbusiness.agent_comm,
            _classofbusiness.payable,
            _classofbusiness.mga_comm,
            int(_classofbusiness.priority),
            _classofbusiness.class_type,
            int(float(_classofbusiness.percentage))
             ))        
            dbConnection.execute(query)      
           # dbConnection.commit()
            #print("Completed")   
            rows=dbConnection.fetchall()
            #print("Fetched")
            #len(rows)
            if len(rows)>0 :
                user_id=rows[0][0]
                print(user_id)
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
       except Exception as error:
          
           print(error)
           res="Internal Server Error"
       finally:
            dbConnection.close()
       return  res 
    

def update_class_of_business_db(_classofbusiness):
        dbConnection= connections['default'].cursor()
        print(id)
        rows=[]
        res=''
        try:
           
            query= dbConnection.mogrify("select public.udf_update_class_of_business(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);", (int(_classofbusiness.id),
            _classofbusiness.class_id,
             _classofbusiness.class_id_name,
            int(_classofbusiness.bank_id),
            _classofbusiness.agent_comm,
            _classofbusiness.payable,
            _classofbusiness.mga_comm,
            int(_classofbusiness.priority),
            _classofbusiness.class_type,
            int(_classofbusiness.percentage)
            ))
            dbConnection.execute(query)
           # ps_connection.commit()
            rows=dbConnection.fetchall()
            #print(type(rows))
            if len(rows)>0 :
                user_id=rows[0][0]
                #print(user_id,"the values are")
                if user_id>-1 :
                    res="SUCCESS"
                else:
                    res="FAILURE"
                data={"id":user_id,"Message":res}  
        except (Exception, psycopg2.DatabaseError) as error:
           
          print(error)
        finally:
            dbConnection.close()
        return  data