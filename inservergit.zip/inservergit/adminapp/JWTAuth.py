from django.conf import settings
from django.http import HttpResponse
from .utils import aes,decode_jwt_token_and_return_validity,is_valid_token
import datetime
from rest_framework.response import Response
from rest_framework import status
from rest_framework.renderers import JSONRenderer
#from jwt.algorithms import HMACAlgorithm


class JWTHandler:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
            #call dunder method
            if request.path=='/adminop/userlogin' or request.path=='/adminop/getrefreshtoken' or request.path=='/' or request.path=='/adminop/getsubmissions' :
               return self.get_response(request)
            else:
                jwt_token = request.headers.get('Authorization', 'Bearer').replace('Bearer ','')
                
                validity=decode_jwt_token_and_return_validity(settings.SECRET_KEY,jwt_token,30)
                if validity=="Invalid" :
               
                   
                   
                    response = HttpResponse(status=401)
                    response['token'] = 'Invalid'
                    return response
                elif validity=="Expired" : 
                    response = HttpResponse(status=400)
                    response['token'] = 'Expired'
                    return response 
                
            
            response = self.get_response(request)

	# Code to be executed for each response after the view is called
        # 
            print("custom middleware after response or previous middleware")
            return response
    
    