from django.shortcuts import render
from os import name
from django.shortcuts import render
from django.shortcuts import render
from django.template import Context, loader
from django.conf import settings
from adminapp.utils import create_jwt_token,  jwt_token_refresh
from rest_framework import generics
from .models import *
import datetime
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.core import serializers
from rest_framework.parsers import JSONParser
from django.http import HttpResponse
import json
from datetime import datetime
from django.http import JsonResponse
from fpdf import FPDF 

from django.conf import settings
from django.core.files import File
from django.http import FileResponse
import uuid
import base64
from django.contrib.auth.hashers import make_password,check_password
from .dboperations import  add_carrier, add_class_of_business_db, add_company_lob_master_db, add_company_master_db, add_lobmaster_db, add_policy_type_master_db, add_sections,add_section_details, add_user_type_db,  get_all_forms_listby_companyid_lobid_db, get_class_of_business_db, get_company_lob_master_db, get_company_master_by_id_db, get_company_master_db, get_lobmaster_by_id_db, get_lobmaster_db, get_lobs, get_lobs_by_company_id_db, get_policy_type_master_db,get_quote_sections, get_user_type_db,login,add_user,get_all_users,get_admin_user, set_active_company_status_db, update_class_of_business_db, update_company_lob_master_db, update_company_master_db, update_lob_master_db, update_policy_type_master_db, update_user_type_db
from .dboperations import  get_all_user_types,  get_agency_user_types, get_claims_user_types,add_agency,get_all_agencies,get_agency_name
from .dboperations import get_base_rate_and_territory_factor,get_ilf_factor,get_lcm_factor,get_pollution_factor,get_radius_factor
from .dboperations import get_state_factor,get_rate_control_factor,get_vehicle_type_factor,get_territory_code_by_zipcode,get_commodity_factor
from .dboperations import get_safer_factor,get_years_of_experience_factor,get_liability_limit_factor,get_type_of_use_factor,get_secondary_class_factor
from .dboperations import get_trailer_type_factor,get_commodityies,get_primary_factor,get_um_premium_rate_per_vehicle
from .dboperations import get_pd_deductible_factor,get_pd_state_factor,get_pd_base_rate_factor,get_pd_vehicle_make_factor,get_all_submissions
from .dboperations import get_cargo_base_rate,get_cargo_state_factor,get_cargo_radius_factor,get_cargo_limit_factor,get_cargo_deductible_factor,get_cargo_refeer_deductible_factor
from .models import User

@api_view(['GET'])

def get_submissions(request):
    """Gets list of submissions, list contains every submission as a dictionary

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    res = get_all_submissions()
    data = {"result": res}
    return Response(data, status=status.HTTP_200_OK)
 
# @api_view(['POST'])
# def save_sections(request):
#     """_summary_

#     Args:
#         request (_type_): _description_

#     Returns:
#         _type_: _description_
#     """
#     datarequested = json.loads(request.body.decode("utf-8"))
#     sections=json.loads(datarequested.get('section'))
#     rows_inserted=0
#     result="FAIL"
#     for objSec in sections:
#         objSection=QuoteSection(objSec.section_name,objSec.tabname)
#         result=add_sections(objSection)
#         if result=="SUCCESS":
#             rows_inserted=rows_inserted+1
    
#     if rows_inserted > 0:
#           result="SUCCESS"      
    
#     data = {
#             "message": result,"Sections Added":rows_inserted
#             }        
#     return Response(data, status=status.HTTP_200_OK)    

# @api_view(['POST'])
# def save_section_details(request):
#     """_summary_

#     Args:
#         request (_type_): _description_

#     Returns:
#         _type_: _description_
#     """
#     datarequested = json.loads(request.body.decode("utf-8"))
#     sectionsdetails=json.loads(datarequested.get('section'))
#     rows_inserted=0
#     result="FAIL"
#     for objSec in sectionsdetails:
#         objSection=QuoteSectionDetails(objSec.Field_name,objSec.Data_type,objSec.Section_name,objSec.Control,objSec.Size,objSec.Conversion)
#         result=add_section_details(objSection)
#         if result=="SUCCESS":
#             rows_inserted=rows_inserted+1
    
#     if rows_inserted > 0:
#           result="SUCCESS"      
    
#     data = {
#             "message": result,"Section Fields Added":rows_inserted
#             }        
#     return Response(data, status=status.HTTP_200_OK)    

# @api_view(['GET'])
# def get_quote_sections(request):
#     """_summary_

#     Args:
#         request (_type_): _description_

#     Returns:
#         _type_: _description_
#     """
#     result=get_quote_sections()
#     data = {
#             "message": result,"data":result
#     }   
#     return   Response(data, status=status.HTTP_200_OK) 

# @api_view(['GET'])
# def get_quote_section_details(request):
#     """_summary_

#     Args:
#         request (_type_): _description_

#     Returns:
#         _type_: _description_
#     """
#     result=get_quote_sections()
#     data = {
#             "message": result,"data":result
#     }   
#     return   Response(data, status=status.HTTP_200_OK) 

@api_view(['POST']) 
def get_refresh_token(request):
    """Returns a JWT token

    Args:
        request (_type_): HttpRequest

    Returns:
        _type_: HttpResponse
    """
    data = json.loads(request.body.decode("utf-8"))
    userid=data['userid']
    print(userid)
    refresh_token=jwt_token_refresh(settings.SECRET_KEY,userid,10)
    data={ "ref_token":refresh_token }
    return   Response(data, status=status.HTTP_200_OK) 

@api_view(['POST'])
def userlogin(request):
    """_summary_

    Args:
        request (_type_): HttpRequest with json data,  used_id and password 
        are received

    Returns:
        _type_: HttpResonse which contains user type (like ADMIN,UNDERWRITER etc.,) 
        if login is successful else FAILURE. Also conatins JWT accesstoken and refreshtoken
    """
    
    response = Response()
    data = json.loads(request.body.decode("utf-8"))
    access_token=''
    refresh_token =''
    print(data,"user data ")
    res=login(data["user_id"],data["password"])
    print(res)
    if res!="FAILURE":
        access_token = create_jwt_token(settings.SECRET_KEY,data["user_id"],30)
        refresh_token = create_jwt_token(settings.SECRET_KEY,data["user_id"],30)
        response.set_cookie(key='refreshtoken', value=refresh_token, httponly=True)
        
    print(access_token," ***** ")
    response.data = {
        'access_token': access_token,
        'message': res,
        }
    #else :
    #    data ={ "message":res }
    #    return   Response(data, status=status.HTTP_200_OK)
    return response 
@api_view(['POST'])
    
def get_agencyname(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    email=data["email"]
    print(email)
    res=get_agency_name(email)
    print(res)
    data={"message":res}
    return   Response(data, status=status.HTTP_200_OK)  
    

@api_view(['POST'])
def get_user_details(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    id=data["id"]
    print(id)
    rows=get_admin_user(id)
    print(rows)
    data={ "message":rows }
   
    return   Response(data, status=status.HTTP_200_OK) 

@api_view(['POST'])
def createagency(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    #print(type(data))
    #print(data)
    agency_name=data["agency_name"]
    
    address=data["address"]
    city=data["city"]
    state=data["state"]
    zipcode=data["zipcode"]
    contact_number_office=data["contact_number_office"]
    contact_number_mobile=data["contact_number_mobile"]
    email=data["email"]
    contact_person=data["contact_person"]
    fax=data["fax"]
    licence_number=data["licence_number"]
    password=data["password"]
      
    agency=Agency(agency_name,contact_person,address,city,state,zipcode,contact_number_office,
             contact_number_mobile,fax,email,licence_number,password)
    #print(usr)
    #res=login('asralladi@gmail.com','1234567')
    res=add_agency(agency)
    #print(res)
    data={ "message":res }
    return   Response(data, status=status.HTTP_200_OK) 


@api_view(['POST'])
def createuser(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    
    data = json.loads(request.body.decode("utf-8"))
    print(type(data))
    first_name=data["first_name"]
    middle_name=data["middle_name"]
    last_name=data["last_name"]
    address=data["address"]
    city=data["city"]
    state=data["state"]
    zipcode=data["zipcode"]
    contact_number_office=data["contact_number_office"]
    contact_number_mobile=data["contact_number_mobile"]
    email=data["email"]
    user_type_id=data["user_type_id"]
    gender=data["gender"]
    password=data["password"]
      
    usr=User(first_name,middle_name,last_name,address,city,state,zipcode,contact_number_office,
             contact_number_mobile,email,user_type_id,gender,password)
    #print(usr)
    #res=login('asralladi@gmail.com','1234567')
    res=add_user(usr)
    #print(res)
    data={ "message":res }
    return   Response(data, status=status.HTTP_200_OK) 
@api_view(['GET'])
def get_commodites(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    res=get_commodityies()
    result=[]
    
    
    for x in res:
        result.append({"commodity_type":x[0].get("commodity_type"),"eligibility":x[0].get("eligibility")})
    data={"result":result}
    return   Response(data, status=status.HTTP_200_OK) 

@api_view(['GET'])
def get_admin_user_types(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    res=get_all_user_types()
    data={"result":res}
    return   Response(data, status=status.HTTP_200_OK)  

@api_view(['GET'])

def get_user_types_agency(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    res= get_agency_user_types()
    data={"result":res}
    return   Response(data, status=status.HTTP_200_OK) 

@api_view(['GET'])
def get_user_types_claims(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    res= get_claims_user_types()
    data={"result":res}
    return   Response(data, status=status.HTTP_200_OK) 

@api_view(['GET'])
def get_users(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    res=get_all_users()
    data={"result":res}
    return   Response(data, status=status.HTTP_200_OK) 
@api_view(['GET'])
def get_agencies(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    res=get_all_agencies()
    data={"result":res}
    return   Response(data, status=status.HTTP_200_OK)   
@api_view(['POST'])
def create_agency(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    agency=Agency(data["agency_name"],data["contact_person"],data["address"],data["city"],data["state"],data["zipcode"],
                 data["contact_number_office"],data["contact_number_mobile"],data["fax"],data["email"],
                 data["licence_number"],data["password"])
    
    return   Response(data, status=status.HTTP_200_OK)   
@api_view(['POST'])
def get_commodity_factors(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    cdts=data["commodities"]
    print(cdts)
    cdts_factors=[]
    for com in cdts:
        cdts_factors.append({"commodity":com,"factors":get_commodity_factor(com.get("commodity_type"))})
    data={"result": cdts_factors}
    return   Response(data, status=status.HTTP_200_OK)       
    

@api_view(['POST'])
def get_vehicle_type_factors(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    vtype=data["vehicle_type"]
    data={"vehicle_type_factor":get_vehicle_type_factor(vtype)} 
    
    res={"result": data}    
    return   Response(res, status=status.HTTP_200_OK)

def get_vehicle_type_fact(vtype):
    """_summary_

    Args:
        vtype (_type_): _description_

    Returns:
        _type_: _description_
    """
    
     
    return   get_vehicle_type_factor(vtype)

@api_view(['POST'])
def get_trailer_type_factors(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    ttype=data["trailer_type"]
   
    data={"trailer_type_factor":get_trailer_type_factor(ttype)}
    data={"result": data}    
    return   Response(data, status=status.HTTP_200_OK)
        
        
#@api_view(['POST']) 
#def get_uw_unit_cost(request)   

def get_vcargo_premium(state,radius,limit,deductible,refdeductible):
    """_summary_

    Args:
        state (_type_): _description_
        radius (_type_): _description_
        limit (_type_): _description_
        deductible (_type_): _description_
        refdeductible (_type_): _description_

    Returns:
        _type_: _description_
    """
    cargo_premium_factors=[];
    
    cargo_premium_factors.append({"factor_type":"base_ratefactor","factor":get_cargo_base_rate()})
    cargo_premium_factors.append({"factor_type":"state_factor","factor":get_cargo_state_factor(state)})
    cargo_premium_factors.append({"factor_type":"radius_factor","factor":get_cargo_radius_factor(radius)})
    cargo_premium_factors.append({"factor_type":"limit_factor","factor":get_cargo_limit_factor(limit)})
    cargo_premium_factors.append({"factor_type":"deductible_factor","factor":get_cargo_deductible_factor(deductible)})
    cargo_premium_factors.append({"factor_type":"refeer_deductible_factor","factor":get_cargo_refeer_deductible_factor(refdeductible)})
    #data={"result": cargo_premium_factors}
    #return   Response(data, status=status.HTTP_200_OK) 
    return cargo_premium_factors



@api_view(['POST'])
def get_cargo_premium(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    cargo_premium_factors=[];
    data=json.loads(request.body.decode("utf-8"));
    
    state=data["state"]
    radius=data["radius"]
    limit=data["limit"]
    
    
    deductible=data["deductible"]
    refdeductible=data["refdeductible"]
    cargo_premium_factors.append({"factor_type":"base_ratefactor","factor":get_cargo_base_rate()})
    cargo_premium_factors.append({"factor_type":"state_factor","factor":get_cargo_state_factor(state)})
    cargo_premium_factors.append({"factor_type":"radius_factor","factor":get_cargo_radius_factor(radius)})
    cargo_premium_factors.append({"factor_type":"limit_factor","factor":get_cargo_limit_factor(limit)})
    cargo_premium_factors.append({"factor_type":"deductible_factor","factor":get_cargo_deductible_factor(deductible)})
    cargo_premium_factors.append({"factor_type":"refeer_deductible_factor","factor":get_cargo_refeer_deductible_factor(refdeductible)})
    #data={"result": cargo_premium_factors}
    #return   Response(data, status=status.HTTP_200_OK) 
    return cargo_premium_factors

def get_vpd_premium(statedvalue,vmake,state,deductible):
    """_summary_

    Args:
        statedvalue (_type_): _description_
        vmake (_type_): _description_
        state (_type_): _description_
        deductible (_type_): _description_

    Returns:
        _type_: _description_
    """
    pd_premium_factors=[]
    
    pd_premium_factors.append({"factor_type":"vehicle_make_factor","factor":get_pd_vehicle_make_factor(vmake)})
    pd_premium_factors.append({"factor_type":"base_rate_factor","factor":get_pd_base_rate_factor(statedvalue)})
    pd_premium_factors.append({"factor_type":"state_factor","factor":get_pd_state_factor(state)})
    pd_premium_factors.append({"factor_type":"deductible_factor","factor":get_pd_deductible_factor(deductible)})
    
    return pd_premium_factors

@api_view(['POST'])
def get_pd_premium(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    pd_premium_factors=[];
    data=json.loads(request.body.decode("utf-8"));
    statedvalue=data["statedvalue"]
    vmake=data["vmake"]
    state=data["state"]
    deductible=data["deductible"]
    pd_premium_factors.append({"factor_type":"vehicle_make_factor","factor":get_pd_vehicle_make_factor(vmake)})
    pd_premium_factors.append({"factor_type":"base_rate_factor","factor":get_pd_base_rate_factor(statedvalue)})
    pd_premium_factors.append({"factor_type":"state_factor","factor":get_pd_state_factor(state)})
    pd_premium_factors.append({"factor_type":"deductible_factor","factor":get_pd_deductible_factor(deductible)})
    
    return pd_premium_factors
    
@api_view  (['POST'])  
def get_all_premium_factors_for_vehicle(request):
    """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
    data = json.loads(request.body.decode("utf-8"))
    cargo_yes= data["is_cargo"]
    pd_yes=data["is_pd"]
    liability_yes=data["is_liability"]
   
    
    statedvalue=data["statedvalue"]
    vmake=data["vmake"]
    state=data["state"]
    deductible=data["deductible"]
    pddeductable=data["pddeductible"]
    print(pddeductable)
    
    radius=data["radius"]
    limit=data["limit"]
    vtype=data["vtype"]   
    
    
    refdeductible=data["refdeductible"]
    print("cargo yes "+cargo_yes)
    if cargo_yes=='Yes':
        print(state,radius,limit,deductible,refdeductible)
        cargo_result=get_vcargo_premium(state,radius,limit,deductible,refdeductible)
    else:
        cargo_result=[]
    if pd_yes=="Yes":
        pd_result=get_vpd_premium(statedvalue,vmake,state,pddeductable)
    else:
        pd_result=[];
    if liability_yes=='Yes':
        liability_result=get_liability_premium(request)
    else:
        liability_result=[]
    data={"pd_result":pd_result,"cargo_result":cargo_result,"vehicle_type":get_vehicle_type_fact(vtype)}
    return   Response(data, status=status.HTTP_200_OK)    
    
    
@api_view(['POST'])
def get_liability_premium(request):
     """_summary_

    Args:
        request (_type_): _description_

    Returns:
        _type_: _description_
    """
     policy_factors=[]
     data = json.loads(request.body.decode("utf-8"))
     
     
     
     
     data = json.loads(request.body.decode("utf-8"))
     liability=data["liability"]
    
     zipcode=data["zcode"]
     state_code=data["state"]
     radius=data["radius"]
     territory_code=get_territory_code_by_zipcode(zipcode)
     
     saferfactor=data["safer_factor"]
     
     yxp=data["years_of_experience"]
  
     usetype=data["usetype"]
     secondary_class=data["secondary_class"]
     
     trailer_type=data["trailer_type"]
     cargo_limit=data["cargo_limit"]
     cargo_deductible=data["cargo_deductible"]
 
     cargo_refdeductible=data["refdeductible"]
      
    
     if cargo_limit!='':
        policy_factors.append({"factor_type":"base_ratefactor","factor":get_cargo_base_rate()})
        policy_factors.append({"factor_type":"cargo_state_factor","factor":get_cargo_state_factor(state_code)})
        policy_factors.append({"factor_type":"cargo_radius_factor","factor":get_cargo_radius_factor(radius)})
        policy_factors.append({"factor_type":"cargo_limit_factor","factor":get_cargo_limit_factor(cargo_limit)})
        policy_factors.append({"factor_type":"cargo_deductible_factor","factor":get_cargo_deductible_factor(cargo_deductible)})
        policy_factors.append({"factor_type":"refeer_deductible_factor","factor":get_cargo_refeer_deductible_factor(cargo_refdeductible)})  

    
     
     lst_base_rate_territory_factor=get_base_rate_and_territory_factor( territory_code,state_code)
     base_rate=lst_base_rate_territory_factor.get("base_rate")
  

     tfactor=lst_base_rate_territory_factor.get("territory_factor")
     
     
     ilf_factor=get_ilf_factor()
     lcm_factor=get_lcm_factor()
     pollution_factor=get_pollution_factor()
     state_factor=get_state_factor()
     rate_control_factor=get_rate_control_factor()
     primary_factor=get_primary_factor()
     radius_factor=get_radius_factor(radius)
     liability_limit_factor=get_liability_limit_factor(liability)
     
    
     
     policy_factors.append({"factor_type":"base_rate","Value":base_rate})
     policy_factors.append({"factor_type":"territory_factor","Value":lst_base_rate_territory_factor.get('territory_factor')})
     policy_factors.append({"factor_type":"ilf_factor","Value":ilf_factor})
     
     policy_factors.append({"factor_type":"lcm_factor","Value":lcm_factor})
     policy_factors.append({"factor_type":"pollution_factor","Value":pollution_factor})
     policy_factors.append({"factor_type":"state_factor","Value":state_factor})
     policy_factors.append({"factor_type":"rate_control_factor","Value":rate_control_factor })
     policy_factors.append({"factor_type":"primary_factor","Value":primary_factor})
     policy_factors.append({"factor_type":"radius_factor","Value":radius_factor})
     if liability!='':
        policy_factors.append({"factor_type":"liability_factor","Value":liability_limit_factor})
     else:
        policy_factors.append({"factor_type":"liability_factor","Value":''})
     
     policy_factors.append({"factor_type":"safer_factor","Value":get_safer_factor(saferfactor)})
     policy_factors.append({"factor_type":"years_of_experience_factor","Value":get_years_of_experience_factor(yxp)})
     policy_factors.append({"factor_type":"type_of_use_factor","Value":get_type_of_use_factor(usetype)})
     policy_factors.append({"factor_type":"secondary_class_factor","Value":get_secondary_class_factor(secondary_class)})
    
     policy_factors.append({"factor_type":"trailer_type_factor","Value":get_trailer_type_factor(trailer_type)})
     print(policy_factors)
     data={"result": policy_factors}
     return   Response(data, status=status.HTTP_200_OK)   
 
@api_view(['GET'])
def get_company_master(request):
    """This is the function to get all the fields of company-master.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        res=get_company_master_db()
        data={"result":res}
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception)as error:
         print(error)
         data={"result":"Something went to wrong..please try again"}
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    
    
@api_view(['POST'])
def get_company_master_by_id(request):
    """This is the function to get company master by id.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        _id=data["_id"]
        print(_id,"the id value")
        data=get_company_master_by_id_db(_id)
        #res={"state":data}
        # data={"id":get_company_master_by_id_db(_id)}
        data={"result":data}    
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception)as error:
         print(error)
         data={"result":"Something went to wrong..please try again"}
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

   

@api_view(['POST'])
def update_company_master(request):
    """This is the function to update the fields of company master.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        id=data["id"] 
        company_id=data["company_id"]
        id_name=data["id_name"]
        company_name=data["company_name"]
        phone=data["phone"]
        active=data["active"]
        mga_commission=data["mga_commission"]
        mga_fees=data["mga_fees"]
        effective_date=data["effective_date"]
        exp_date=data["exp_date"]
        _companymaster=Companymaster(id,company_id,id_name,company_name,phone,active,mga_commission,mga_fees,
                                        effective_date,exp_date)
        print(_companymaster)
        #res=login('asralladi@gmail.com','1234567')
        res=update_company_master_db(_companymaster)
        print(res)
        # data={"message":res}
        return  Response(res, status=status.HTTP_200_OK)
    except(Exception)as error:
         print(error)
         data={"id":0,"Message":"Something went to wrong"}  
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def add_company_master(request):
    """This is the function to create new company.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        id =data["id"]
        company_id = data["company_id"]
        id_name =data["id_name"]
        company_name=data["company_name"]
        phone=data["phone"]
        active=data["active"]
        mga_commission=data["mga_commission"]
        mga_fees=data["mga_fees"]
        effective_date=data["effective_date"]  
        exp_date =data["exp_date"]      
        _companymaster=Companymaster(0,company_id,id_name,company_name,phone,active,mga_commission,mga_fees,effective_date,exp_date)
        # res=login('asralladi@gmail.com','1234567')
        res=add_company_master_db(_companymaster)
        data={"message":res}
        return  Response(data, status=status.HTTP_200_OK)
    except(Exception)as error:
         print(error)
         data={"message":"Something went to wrong..please try again"}
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    

    # To make company Inactive or Active
@api_view(['POST', 'OPTIONS'])
def set_status_company_master(request):
    """This function is used to make form status inactive.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        id = data["id"]
        if request.method == 'POST':
            try:
                    # print(request.data)

                
                    #form_data = ins_forms_master(id,form_active)
                    res = {"status": set_active_company_status_db(id)}
                    if res['status'] != "FAIL":
                        data = {"message":"SUCESS", "Company Updated": True}
                    else:
                        data = {"message": "Some thing wento wrong..",
                                "Company Updated": False}
            except Exception as error:
                    print(error)
                    data = {"message": "not a post method"}
            return Response(data, status=status.HTTP_200_OK)
    except(Exception)as error:
         print(error)
         data={"message":"Something went to wrong..please try again"}
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)




@api_view(['POST'])
def get_all_lobs(request):
    try:
        
        # _id=data["lob_id"]
       
    
        data=get_lobs()
        #res={"state":data}
        data={"result":data}    
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception)as error:
         data={"result":None}
         #print(error)
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def get_all_forms_by_companyid_lobid(request):
    """This is the function to get all the forms by company id and lob id.
    Args:
        request (_type_): HttpRequest

    Returns:
        _type_: HttpResponse
    """
    # data = json.loads(request.body.decode("utf-8"))
    # # _id=data["lob_id"]
    # print(data,"the id value")
    try:
        data=get_all_forms_listby_companyid_lobid_db(request)
        data={"result":data}    
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception)as error:
         data={"result":None}
         print(error)
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    


@api_view(['POST'])
def get_lobs_by_company_id(request):
    """This is the function to get lobs by id.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        lob_id = json.loads(request.body.decode("utf-8"))
        # _id=data["lob_id"]
        print(lob_id,"the id value")
    
        data=get_lobs_by_company_id_db(lob_id)
        #res={"state":data}
        data={"result":data}    
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception)as error:
         data={"result":None}
         #print(error)
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def get_all_forms_by_companyid_lobid(request):
    """This is the function to get all the forms by company id and lob id.
    Args:
        request (_type_): HttpRequest

    Returns:
        _type_: HttpResponse
    """
    # data = json.loads(request.body.decode("utf-8"))
    # # _id=data["lob_id"]
    # print(data,"the id value")
    try:
        data=get_all_forms_listby_companyid_lobid_db(request)
        data={"result":data}    
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception)as error:
         data={"result":None}
         print(error)
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

 
     
    #res={"state":data}
  





@api_view(['GET'])
def get_lobmaster(request):
    """This is the function to get all fields of lob master.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        res=get_lobmaster_db()
        data={"result":res}
        return   Response(data, status=status.HTTP_200_OK) 

    except(Exception) as error:
         data={"result":res}
         return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


    
@api_view(['POST'])
def add_lobmaster(request):
    """This is the function to create new lob.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        lob=data["lob"]
        lob_id=data["lob_id"]
        name=data["name"]
                
        _lobmaster=lobmaster(0,lob,lob_id,name)
        #res=login('asralladi@gmail.com','1234567')
        res=add_lobmaster_db(_lobmaster)
        print(res)
        
        data={ "message":"SUCSESS" }
    
        return  Response(data, status=status.HTTP_200_OK) 
    except(Exception) as error:
        data={"result":"Something wento wrong....!"}
        return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    

@api_view(['GET'])
def get_lob_master_by_id(request):
    """This is the function to get all fields of lob master by id.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        _lob_id =data["_lob_id"]
        print(_lob_id,"the id value")
        data= get_lobmaster_by_id_db(_lob_id)
        data={"lob_id":get_lobmaster_by_id_db(_lob_id)}
        data={"result": data}    
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception) as error:
        data={"result":data}
        return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def update_lob_master(request):
    """This is the function to update the fields of lob-master data.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        lob=data["lob"]
        lob_id=data["lob_id"]
        name=data["name"]
        id=data["id"]
        usr=lobmaster(id,lob,lob_id,name)
        print(usr)
        #res=login('asralladi@gmail.com','1234567')
        res=update_lob_master_db(usr)
        print(res)
        data={ "message":"SUCSESSS" }
        return  Response(data, status=status.HTTP_200_OK)  
    except(Exception) as error:
        data={"result":"Somethig wento wrong...!"}
        return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)




@api_view(['GET'])
def get_company_lob_master(request):
    """This is the function to get all the fields data of lob-master.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        res=get_company_lob_master_db()
        data={"result":res}
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception) as error:
        data={"result":res}
        return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
def add_company_lob_master(request):
    """This is the function to create new company-lob-master.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        company_id=data["company_id"]
        lob_id=data["lob_id"]
        _companylobmaster=companylobmaster(company_id,lob_id)
        #res=login('asralladi@gmail.com','1234567')
        res=add_company_lob_master_db(_companylobmaster)
        print(res)
        data={ "message":res }
        return  Response(data, status=status.HTTP_200_OK)  
    except(Exception) as error:
        data={"result":res}
        return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    

@api_view(['POST'])
def update_company_lob_master(request):
    """This is the function to edit the company-lob-master data.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        company_id=data["company_id"] 
        lob_id=data["lob_id"]
        id=data["id"]
        _companylobmaster=companylobmaster(company_id,lob_id,id)
        print(_companylobmaster)
        res=update_company_lob_master_db(_companylobmaster)
        print(res)
        return  Response(res, status=status.HTTP_200_OK)
    except(Exception) as error:
        data={"result":res}
        return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    



@api_view(['GET'])
def get_policy_type_master(request):
    """This is the function to get all the fields of policy_type-master data.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        res=get_policy_type_master_db()
        data={"result":res}
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception) as error:
        error_data={"result":data}
        return Response(error_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    


@api_view(['POST'])
def add_policy_type_master(request):
    """This is the function to create new policy_type.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        policy_type_description=data["policy_type_description"]
        _policymaster=policymaster(0,policy_type_description)
        #res=login('asralladi@gmail.com','1234567')
        res=add_policy_type_master_db(_policymaster)
        print(res)
        data={ "message":res }
        return  Response(data, status=status.HTTP_200_OK)  
    except(Exception) as error:
        error_data={"result":data}
        return Response(error_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    

@api_view(['POST'])
def update_policy_type_master(request):
    """This is the function to edit the fields of policy_type_master.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        policy_type_id=data["policy_type_id"] 
        policy_type_description=data["policy_type_description"]
        _policymaster=policymaster(policy_type_id,policy_type_description)
        print(_policymaster)
        res=update_policy_type_master_db(_policymaster)
        print(res)
        return  Response(res, status=status.HTTP_200_OK)
    except(Exception) as error:
        return Response(res, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    


@api_view(['GET'])
def get_user_type(request):
    """This is the function to get all the fields of user-type.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        res=get_user_type_db()
        data={"result":res}
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception) as error:
        return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)   

@api_view(['POST'])
def add_user_type(request):
    """This is the function to create new user-type.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        user_type=data["user_type"]
        _usertype=usertype(0,user_type)
        res=add_user_type_db(_usertype)
        print(res)
        data={ "message":res }
        return  Response(data, status=status.HTTP_200_OK) 
    except(Exception) as error:
        return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    

@api_view(['POST'])
def update_user_type(request):
    """This is the function to update user-type.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        id=data["id"] 
        user_type=data["user_type"]
        _usertype=usertype(id,user_type)
        print(_usertype)
        res=update_user_type_db(_usertype)
        print(res)
        return  Response(res, status=status.HTTP_200_OK)
    except(Exception) as error:
        return Response(res, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    




@api_view(['GET'])
def get_class_of_business(request):
    """This is the function to get all the fields of class-of-business.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        res=get_class_of_business_db()
        data={"result":res}
        return   Response(data, status=status.HTTP_200_OK)
    except(Exception) as error:
        return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)    
    

@api_view(['POST'])
def add_class_of_business(request):
    """This is the function to create new class-of-business.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        class_id=data["class_id"]
        class_id_name=data["class_id_name"]
        bank_id=data["bank_id"]
        agent_comm=data["agent_comm"]
        payable=data["payable"]
        mga_comm=data["mga_comm"]
        priority=data["priority"]
        class_type=data["class_type"]
        percentage=data["percentage"]
        _classofbusiness=Classofbusiness(0,class_id,class_id_name,bank_id,agent_comm,payable,mga_comm,priority,
                                        class_type,percentage )
        res=add_class_of_business_db(_classofbusiness)
        print(res)
        data={ "message":res }
        return  Response(data, status=status.HTTP_200_OK) 
    except(Exception) as error:
        return Response(data, status=status.HTTP_500_INTERNAL_SERVER_ERROR) 

@api_view(['POST'])
def update_class_of_business(request):
    """This is the function to edit all the fields of class-of-business data.
    Args:
        request (_type_): HttpRequest
    Returns:
        _type_: HttpResponse
    """
    try:
        data = json.loads(request.body.decode("utf-8"))
        id=data["id"]
        class_id=data["class_id"]
        class_id_name=data["class_id_name"]
        bank_id=data["bank_id"]
        agent_comm=data["agent_comm"]
        payable=data["payable"]
        mga_comm=data["mga_comm"]
        priority=data["priority"]
        class_type=data["class_type"]
        percentage=data["percentage"]
        _classofbusiness=Classofbusiness(id,class_id,class_id_name,bank_id,agent_comm,payable,mga_comm,priority,class_type,percentage )
        print(_classofbusiness)
        res=update_class_of_business_db(_classofbusiness)
        print(res)
        return  Response(res, status=status.HTTP_200_OK)
    except(Exception) as error:
        return Response(res, status=status.HTTP_500_INTERNAL_SERVER_ERROR) 

 







        
    
