from django.shortcuts import render
from os import name
from django.shortcuts import render
from django.shortcuts import render
from django.template import Context, loader
from django.conf import settings
from adminapp.dboperations import get_agency_details_db, login
from adminapp.utils import create_jwt_token,  jwt_token_refresh
from rest_framework import generics
from rest_framework.views import APIView
#from .models import *
import datetime
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.core import serializers
from rest_framework.parsers import JSONParser
from django.http import HttpResponse
import json
from datetime import datetime
from django.http import JsonResponse
from fpdf import FPDF 

from django.conf import settings
from django.core.files import File
from django.http import FileResponse
import uuid
import base64
from django.contrib.auth.hashers import make_password,check_password
# from .dboperations import  add_carrier, add_class_of_business_db, add_company_lob_master_db, add_company_master_db, add_lobmaster_db, add_policy_type_master_db, add_sections,add_section_details, add_user_type_db,  get_all_forms_listby_companyid_lobid_db, get_class_of_business_db, get_company_lob_master_db, get_company_master_by_id_db, get_company_master_db, get_lobmaster_by_id_db, get_lobmaster_db, get_lobs, get_lobs_by_company_id_db, get_policy_type_master_db,get_quote_sections, get_user_type_db,login,add_user,get_all_users,get_admin_user, set_active_company_status_db, update_class_of_business_db, update_company_lob_master_db, update_company_master_db, update_lob_master_db, update_policy_type_master_db, update_user_type_db
# from .dboperations import  get_all_user_types,  get_agency_user_types, get_claims_user_types,add_agency,get_all_agencies,get_agency_name
# from .dboperations import get_base_rate_and_territory_factor,get_ilf_factor,get_lcm_factor,get_pollution_factor,get_radius_factor
# from .dboperations import get_state_factor,get_rate_control_factor,get_vehicle_type_factor,get_territory_code_by_zipcode,get_commodity_factor
# from .dboperations import get_safer_factor,get_years_of_experience_factor,get_liability_limit_factor,get_type_of_use_factor,get_secondary_class_factor
# from .dboperations import get_trailer_type_factor,get_commodityies,get_primary_factor,get_um_premium_rate_per_vehicle
# from .dboperations import get_pd_deductible_factor,get_pd_state_factor,get_pd_base_rate_factor,get_pd_vehicle_make_factor,get_all_submissions
# from .dboperations import get_cargo_base_rate,get_cargo_state_factor,get_cargo_radius_factor,get_cargo_limit_factor,get_cargo_deductible_factor,get_cargo_refeer_deductible_factor
# from .models import User

class Login(APIView):
    def post(self,request):
        response = Response()
        data = json.loads(request.body.decode("utf-8"))
        access_token=''
        refresh_token =''
        agency={}
        res,user_dict=login(data["user_id"],data["password"])
        #print(res)
        if res!='FAILURE':
        #print(user_dict)
            if user_dict['agency_id']!=None:
                agency=get_agency_details_db(user_dict["agency_id"])
            else:
            #id_name=rows[0][0].get('id_name')
                #agency_id=rows[0][0].get('agency_id')
                #agency_name=rows[0][0].get('agency_name')
                #phone=rows[0][0].get('phone')
                agency={"id_name":"","agency_id":-1,"agency_name":"","phone":""}    
    
        if res!="FAILURE":
            access_token = create_jwt_token(settings.SECRET_KEY,data["user_id"],30)
            refresh_token = create_jwt_token(settings.SECRET_KEY,data["user_id"],30)
            response.set_cookie(key='refreshtoken', value=refresh_token, httponly=True)
        
        #print(access_token," ***** ")
        response.data = {
            'access_token': access_token,
            'message': res,
            'user':user_dict,
            'agency': agency
        }
    #else :
    #    data ={ "message":res }
    #    return   Response(data, status=status.HTTP_200_OK)
        return response 

# @api_view(['POST'])
# def userlogin(request):
#     """_summary_

#     Args:
#         request (_type_): HttpRequest with json data,  used_id and password 
#         are received

#     Returns:
#         _type_: HttpResonse which contains user type (like ADMIN,UNDERWRITER etc.,) 
#         if login is successful else FAILURE. Also conatins JWT accesstoken and refreshtoken
#     """
    
#     response = Response()
#     data = json.loads(request.body.decode("utf-8"))
#     access_token=''
#     agency={}
        # res,user_dict=login(data["user_id"],data["password"])
        # if user_dict['agency_id']!=None:
        #     agency=get_agency_details_db(data["user_id"])
    
        # if res!="FAILURE":
        #     access_token = create_jwt_token(settings.SECRET_KEY,data["user_id"],30)
        #     refresh_token = create_jwt_token(settings.SECRET_KEY,data["user_id"],30)
        #     response.set_cookie(key='refreshtoken', value=refresh_token, httponly=True)
        
        # print(access_token," ***** ")
        # response.data = {
        #     'access_token': access_token,
        #     'message': res,
        #     'user':user_dict,
        #     'agency': agency
        # }
#     #else :
#     #    data ={ "message":res }
#     #    return   Response(data, status=status.HTTP_200_OK)
#     return response 
