from django.urls import include, path

from adminapp.dboperations import get_all_users
from adminapp.views.login import Login
#from .views import GenInfoCreate, GenInfoList, GenInfoDetail, GenInfoUpdate, GenInfoDelete,geninfo_list,geninfo_detail,DownloadPDF,home,bulkinsert,geninfo_edit,geninfo_retrieve
from .views import add_class_of_business, add_company_lob_master, add_company_master, add_policy_type_master, add_user_type, get_all_lobs, get_class_of_business, get_policy_type_master, get_user_details, get_user_type,  set_status_company_master, update_class_of_business, update_company_lob_master, update_policy_type_master, update_user_type,userlogin,createuser,get_users,createagency,get_agencies,get_agencyname,get_liability_premium,get_commodites
from .views import get_commodity_factors,get_vehicle_type_factors,get_pd_premium,get_cargo_premium,get_trailer_type_factors,get_all_premium_factors_for_vehicle,    get_submissions,get_refresh_token
from .views import add_lobmaster,get_lobmaster,get_lob_master_by_id,update_lob_master,add_company_master_db,get_company_master
from .views import get_company_master_by_id,update_company_master,get_lobs_by_company_id,get_all_forms_by_companyid_lobid
urlpatterns = [
   # path('create/', GenInfoCreate.as_view(), name='create-geninfo'),
   # path('', home),
   # path('<int:pk>/', GenInfoCreate.as_view(), name='retrieve-geninfo'),
   # path('update/<int:pk>/', GenInfoCreate.as_view(), name='update-geninfo'),
   # path('delete/<int:pk>/', GenInfoCreate.as_view(), name='delete-geninfo'),
   # path('all', geninfo_list),
   # path('manage/<int:pk>/',geninfo_detail),
   # path('download/<int:id>/',DownloadPDF),
   # path('bulkinsert',bulkinsert),
   # path('editgeninfo/<int:id>',geninfo_edit),
   # path('getquote/<int:id>',geninfo_retrieve) '''
   
   #path ('createsections/',save_sections),
   #path ('createsectiondetails/',save_section_details),
   #path ('getquotesections/',get_quote_sections),
   #path ('getquotesectiondetails/',get_quote_section_details),
   path('login',userlogin),
   path('createuser',createuser),
   path('getusers',get_users),
   path('createagency',createagency),
   path('getagencies',get_agencies),
   path('getagencyname',get_agencyname),
   path('getadminuser',get_user_details),
   path('getpremium',get_liability_premium),
   path('getpdpremium',get_pd_premium),
   path('getcargopremium',get_cargo_premium),
   path('getcommodites',get_commodites),
   path('getcommodityfactors',get_commodity_factors),
   path('getvehicletypefactor',get_vehicle_type_factors),
   path('getallvehiclefactors',get_all_premium_factors_for_vehicle),
   path('gettrailertypefactors',get_trailer_type_factors),
   path('getsubmissions', get_submissions), 
   path('getrefreshtoken',get_refresh_token),
    path('addlobmaster',add_lobmaster, name='add_lobmaster'),
   path('getlobmaster',get_lobmaster,name='get_lobmaster'),
   path('getlobmasterbyid',get_lob_master_by_id,name='get_lob_master_by_id'),
   path('updatelobmaster',update_lob_master,name='update_lob_master'),
   path('addcompanymaster',add_company_master,name='add_company_master'),
   path('getcompanymaster',get_company_master,name='get_company_master'),
   path('getcompanymasterbyid',get_company_master_by_id,name='get_company_master_by_id'),
   path('updatecompanymaster',update_company_master,name="update_company_master"),
   path('getlobsbycomapnyid',get_lobs_by_company_id, name='get_lobs_by_company_id'),
   path('getallformsbycomapnyidlobid',get_all_forms_by_companyid_lobid, name='get_all_forms_by_companyid_lobid'),
   path('setcompanymasterstatus',set_status_company_master, name='set_status_company_master'),
   path('getcompanylobmaster',add_company_lob_master,name='get_company_lob_master'),
   path('addcompanylobmaster',add_company_lob_master,name='add_company_lob_master'),
   path('updatecompanylobmaster',update_company_lob_master, name='update_company_lob_master'),
   path('getpolicytypemaster',get_policy_type_master, name='get_policy_type_master'),
   path('addpolicytypemaster',add_policy_type_master, name='add_policy_type_master'),
   path('updatepolicytypemaster',update_policy_type_master,name='update_policy_type_master'),
   path('getusertype',get_user_type, name='get_user_type'),
   path('addusertype',add_user_type, name='add_user_type'),
   path('updateusertype',update_user_type, name='update_user_type'),
   path('getclassofbusiness',get_class_of_business, name='get_class_of_business'),
   path('addclassofbusiness',add_class_of_business, name='add_class_of_business'),
   path('updateclassofbusiness',update_class_of_business, name='update_class_of_business'),
   path('getlobs',get_all_lobs,name='get_all_lobs'),
   path('userlogin',Login.as_view()), 
   
   
   
   
    
    
]